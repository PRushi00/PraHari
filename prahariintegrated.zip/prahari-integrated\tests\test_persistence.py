"""Tests for storage/persistence.py and its wiring into ThreatEventStore
(backend/threat_service.py) and LocalBlockchainLedger (blockchain/ledger.py).

The central claim to verify: state written through a SqlitePersistence
survives being handed to a BRAND NEW store/ledger instance pointed at the
same file -- i.e. it genuinely simulates a process restart, not just
"the same object still has it in memory"."""
import pandas as pd
import pytest

from backend.forecasting_service import DEMONSTRATION_MODE, ForecastResult
from backend.threat_service import ThreatEventStore, create_threat_event
from blockchain.ledger import LocalBlockchainLedger
from storage.persistence import SqlitePersistence

FORECAST_WINDOW = {
    "horizon_minutes": 30,
    "window_start_offset_minutes": 1,
    "window_end_offset_minutes": 30,
    "label": "next 30 minutes",
}


def _demo_result(probability=0.9, attack_type="DDoS"):
    return ForecastResult(
        mode=DEMONSTRATION_MODE,
        probability=probability,
        attack_type=attack_type,
        model_status="HEURISTIC_NOT_A_TRAINED_MODEL",
        confidence=0.5,
        explanation="heuristic explanation",
        history_minutes_used=3,
        ready=True,
        forecast_window=dict(FORECAST_WINDOW),
    )


@pytest.fixture()
def db_path(tmp_path):
    return tmp_path / "test_state.sqlite3"


def test_persistence_creates_the_db_file_and_parent_dirs(tmp_path):
    nested = tmp_path / "a" / "b" / "state.sqlite3"
    persistence = SqlitePersistence(nested)
    assert nested.exists()
    persistence.close()


def test_save_and_load_threat_events_round_trip(db_path):
    persistence = SqlitePersistence(db_path)
    persistence.save_threat_event("evt_1", 0, {"event_id": "evt_1", "severity": "HIGH"})
    persistence.save_threat_event("evt_2", 1, {"event_id": "evt_2", "severity": "LOW"})
    loaded = persistence.load_threat_events()
    assert [e["event_id"] for e in loaded] == ["evt_1", "evt_2"]  # oldest-first


def test_save_threat_event_is_upsert_by_event_id(db_path):
    persistence = SqlitePersistence(db_path)
    persistence.save_threat_event("evt_1", 0, {"event_id": "evt_1", "severity": "LOW"})
    persistence.save_threat_event("evt_1", 0, {"event_id": "evt_1", "severity": "CRITICAL"})
    loaded = persistence.load_threat_events()
    assert len(loaded) == 1
    assert loaded[0]["severity"] == "CRITICAL"


def test_clear_threat_events_leaves_blockchain_records_untouched(db_path):
    persistence = SqlitePersistence(db_path)
    persistence.save_threat_event("evt_1", 0, {"event_id": "evt_1"})
    persistence.save_blockchain_record("evt_1", {"event_id": "evt_1", "threat_hash": "0xabc"})
    persistence.clear_threat_events()
    assert persistence.load_threat_events() == []
    assert persistence.load_blockchain_records() == {"evt_1": {"event_id": "evt_1", "threat_hash": "0xabc"}}


def test_clear_blockchain_records_leaves_threat_events_untouched(db_path):
    persistence = SqlitePersistence(db_path)
    persistence.save_threat_event("evt_1", 0, {"event_id": "evt_1"})
    persistence.save_blockchain_record("evt_1", {"event_id": "evt_1", "threat_hash": "0xabc"})
    persistence.clear_blockchain_records()
    assert persistence.load_blockchain_records() == {}
    assert len(persistence.load_threat_events()) == 1


def test_threat_event_store_without_persistence_behaves_as_before(db_path):
    """No persistence argument -> unchanged in-memory-only behavior."""
    store = ThreatEventStore()
    forecast = _demo_result()
    event = create_threat_event(forecast, as_of=pd.Timestamp("2017-07-07 03:56:00"))
    store.add(event)
    assert len(store) == 1

    reloaded = ThreatEventStore()  # a second, independent in-memory-only store
    assert len(reloaded) == 0


def test_threat_event_store_survives_a_simulated_restart(db_path):
    persistence = SqlitePersistence(db_path)
    store = ThreatEventStore(persistence=persistence)
    forecast = _demo_result()
    event = create_threat_event(forecast, as_of=pd.Timestamp("2017-07-07 03:56:00"))
    store.add(event)
    assert len(store) == 1

    # Simulate a process restart: brand new store, new SqlitePersistence,
    # same underlying file.
    restarted_persistence = SqlitePersistence(db_path)
    restarted_store = ThreatEventStore(persistence=restarted_persistence)
    assert len(restarted_store) == 1
    assert restarted_store.latest().event_id == event.event_id
    assert restarted_store.latest().severity == event.severity


def test_threat_event_store_clear_also_clears_the_persisted_rows(db_path):
    persistence = SqlitePersistence(db_path)
    store = ThreatEventStore(persistence=persistence)
    forecast = _demo_result()
    event = create_threat_event(forecast, as_of=pd.Timestamp("2017-07-07 03:56:00"))
    store.add(event)
    store.clear()

    restarted_store = ThreatEventStore(persistence=SqlitePersistence(db_path))
    assert len(restarted_store) == 0


def test_threat_event_store_duplicate_event_is_not_re_persisted_as_new_row(db_path):
    persistence = SqlitePersistence(db_path)
    store = ThreatEventStore(persistence=persistence)
    forecast = _demo_result()
    event = create_threat_event(forecast, as_of=pd.Timestamp("2017-07-07 03:56:00"))
    assert store.add(event) is True
    assert store.add(event) is False  # deterministic event_id -> duplicate
    assert len(persistence.load_threat_events()) == 1


def test_blockchain_ledger_survives_a_simulated_restart(db_path):
    persistence = SqlitePersistence(db_path)
    ledger = LocalBlockchainLedger(persistence=persistence)
    record = ledger.record_threat({"event_id": "evt_1", "severity": "HIGH"})

    restarted_ledger = LocalBlockchainLedger(persistence=SqlitePersistence(db_path))
    reloaded = restarted_ledger.get_record("evt_1")
    assert reloaded is not None
    assert reloaded["threat_hash"] == record["threat_hash"]


def test_blockchain_ledger_verify_still_works_after_a_simulated_restart(db_path):
    persistence = SqlitePersistence(db_path)
    ledger = LocalBlockchainLedger(persistence=persistence)
    threat_event = {"event_id": "evt_1", "severity": "HIGH"}
    ledger.record_threat(threat_event)

    restarted_ledger = LocalBlockchainLedger(persistence=SqlitePersistence(db_path))
    result = restarted_ledger.verify_threat(threat_event)
    assert result["verified"] is True


def test_blockchain_ledger_clear_also_clears_the_persisted_rows(db_path):
    persistence = SqlitePersistence(db_path)
    ledger = LocalBlockchainLedger(persistence=persistence)
    ledger.record_threat({"event_id": "evt_1"})
    ledger.clear()

    restarted_ledger = LocalBlockchainLedger(persistence=SqlitePersistence(db_path))
    assert restarted_ledger.list_records() == []
