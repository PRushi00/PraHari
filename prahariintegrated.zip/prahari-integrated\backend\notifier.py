"""Administrator alerting: the "alert the network administrator" stage
of the target architecture.

Real, working today: every HIGH/CRITICAL-severity threat event is
recorded to an in-memory alert log (immediately visible via GET
/alerts), so "the administrator gets alerted" is genuinely true for
this local prototype -- there is a real, inspectable alert record, not
just a dashboard color changing.

What is NOT implemented: delivery to an external channel (email, SMS,
push notification, Slack). AlertChannel names that interface so a real
channel can be plugged in later -- exactly the same pattern as
backend/ingestion.py's TrafficSource and backend/pattern_store.py's
PatternStore -- without changing anything that calls notify().
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from typing import Optional

ALERT_SEVERITIES = {"CRITICAL", "HIGH"}


@dataclass
class Alert:
    event_id: str
    timestamp: str
    severity: str
    risk_state: str
    predicted_attack_type: str
    suspicious_source_ip: Optional[str]
    forecast_window_label: str
    channel: str
    delivered: bool
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class AlertChannel(ABC):
    """Interface a real delivery channel (email/SMS/push/Slack) would
    implement. LogAlertChannel (below) is the only implementation in
    this prototype -- it records the alert in-process, it does not send
    anything anywhere."""

    name: str

    @abstractmethod
    def send(self, alert: Alert) -> bool:
        """Attempt delivery; return whether it was "delivered" by this
        channel's own definition."""


class LogAlertChannel(AlertChannel):
    """Honest default: "delivering" an alert means recording it where an
    administrator (or this prototype's own dashboard/API) can see it --
    nothing is actually emailed, texted, or pushed anywhere."""

    name = "log"

    def send(self, alert: Alert) -> bool:
        return True


class AdminNotifier:
    """Turns a CRITICAL/HIGH threat event into a recorded administrator
    alert. Real, in-memory, inspectable -- not a claim of email/SMS/push
    delivery unless a real AlertChannel is swapped in."""

    def __init__(self, channel: Optional[AlertChannel] = None, max_alerts: int = 500):
        self.channel = channel or LogAlertChannel()
        self.max_alerts = max_alerts
        self._alerts: list[Alert] = []

    def notify_if_warranted(self, threat_event: dict) -> Optional[Alert]:
        """Given a ThreatEvent.to_dict(), record an alert if its severity
        warrants one. Returns None (no fabricated alert) for LOW/MEDIUM/
        UNVALIDATED severities -- an administrator should not be alerted
        every single minute for routine or unvalidated readings."""
        severity = threat_event.get("severity")
        if severity not in ALERT_SEVERITIES:
            return None

        suspicious_source = threat_event.get("suspicious_source") or {}
        alert = Alert(
            event_id=threat_event["event_id"],
            timestamp=threat_event["timestamp"],
            severity=severity,
            risk_state=threat_event.get("risk_state", "UNKNOWN"),
            predicted_attack_type=threat_event.get("predicted_attack_type", "unknown"),
            suspicious_source_ip=suspicious_source.get("source_ip"),
            forecast_window_label=(threat_event.get("forecast_window") or {}).get("label", "unknown window"),
            channel=self.channel.name,
            delivered=self.channel.send(threat_event),  # type: ignore[arg-type]
            note="Recorded locally (LogAlertChannel) -- no email/SMS/push integration in this prototype.",
        )
        self._alerts.append(alert)
        if len(self._alerts) > self.max_alerts:
            self._alerts.pop(0)
        return alert

    def list(self, limit: Optional[int] = None) -> list[Alert]:
        """Most-recent-first."""
        ordered = list(reversed(self._alerts))
        return ordered[:limit] if limit is not None else ordered

    def clear(self) -> None:
        self._alerts.clear()

    def __len__(self) -> int:
        return len(self._alerts)
