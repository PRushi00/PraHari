"""Tests for ai/build_window_forecast_dataset.py."""
import pandas as pd
import pytest

from ai.build_window_forecast_dataset import (
    PREDICTOR_COLUMN_ORDER,
    TARGET_COLUMN,
    WINDOW_ATTACK_MINUTES_COLUMN,
    build_window_dataset,
    run_sanity_checks,
)
from ai.build_lagged_forecasting_dataset import PRIMARY_FEATURES, CALENDAR_FEATURES


def _synthetic_full_agg(n_minutes: int, attack_minutes: set[int]) -> pd.DataFrame:
    timestamps = pd.date_range("2017-01-01 00:00:00", periods=n_minutes, freq="1min")
    rows = []
    for i, ts in enumerate(timestamps):
        row = {f: float(i + 1) for f in PRIMARY_FEATURES}
        row["timestamp"] = ts
        row["attack_flows"] = 5 if i in attack_minutes else 0
        row["minute_of_hour"] = ts.minute
        row["hour"] = ts.hour
        rows.append(row)
    return pd.DataFrame(rows)


def test_window_target_flags_any_attack_in_future_window():
    # 20 minutes, single attack at index 10 (0-based). window=5.
    full_agg = _synthetic_full_agg(20, attack_minutes={10})
    dataset, stats = build_window_dataset(full_agg, window_minutes=5)

    row_at_5 = dataset[dataset["timestamp"] == full_agg["timestamp"].iloc[5]].iloc[0]
    assert row_at_5[TARGET_COLUMN] == 1  # window (6..10) includes the attack at 10
    assert row_at_5[WINDOW_ATTACK_MINUTES_COLUMN] == 1

    row_at_10 = dataset[dataset["timestamp"] == full_agg["timestamp"].iloc[10]].iloc[0]
    assert row_at_10[TARGET_COLUMN] == 0  # window (11..15) excludes t=10 itself


def test_window_never_includes_current_minute():
    full_agg = _synthetic_full_agg(20, attack_minutes={7})
    dataset, _ = build_window_dataset(full_agg, window_minutes=5)
    row_at_7 = dataset[dataset["timestamp"] == full_agg["timestamp"].iloc[7]].iloc[0]
    # t=7 itself is an attack minute, but that must NOT count toward its own
    # future-window target (no leakage of the current minute's own label).
    assert row_at_7[TARGET_COLUMN] == 0


def test_rows_dropped_for_incomplete_history_and_future():
    full_agg = _synthetic_full_agg(10, attack_minutes=set())
    dataset, stats = build_window_dataset(full_agg, window_minutes=5)
    # first 2 rows lack full 3-minute lookback; last 5 rows lack a full
    # 5-minute future window.
    assert stats["dropped_incomplete_history"] == 2
    assert stats["dropped_incomplete_future"] == 5
    assert stats["output_rows"] == 10 - 2 - 5
    assert len(dataset) == stats["output_rows"]


def test_predictor_columns_match_shared_lag_construction():
    full_agg = _synthetic_full_agg(15, attack_minutes={12})
    dataset, _ = build_window_dataset(full_agg, window_minutes=3)
    for col in PREDICTOR_COLUMN_ORDER:
        assert col in dataset.columns
    expected_count = 3 * len(PRIMARY_FEATURES) + len(CALENDAR_FEATURES)
    assert len(PREDICTOR_COLUMN_ORDER) == expected_count


def test_sanity_checks_pass_on_well_formed_dataset():
    full_agg = _synthetic_full_agg(40, attack_minutes={20, 21, 22})
    dataset, _ = build_window_dataset(full_agg, window_minutes=10)
    run_sanity_checks(dataset, full_agg, window_minutes=10)  # must not raise


def test_no_nan_and_chronological_order():
    full_agg = _synthetic_full_agg(30, attack_minutes={15})
    dataset, _ = build_window_dataset(full_agg, window_minutes=10)
    assert dataset.isna().sum().sum() == 0
    assert dataset["timestamp"].is_monotonic_increasing
    assert dataset["timestamp"].duplicated().sum() == 0
