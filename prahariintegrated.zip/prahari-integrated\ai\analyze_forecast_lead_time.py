"""Early-Warning Lead Time analysis.

The original PraHari pitch deck's central claim is "not just detection --
forecasting, so an administrator gets advance warning before an attack
escalates." "Lead time" is the honest way to measure that claim: how many
minutes before the real recorded attack onset did a forecasting signal
first raise an alert?

This script computes that number for real, by chronologically replaying
the SAME real recorded CICIDS2017 dataset backend/replay.py replays live,
through the SAME ForecastingService both API modes use -- zero new
modeling, zero new data, nothing recomputed differently than the live
pipeline already computes it minute by minute.

Two numbers are reported, never blended, exactly mirroring the two-mode
split already established everywhere else in this backend:

DEMONSTRATION_MODE
    A rule-based heuristic reacting to the current minute's own traffic
    volume -- not a model forecasting a future attack it hasn't observed
    yet. Its "lead time" measures how many minutes before the recorded
    attack onset this real-time signal first escalates to ELEVATED or
    above, i.e. how much warning an administrator watching this signal
    live would actually have gotten.

VALIDATED_MODEL_MODE
    The trained RandomForest window forecaster. Its "lead time" is
    reported too, but explicitly caveated: this dataset has only one
    attack episode, so the model's own test rows are the tail of the
    SAME episode it trained on. Any lead time measured against them is
    circular, not a validated early-warning claim -- shown for research
    interest only, exactly like every other VALIDATED_MODEL_MODE number
    in this prototype.

Neither number is inflated, averaged across occurrences that don't exist,
or hidden if it comes out zero/negative/absent. Run:

    python ai/analyze_forecast_lead_time.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from ai.config import LEAD_TIME_PATH
from backend.forecasting_service import (
    DEMONSTRATION_MODE,
    RISK_CRITICAL,
    RISK_ELEVATED,
    RISK_HIGH_RISK,
    RISK_NORMAL,
    UNVALIDATED_MODEL_STATUSES,
    VALIDATED_MODEL_MODE,
    ForecastingService,
)
from backend.replay import TrafficReplayEngine

# Only these three risk states count as "an alert was raised" -- RISK_UNVALIDATED
# intentionally has no entry and can never satisfy _first_minute_at_or_above.
RISK_RANK = {RISK_NORMAL: 0, RISK_ELEVATED: 1, RISK_HIGH_RISK: 2, RISK_CRITICAL: 3}
ALERT_MIN_RANK = RISK_RANK[RISK_ELEVATED]

PROBABILITY_ALERT_THRESHOLD = 0.5

DISCLAIMER = (
    "Early-warning lead time measured by chronologically replaying the same single "
    "recorded CICIDS2017 DDoS episode this whole prototype runs on -- both signals below "
    "are read from that ONE episode, never averaged across independent occurrences, so "
    "neither number is a validated real-world guarantee. Reported exactly as computed, "
    "including if a signal never escalates, or escalates only after the attack already began."
)


def build_full_per_minute_dataset() -> pd.DataFrame:
    """Load the exact same replayed, chronologically-ordered per-minute
    dataset the live backend replays (backend/replay.py) -- real
    ground-truth attack_flows labels plus top-talker context, nothing
    recomputed or resampled differently."""
    engine = TrafficReplayEngine()
    if not engine.loaded:
        raise FileNotFoundError(engine.load_error)
    return engine.per_minute_df.sort_values("timestamp").reset_index(drop=True)


def _attack_onset_timestamp(df: pd.DataFrame) -> Optional[pd.Timestamp]:
    """First minute the dataset's own ground truth marks as attack traffic
    (attack_flows > 0) -- the real recorded onset, never a fabricated one."""
    attacked = df[df["attack_flows"] > 0]
    if attacked.empty:
        return None
    return pd.Timestamp(attacked.iloc[0]["timestamp"])


def _first_minute_at_or_above(records: list[dict], min_rank: int) -> Optional[dict]:
    """First record (records assumed chronological) whose risk_state rank
    is >= min_rank. RISK_UNVALIDATED has no RISK_RANK entry and can never
    match here."""
    for record in records:
        rank = RISK_RANK.get(record["risk_state"])
        if rank is not None and rank >= min_rank:
            return record
    return None


def _first_probability_crossing(records: list[dict], threshold: float = PROBABILITY_ALERT_THRESHOLD) -> Optional[dict]:
    """First record (chronological) whose probability is not None and has
    reached threshold."""
    for record in records:
        if record["probability"] is not None and record["probability"] >= threshold:
            return record
    return None


def _lead_time_minutes(onset: Optional[pd.Timestamp], alert_time: Optional[pd.Timestamp]) -> Optional[float]:
    """onset - alert_time in minutes, reported exactly as computed --
    positive means the alert came before the attack (real lead time),
    negative means it came after (no early warning), never clamped."""
    if onset is None or alert_time is None:
        return None
    return round((onset - alert_time).total_seconds() / 60, 2)


def replay_and_score(df: pd.DataFrame, service: ForecastingService) -> tuple[list[dict], list[dict]]:
    """Feed df's rows into service one minute at a time -- the identical
    sequence backend/app.py's _on_minute uses for a live replay -- and
    collect every READY forecast from both modes, in chronological order.
    No new modeling: this reuses the exact same ForecastingService a live
    replay would call, just off-line and all at once."""
    demo_records: list[dict] = []
    validated_records: list[dict] = []

    for _, row in df.iterrows():
        minute_row = row.to_dict()
        minute_row["timestamp"] = pd.Timestamp(minute_row["timestamp"])
        service.observe_minute(minute_row)

        demo_result = service.forecast(DEMONSTRATION_MODE)
        if demo_result.ready:
            demo_records.append({
                "timestamp": minute_row["timestamp"],
                "risk_state": demo_result.risk_state,
                "probability": demo_result.probability,
            })

        validated_result = service.forecast(VALIDATED_MODEL_MODE)
        if validated_result.ready:
            validated_records.append({
                "timestamp": minute_row["timestamp"],
                "risk_state": validated_result.risk_state,
                "probability": validated_result.probability,
                "model_status": validated_result.model_status,
            })

    return demo_records, validated_records


def analyze() -> dict:
    df = build_full_per_minute_dataset()
    onset = _attack_onset_timestamp(df)

    service = ForecastingService()
    demo_records, validated_records = replay_and_score(df, service)

    demo_alert = _first_minute_at_or_above(demo_records, ALERT_MIN_RANK)
    demo_lead_time = _lead_time_minutes(onset, demo_alert["timestamp"] if demo_alert else None)

    validated_model_status = validated_records[0]["model_status"] if validated_records else service.saved_model_status
    validated_alert = _first_probability_crossing(validated_records)
    validated_lead_time = _lead_time_minutes(onset, validated_alert["timestamp"] if validated_alert else None)
    validated_is_unvalidated = validated_model_status in UNVALIDATED_MODEL_STATUSES

    return {
        "attack_onset_timestamp": str(onset) if onset is not None else None,
        "total_minutes_replayed": len(df),
        "demonstration_mode": {
            "mode": DEMONSTRATION_MODE,
            "first_alert_timestamp": str(demo_alert["timestamp"]) if demo_alert else None,
            "first_alert_risk_state": demo_alert["risk_state"] if demo_alert else None,
            "lead_time_minutes": demo_lead_time,
            "note": (
                "Minutes between this real-time heuristic signal first reaching ELEVATED/"
                "HIGH_RISK/CRITICAL and the real recorded attack onset -- i.e. how much warning "
                "an administrator watching this exact signal live would have gotten. The "
                "heuristic reacts to the current minute's own traffic volume; it is not a model "
                "forecasting an attack it has not yet observed, so this is a measured reaction "
                "time, not a claim about detecting attacks before any of their traffic exists."
                if demo_alert is not None else
                "The demonstration heuristic never reached ELEVATED risk anywhere in this "
                "replayed dataset -- no lead time to report."
            ),
        },
        "validated_model_mode": {
            "mode": VALIDATED_MODEL_MODE,
            "model_status": validated_model_status,
            "first_probability_ge_threshold_timestamp": str(validated_alert["timestamp"]) if validated_alert else None,
            "probability_threshold": PROBABILITY_ALERT_THRESHOLD,
            "lead_time_minutes": validated_lead_time,
            "note": (
                f"model_status={validated_model_status}: the test portion of this model's own "
                "training split is the tail of this SAME single episode, so any lead time "
                "measured here is circular (computed against data the model has already partly "
                "seen), not a validated early-warning claim -- shown for research interest only, "
                "alongside the same honest disclaimer already attached to every other "
                "VALIDATED_MODEL_MODE output in this prototype."
                if validated_is_unvalidated else
                "model_status is not one of the known UNVALIDATED statuses -- treat with the "
                "same caution as every other number computed from this single-episode dataset."
            ),
        },
        "disclaimer": DISCLAIMER,
    }


def main() -> None:
    result = analyze()

    LEAD_TIME_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(LEAD_TIME_PATH, "w") as fh:
        json.dump(result, fh, indent=2, default=str)

    print(f"attack onset: {result['attack_onset_timestamp']}")
    print(f"total minutes replayed: {result['total_minutes_replayed']}")

    demo = result["demonstration_mode"]
    print(f"\n[{demo['mode']}] first alert: {demo['first_alert_timestamp']} "
          f"({demo['first_alert_risk_state']})  lead_time_minutes={demo['lead_time_minutes']}")
    print(demo["note"])

    validated = result["validated_model_mode"]
    print(f"\n[{validated['mode']}] model_status={validated['model_status']}  "
          f"first p>={validated['probability_threshold']} at: "
          f"{validated['first_probability_ge_threshold_timestamp']}  "
          f"lead_time_minutes={validated['lead_time_minutes']}")
    print(validated["note"])

    print(f"\nSaved to: {LEAD_TIME_PATH}")
    print("\n" + "=" * 70)
    print(DISCLAIMER)
    print("=" * 70)


if __name__ == "__main__":
    main()
