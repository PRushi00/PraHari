"""Organizational baseline: "current traffic behaviour" vs. "what this
network normally looks like" -- computed once, deterministically, from
the real replayed dataset's own BENIGN-labeled minutes (ground truth
already present in the dataset, never fabricated).

This is a plain descriptive statistic (mean/std per feature over the
non-attack minutes), not a model and not a claim of organizational scale
-- it exists so the dashboard can show "current" next to "normal" instead
of only an isolated number, and so the demonstration heuristic's rolling
window has a stable, labeled point of comparison alongside it.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

BASELINE_FEATURES = [
    "total_flows",
    "unique_source_ips",
    "unique_destination_ports",
]


@dataclass
class OrganizationalBaseline:
    available: bool
    sample_minutes: int
    means: dict = field(default_factory=dict)
    stdevs: dict = field(default_factory=dict)
    note: str = ""

    @classmethod
    def unavailable(cls, note: str) -> "OrganizationalBaseline":
        return cls(available=False, sample_minutes=0, note=note)

    @classmethod
    def from_history(cls, per_minute_df: Optional[pd.DataFrame]) -> "OrganizationalBaseline":
        """Build the baseline from every minute the replayed dataset's own
        label marks BENIGN (attack_flows == 0) -- real ground truth from
        the dataset, used only for descriptive baseline stats, never given
        to either forecasting model as an input."""
        if per_minute_df is None or "attack_flows" not in per_minute_df.columns:
            return cls.unavailable("no labeled history available to compute a baseline from")

        normal = per_minute_df[per_minute_df["attack_flows"] == 0]
        if len(normal) < 5:
            return cls.unavailable(f"only {len(normal)} labeled-normal minutes available -- too few for a stable baseline")

        means, stdevs = {}, {}
        for feature in BASELINE_FEATURES:
            if feature not in normal.columns:
                continue
            values = [float(v) for v in normal[feature].tolist()]
            means[feature] = statistics.fmean(values)
            stdevs[feature] = statistics.pstdev(values) or 1e-9

        return cls(
            available=True,
            sample_minutes=len(normal),
            means=means,
            stdevs=stdevs,
            note=(
                f"Computed from {len(normal)} minutes labeled BENIGN in the replayed "
                "CICIDS2017 dataset itself -- a real, deterministic descriptive baseline, "
                "not a learned model and not a claim of live organizational deployment."
            ),
        )

    def compare(self, current_minute: Optional[dict]) -> dict:
        """Return {feature: {current, normal_mean, deviation_ratio, status}}
        plus an overall verdict -- current vs. organizational normal."""
        if not self.available or not current_minute:
            return {
                "available": False,
                "note": self.note or "no current traffic observed yet",
                "features": {},
                "overall_status": "UNKNOWN",
            }

        features = {}
        max_ratio = 0.0
        for feature in BASELINE_FEATURES:
            if feature not in self.means or feature not in current_minute:
                continue
            current = float(current_minute[feature])
            mean = self.means[feature]
            stdev = self.stdevs[feature]
            ratio = abs(current - mean) / stdev
            max_ratio = max(max_ratio, ratio)
            features[feature] = {
                "current": current,
                "normal_mean": round(mean, 2),
                "deviation_std_devs": round(ratio, 2),
                "status": "ABOVE_NORMAL" if current > mean + stdev else ("BELOW_NORMAL" if current < mean - stdev else "WITHIN_NORMAL"),
            }

        if max_ratio >= 3.0:
            overall = "FAR_ABOVE_NORMAL"
        elif max_ratio >= 1.5:
            overall = "ABOVE_NORMAL"
        else:
            overall = "WITHIN_NORMAL"

        return {
            "available": True,
            "note": self.note,
            "sample_minutes": self.sample_minutes,
            "features": features,
            "overall_status": overall,
        }
