"""Tests for backend/baseline.py."""
import pandas as pd

from backend.baseline import OrganizationalBaseline


def _synthetic_history():
    rows = []
    for i in range(10):
        rows.append({
            "timestamp": pd.Timestamp("2017-07-07 03:00:00") + pd.Timedelta(minutes=i),
            "total_flows": 100 + i,  # 100..109, clearly BENIGN
            "unique_source_ips": 10,
            "unique_destination_ports": 5,
            "attack_flows": 0,
        })
    # one attack-labeled minute -- must be excluded from the baseline
    rows.append({
        "timestamp": pd.Timestamp("2017-07-07 03:10:00"),
        "total_flows": 9000, "unique_source_ips": 60, "unique_destination_ports": 5,
        "attack_flows": 500,
    })
    return pd.DataFrame(rows)


def test_unavailable_without_history():
    baseline = OrganizationalBaseline.from_history(None)
    assert baseline.available is False


def test_unavailable_with_too_few_normal_minutes():
    df = pd.DataFrame([{"timestamp": pd.Timestamp("2017-01-01"), "total_flows": 1, "attack_flows": 0}])
    baseline = OrganizationalBaseline.from_history(df)
    assert baseline.available is False


def test_baseline_computed_only_from_benign_minutes():
    baseline = OrganizationalBaseline.from_history(_synthetic_history())
    assert baseline.available is True
    assert baseline.sample_minutes == 10  # the one attack-labeled minute excluded
    assert 100 <= baseline.means["total_flows"] <= 110


def test_compare_flags_a_far_above_normal_reading():
    baseline = OrganizationalBaseline.from_history(_synthetic_history())
    result = baseline.compare({"total_flows": 9000, "unique_source_ips": 60, "unique_destination_ports": 5})
    assert result["available"] is True
    assert result["overall_status"] == "FAR_ABOVE_NORMAL"
    assert result["features"]["total_flows"]["status"] == "ABOVE_NORMAL"


def test_compare_reports_within_normal_for_typical_traffic():
    baseline = OrganizationalBaseline.from_history(_synthetic_history())
    result = baseline.compare({"total_flows": 104, "unique_source_ips": 10, "unique_destination_ports": 5})
    assert result["overall_status"] == "WITHIN_NORMAL"


def test_compare_handles_no_current_minute():
    baseline = OrganizationalBaseline.from_history(_synthetic_history())
    result = baseline.compare(None)
    assert result["available"] is False
