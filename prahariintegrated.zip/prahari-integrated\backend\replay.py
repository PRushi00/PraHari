"""Local traffic replay engine: the "Network/Traffic Replay" stage of the
MVP pipeline.

Reads the already-cleaned, already-labeled flow-level dataset
(data/processed/cleaned.csv, produced by ai/preprocess.py) and replays it
one chronological minute at a time, reusing the EXACT per-minute
aggregation function from ai/build_forecasting_dataset.py
(aggregate_per_minute) so a replayed minute's features are identical in
shape and meaning to what the model was trained on.

This is a local file replay, not a live packet capture -- appropriate for
a one-day MVP demonstrating the forecasting pipeline end-to-end on the
existing research dataset. It deliberately does not fabricate any new
traffic or timestamps.

Phase 2 addition: alongside the aggregate traffic statistics, each
replayed minute also carries a "top talker" summary -- which source IP,
destination IP/port, and protocol accounted for the most flows THAT
MINUTE. This is a plain, deterministic volume computation over real flow
records (no learning, no label use) -- it exists to give the dashboard a
genuine "suspicious source/asset" to display as supporting context,
without claiming the forecasting model itself does any source-level
learning (it doesn't; it operates on per-minute aggregate statistics
only, same as before).
"""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from typing import Callable, Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from ai.build_forecasting_dataset import aggregate_per_minute
from ai.config import (
    CLEANED_DATA_PATH,
    DEST_IP_CANDIDATES,
    DEST_PORT_CANDIDATES,
    PROTOCOL_CANDIDATES,
    SOURCE_IP_CANDIDATES,
)
from ai.preprocess import detect_label_column, detect_timestamp_column
from backend.ingestion import TrafficSource

TOP_N_SOURCES = 3

NO_TOP_TALKER = {
    "top_source_ip": None,
    "top_source_ip_flow_count": None,
    "top_source_ip_flow_share": None,
    "top_destination_ip": None,
    "top_destination_port": None,
    "top_sources": [],
    "top_talker_note": "source/destination columns not available in this dataset",
}


def _first_present(columns: list[str], candidates: list[str]) -> Optional[str]:
    for c in candidates:
        if c in columns:
            return c
    return None


def compute_top_talkers_per_minute(df: pd.DataFrame, timestamp_col: str) -> pd.DataFrame:
    """One row per minute: the single most active source IP (by flow
    count), its share of that minute's total flows, and the most common
    destination IP/port that minute. Purely a volume tally over real flow
    records -- never uses the label column, never learned."""
    columns = list(df.columns)
    src_col = _first_present(columns, SOURCE_IP_CANDIDATES)
    dst_col = _first_present(columns, DEST_IP_CANDIDATES)
    port_col = _first_present(columns, DEST_PORT_CANDIDATES)

    if src_col is None:
        return pd.DataFrame(columns=[timestamp_col] + list(NO_TOP_TALKER.keys()))

    rows = []
    for ts, group in df.groupby(timestamp_col):
        total = len(group)
        src_counts = group[src_col].value_counts()
        top_source_ip = src_counts.index[0]
        top_source_count = int(src_counts.iloc[0])

        # Multiple suspicious entities (Priority 3): the top N source IPs by
        # flow count this minute, not only the single dominant one -- so the
        # architecture can represent several suspicious sources even though
        # the demo dashboard highlights the strongest.
        top_sources = [
            {
                "rank": i + 1,
                "source_ip": ip,
                "flow_count": int(count),
                "flow_share": round(int(count) / total, 4) if total else 0.0,
            }
            for i, (ip, count) in enumerate(src_counts.head(TOP_N_SOURCES).items())
        ]

        row = {
            timestamp_col: ts,
            "top_source_ip": top_source_ip,
            "top_source_ip_flow_count": top_source_count,
            "top_source_ip_flow_share": round(top_source_count / total, 4) if total else 0.0,
            "top_destination_ip": group[dst_col].value_counts().index[0] if dst_col else None,
            "top_destination_port": (
                int(group[port_col].value_counts().index[0]) if port_col else None
            ),
            "top_sources": top_sources,
            "top_talker_note": None,
        }
        rows.append(row)

    return pd.DataFrame(rows)


class TrafficReplayEngine(TrafficSource):
    """Steps through the cleaned dataset's per-minute aggregation one
    minute at a time, in real recorded chronological order. Implements
    the TrafficSource interface (backend/ingestion.py) so the rest of the
    backend depends on "a traffic source", not specifically on replay --
    a future live-capture source could implement the same interface
    without the forecasting/threat/blockchain code changing."""

    def __init__(self, cleaned_csv_path: Path = CLEANED_DATA_PATH):
        self.cleaned_csv_path = cleaned_csv_path
        self.per_minute_df: Optional[pd.DataFrame] = None
        self.load_error: Optional[str] = None
        self.index = 0
        self._load()

    def _load(self) -> None:
        if not self.cleaned_csv_path.exists():
            self.load_error = (
                f"{self.cleaned_csv_path} not found. Run `python ai/preprocess.py` first."
            )
            return
        try:
            df = pd.read_csv(self.cleaned_csv_path, low_memory=False)
            timestamp_col = detect_timestamp_column(df) or "timestamp"
            detect_label_column(df)  # validated to exist upstream; not used directly here
            df[timestamp_col] = pd.to_datetime(df[timestamp_col])

            per_minute_df = aggregate_per_minute(df, timestamp_col)
            top_talkers = compute_top_talkers_per_minute(df, timestamp_col)
            if not top_talkers.empty:
                per_minute_df = per_minute_df.merge(
                    top_talkers, left_on="timestamp", right_on=timestamp_col, how="left"
                )
                if timestamp_col != "timestamp" and timestamp_col in per_minute_df.columns:
                    per_minute_df = per_minute_df.drop(columns=[timestamp_col])
            else:
                for key, value in NO_TOP_TALKER.items():
                    per_minute_df[key] = value
            self.per_minute_df = per_minute_df
        except Exception as exc:  # pragma: no cover - defensive
            self.load_error = f"failed to load/aggregate {self.cleaned_csv_path}: {exc}"

    @property
    def loaded(self) -> bool:
        return self.per_minute_df is not None

    @property
    def total_minutes(self) -> int:
        return 0 if self.per_minute_df is None else len(self.per_minute_df)

    @property
    def finished(self) -> bool:
        return self.index >= self.total_minutes

    def reset(self) -> None:
        self.index = 0

    def step(self) -> Optional[dict]:
        """Return the next chronological minute's aggregated row as a
        plain dict (with a native datetime timestamp), or None once the
        replay has reached the end of the real recorded dataset."""
        if self.per_minute_df is None or self.finished:
            return None
        row = self.per_minute_df.iloc[self.index].to_dict()
        row["timestamp"] = pd.Timestamp(row["timestamp"])
        self.index += 1
        return row

    def run(
        self,
        on_minute: Callable[[dict, int, int], None],
        minutes_per_second: float = 2.0,
        max_minutes: Optional[int] = None,
    ) -> None:
        """Synchronous replay loop for CLI/demo use: calls on_minute(row,
        index, total) once per replayed minute, sleeping between steps so
        the replay proceeds at a fixed, human-watchable pace rather than
        instantaneously. Does not run forever -- stops at the end of the
        real recorded dataset (or after max_minutes, if given)."""
        delay = 1.0 / minutes_per_second if minutes_per_second > 0 else 0.0
        count = 0
        while True:
            if max_minutes is not None and count >= max_minutes:
                break
            row = self.step()
            if row is None:
                break
            on_minute(row, self.index, self.total_minutes)
            count += 1
            if delay:
                time.sleep(delay)

    async def run_async(
        self,
        on_minute: Callable[[dict, int, int], None],
        minutes_per_second: float = 2.0,
        stop_event: Optional[asyncio.Event] = None,
    ) -> None:
        """Async version of run(), for embedding in a FastAPI background
        task. Checks stop_event before each step so a caller can cancel
        the replay between minutes."""
        delay = 1.0 / minutes_per_second if minutes_per_second > 0 else 0.0
        while True:
            if stop_event is not None and stop_event.is_set():
                break
            row = self.step()
            if row is None:
                break
            on_minute(row, self.index, self.total_minutes)
            if delay:
                await asyncio.sleep(delay)
