#!/usr/bin/env bash
# End-to-end demonstration runner for the AI Network Attack Forecasting MVP.
#
# Orchestrates the EXISTING components over their EXISTING API contracts --
# it does not duplicate any forecasting/replay/threat/blockchain logic, it
# only calls the same endpoints frontend/app.js calls:
#
#   FastAPI backend -> dashboard -> replay -> forecast -> threat event
#   -> blockchain record -> verification
#
# Run:
#   ./demo/run_demo.sh
#
# Stop:
#   Ctrl+C -- cleans up only the two processes this script started
#   (the backend and the dashboard's static file server), nothing else.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

BACKEND_HOST="127.0.0.1"
BACKEND_PORT="8000"
BACKEND_URL="http://${BACKEND_HOST}:${BACKEND_PORT}"
DASHBOARD_PORT="8080"
DASHBOARD_URL="http://127.0.0.1:${DASHBOARD_PORT}"

# Security role (backend/security.py): state-changing endpoints require
# this shared API key. Defaults to the backend's own demo/local default
# (PRAHARI_API_KEY) -- override both consistently if you change one.
API_KEY="${PRAHARI_API_KEY:-demo-local-admin-key}"

# DEMONSTRATION_MODE drives this script's visible walkthrough because it's
# the mode that actually responds to the replayed traffic -- the real
# trained model (VALIDATED_MODEL_MODE) is still queried and reported below,
# honestly, exactly as the backend returns it (see step [3]).
DEMO_MODE="DEMONSTRATION_MODE"
REPLAY_SPEED="8"   # minutes_per_second
ATTACK_RATIO_THRESHOLD="0.3"
WAIT_FOR_ATTACK_TIMEOUT_S="90"

BACKEND_PID=""
DASHBOARD_PID=""
CLEANED_UP=0

cleanup() {
    if [ "$CLEANED_UP" -eq 1 ]; then
        return
    fi
    CLEANED_UP=1
    echo
    echo "Stopping demo -- cleaning up only the processes this script started..."
    if [ -n "$DASHBOARD_PID" ] && kill -0 "$DASHBOARD_PID" 2>/dev/null; then
        kill "$DASHBOARD_PID" 2>/dev/null
        wait "$DASHBOARD_PID" 2>/dev/null
        echo "  dashboard server stopped (pid $DASHBOARD_PID)"
    fi
    if [ -n "$BACKEND_PID" ] && kill -0 "$BACKEND_PID" 2>/dev/null; then
        kill "$BACKEND_PID" 2>/dev/null
        wait "$BACKEND_PID" 2>/dev/null
        echo "  backend stopped (pid $BACKEND_PID)"
    fi
    echo "Logs kept at: $LOG_DIR"
    exit 0
}
trap cleanup INT TERM

# Reads JSON from stdin, evaluates a python expression against it as 'd',
# prints '' on any error (missing key, invalid JSON, empty input) instead
# of ever fabricating a value.
json_field() {
    python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    v = ($1)
    print(v if v is not None else '')
except Exception:
    print('')
"
}

echo "AI Network Attack Forecasting Prototype"
echo "Environment: Fedora / Local"
echo "Backend: starting"
echo "Blockchain: local"
echo "Forecasting: ready"
echo "Dashboard: starting"
echo "Mode: ${DEMO_MODE}"
echo

# --- 1. Verify environment -------------------------------------------------
command -v curl >/dev/null 2>&1 || { echo "ERROR: curl not found."; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 not found."; exit 1; }

if [ ! -d "$PROJECT_ROOT/.venv" ]; then
    echo "ERROR: .venv not found. Run:"
    echo "  python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
    exit 1
fi
# shellcheck disable=SC1091
source "$PROJECT_ROOT/.venv/bin/activate"

MISSING=0
for pkg in fastapi uvicorn web3 sklearn pandas joblib; do
    python3 -c "import $pkg" >/dev/null 2>&1 || { echo "ERROR: required package '$pkg' not importable. Run: pip install -r requirements.txt"; MISSING=1; }
done
[ "$MISSING" -eq 1 ] && exit 1

for artifact in data/processed/cleaned.csv data/processed/window_random_forest.joblib data/processed/window_metrics.json; do
    if [ ! -f "$PROJECT_ROOT/$artifact" ]; then
        echo "ERROR: missing $artifact"
        echo "Run the pipeline first: python ai/preprocess.py && python ai/build_forecasting_dataset.py \\"
        echo "  && python ai/build_lagged_forecasting_dataset.py && python ai/build_window_forecast_dataset.py \\"
        echo "  && python ai/train_window_forecaster.py"
        exit 1
    fi
done

LOG_DIR="$(mktemp -d /tmp/ai-network-forecast-demo.XXXXXX)"
echo "Environment OK. Logs: $LOG_DIR"
echo

# --- 2. Start FastAPI backend ------------------------------------------------
nohup uvicorn backend.app:app --host "$BACKEND_HOST" --port "$BACKEND_PORT" \
    > "$LOG_DIR/backend.log" 2>&1 &
BACKEND_PID=$!

echo "Waiting for backend to become healthy..."
READY=0
for _ in $(seq 1 30); do
    if curl -sS --max-time 2 "$BACKEND_URL/status" > "$LOG_DIR/status.json" 2>/dev/null; then
        sys_status="$(json_field "d.get('system_status')" < "$LOG_DIR/status.json")"
        if [ -n "$sys_status" ]; then
            READY=1
            break
        fi
    fi
    sleep 1
done
if [ "$READY" -ne 1 ]; then
    echo "ERROR: backend did not become healthy within 30s. See $LOG_DIR/backend.log"
    cleanup
fi

model_loaded="$(json_field "d['model']['model_loaded']" < "$LOG_DIR/status.json")"
train_single_class="$(json_field "d['model']['train_single_class']" < "$LOG_DIR/status.json")"
blockchain_available="$(json_field "d['blockchain']['available']" < "$LOG_DIR/status.json")"
echo "[1] Backend started (system_status=$sys_status, model_loaded=$model_loaded, blockchain_available=$blockchain_available)"

# --- 3. Serve the existing dashboard (static files, no framework) ----------
(
    cd "$PROJECT_ROOT/frontend"
    nohup python3 -m http.server "$DASHBOARD_PORT" --bind 127.0.0.1 > "$LOG_DIR/dashboard.log" 2>&1 &
    echo $! > "$LOG_DIR/dashboard.pid"
)
DASHBOARD_PID="$(cat "$LOG_DIR/dashboard.pid")"
sleep 1
echo "Dashboard: ${DASHBOARD_URL}/index.html"
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "${DASHBOARD_URL}/index.html" >/dev/null 2>&1 &
fi
echo

# --- 4. Reset any old replay/threat/blockchain state -----------------------
curl -sS -X POST "$BACKEND_URL/replay/stop" -H "X-API-Key: ${API_KEY}" >/dev/null 2>&1
curl -sS -X POST "$BACKEND_URL/replay/reset" -H "X-API-Key: ${API_KEY}" > "$LOG_DIR/reset.json" 2>&1

# --- 5. Start the deterministic replay via the existing endpoint ----------
curl -sS -X POST "$BACKEND_URL/replay/start" \
    -H "X-API-Key: ${API_KEY}" -H "Content-Type: application/json" \
    -d "{\"minutes_per_second\": ${REPLAY_SPEED}}" > "$LOG_DIR/replay_start.json"
started_speed="$(json_field "d.get('minutes_per_second')" < "$LOG_DIR/replay_start.json")"
echo "[2] Replay started (${started_speed} minutes/second, real recorded CICIDS2017 dataset)"

# --- 6. Wait for forecasting to become active, and for the REAL historical
#        attack interval to be reached (never inferred, always polled) ------
echo "Waiting for forecasting to activate and the real historical attack interval..."
forecast_active_printed=0
attack_reached=0
elapsed=0
poll_interval="0.3"
max_polls=$(python3 -c "print(int(${WAIT_FOR_ATTACK_TIMEOUT_S} / ${poll_interval}))")

for _ in $(seq 1 "$max_polls"); do
    sleep "$poll_interval"

    traffic_json="$(curl -sS --max-time 2 "$BACKEND_URL/traffic/current" 2>/dev/null)"
    echo "$traffic_json" > "$LOG_DIR/traffic_last.json"
    ts="$(echo "$traffic_json" | json_field "d.get('observed_traffic',{}).get('timestamp')")"
    ratio="$(echo "$traffic_json" | json_field "d.get('ground_truth_label_for_this_minute',{}).get('attack_ratio')")"

    if [ "$forecast_active_printed" -eq 0 ] && [ -n "$ts" ]; then
        fc_json="$(curl -sS --max-time 2 "$BACKEND_URL/forecast?mode=${DEMO_MODE}")"
        ready="$(echo "$fc_json" | json_field "d.get('ready')")"
        if [ "$ready" = "True" ]; then
            fc_model_status="$(echo "$fc_json" | json_field "d.get('model_status')")"
            fc_risk_state="$(echo "$fc_json" | json_field "d.get('risk_state')")"
            fc_window_label="$(echo "$fc_json" | json_field "d.get('forecast_window',{}).get('label')")"
            echo "[3] Forecasting active (mode=${DEMO_MODE}, model_status=${fc_model_status}, risk_state=${fc_risk_state}, window=${fc_window_label})"

            validated_json="$(curl -sS --max-time 2 "$BACKEND_URL/forecast?mode=VALIDATED_MODEL_MODE")"
            v_prob="$(echo "$validated_json" | json_field "d.get('probability')")"
            v_status="$(echo "$validated_json" | json_field "d.get('model_status')")"
            v_risk_state="$(echo "$validated_json" | json_field "d.get('risk_state')")"
            echo "    (for honest comparison -- VALIDATED_MODEL_MODE real trained model: probability=${v_prob}, model_status=${v_status}, risk_state=${v_risk_state})"
            forecast_active_printed=1
        fi
    fi

    if [ -n "$ratio" ] && python3 -c "import sys; sys.exit(0 if float('$ratio') >= ${ATTACK_RATIO_THRESHOLD} else 1)" 2>/dev/null; then
        echo "    real historical attack interval reached: timestamp=${ts} attack_ratio=${ratio}"
        attack_reached=1
        break
    fi

    status_json="$(curl -sS --max-time 2 "$BACKEND_URL/status")"
    finished="$(echo "$status_json" | json_field "d['replay']['finished']")"
    if [ "$finished" = "True" ]; then
        echo "    replay reached the end of the dataset."
        break
    fi
done
if [ "$attack_reached" -eq 0 ]; then
    echo "    (attack interval not reached within timeout -- continuing with whatever traffic is current)"
fi

# --- 7. Generate the threat event via the existing endpoint ---------------
gen_json="$(curl -sS -X POST "$BACKEND_URL/threats/generate?mode=${DEMO_MODE}" -H "X-API-Key: ${API_KEY}")"
event_id="$(echo "$gen_json" | json_field "d.get('event',{}).get('event_id')")"
severity="$(echo "$gen_json" | json_field "d.get('event',{}).get('severity')")"
event_model_status="$(echo "$gen_json" | json_field "d.get('event',{}).get('model_status')")"
event_risk_state="$(echo "$gen_json" | json_field "d.get('event',{}).get('risk_state')")"
event_source_ip="$(echo "$gen_json" | json_field "d.get('event',{}).get('suspicious_source',{}).get('source_ip') if d.get('event',{}).get('suspicious_source') else None")"
event_action="$(echo "$gen_json" | json_field "(d.get('event',{}).get('recommended_actions') or [None])[0]")"

if [ -z "$event_id" ]; then
    reason="$(echo "$gen_json" | json_field "d.get('reason')")"
    echo "[4] No threat event generated yet (${reason})"
else
    echo "[4] Threat event generated (event_id=${event_id}, severity=${severity}, risk_state=${event_risk_state}, model_status=${event_model_status})"
    [ -n "$event_source_ip" ] && echo "    suspicious source: ${event_source_ip}"
    [ -n "$event_action" ] && echo "    recommended action: ${event_action}"
fi

# --- 8. Record on the existing local blockchain ----------------------------
if [ -n "$event_id" ]; then
    rec_json="$(curl -sS -X POST "$BACKEND_URL/blockchain/record" \
        -H "X-API-Key: ${API_KEY}" -H "Content-Type: application/json" -d "{\"event_id\": \"${event_id}\"}")"
    chain_status="$(echo "$rec_json" | json_field "d.get('chain_status')")"
    tx_id="$(echo "$rec_json" | json_field "d.get('blockchain_transaction_id')")"
    block_number="$(echo "$rec_json" | json_field "d.get('block_number')")"

    if [ "$chain_status" = "CONFIRMED" ]; then
        echo "[5] Blockchain record confirmed (tx=${tx_id}, block=${block_number})"
    else
        echo "[5] Blockchain record status: ${chain_status} (not a confirmed on-chain record -- reporting exactly what the backend returned)"
    fi

    # --- 9. Verify via the existing endpoint -------------------------------
    verify_json="$(curl -sS -X POST "$BACKEND_URL/blockchain/verify/${event_id}")"
    verified="$(echo "$verify_json" | json_field "d.get('verified')")"
    if [ "$verified" = "True" ]; then
        echo "[6] Threat verification successful (event_id=${event_id})"
    else
        verify_reason="$(echo "$verify_json" | json_field "d.get('reason')")"
        echo "[6] Threat verification result: NOT VERIFIED (${verify_reason})"
    fi
fi

echo
echo "=================================================================="
echo "Demo is live. Dashboard: ${DASHBOARD_URL}/index.html"
echo "The dashboard keeps polling the backend on its own and will keep"
echo "advancing replay/forecast/threat/blockchain state as it runs."
echo "The SECURITY FORECAST hero shows the whole story at a glance: current"
echo "risk, predicted attack, forecast window, suspicious source/asset, why"
echo "it was flagged, recommended actions, and blockchain proof. A toggle"
echo "switches it between the Live Heuristic Signal (DEMONSTRATION_MODE)"
echo "and the Trained AI Model (VALIDATED_MODEL_MODE, honestly UNVALIDATED)"
echo "-- both are always computed, never blended. Every raw number and"
echo "validation caveat is one click away under Technical & Validation"
echo "Details."
echo "Press Ctrl+C to stop the demo and clean up."
echo "=================================================================="
echo

wait "$BACKEND_PID" "$DASHBOARD_PID"
cleanup
