"""Tests for backend/security.py and its wiring into backend/app.py."""
import asyncio
import time

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from backend.security import (
    API_KEY,
    API_KEY_HEADER,
    RateLimitMiddleware,
    require_api_key,
)


@pytest.fixture()
def app_client():
    from backend.app import app, state

    with TestClient(app, headers={API_KEY_HEADER: API_KEY}) as c:
        yield c
        if state.replay_task is not None and not state.replay_task.done():
            state.stop_event.set()
        state.threats.clear()
        state.ledger.clear()
        state.notifier.clear()


def test_mutating_endpoint_rejects_missing_api_key():
    from backend.app import app

    with TestClient(app) as c:  # no default header
        res = c.post("/replay/stop")
        assert res.status_code == 401


def test_mutating_endpoint_rejects_wrong_api_key():
    from backend.app import app

    with TestClient(app, headers={API_KEY_HEADER: "wrong-key"}) as c:
        res = c.post("/replay/stop")
        assert res.status_code == 401


def test_mutating_endpoint_accepts_correct_api_key(app_client):
    res = app_client.post("/replay/stop")
    assert res.status_code == 200


def test_read_only_endpoints_stay_open_without_a_key():
    from backend.app import app

    with TestClient(app) as c:  # no api key at all
        assert c.get("/status").status_code == 200
        assert c.get("/forecast").status_code == 200
        assert c.get("/baseline").status_code == 200
        assert c.get("/alerts").status_code == 200


def test_responses_carry_security_headers(app_client):
    res = app_client.get("/status")
    assert res.headers["x-content-type-options"] == "nosniff"
    assert res.headers["x-frame-options"] == "DENY"
    assert res.headers["referrer-policy"] == "no-referrer"


def test_rate_limit_middleware_blocks_after_the_configured_max():
    app = FastAPI()
    app.add_middleware(RateLimitMiddleware, max_requests=3, window_seconds=10.0)

    @app.get("/ping")
    def ping():
        return {"ok": True}

    with TestClient(app) as c:
        for _ in range(3):
            assert c.get("/ping").status_code == 200
        blocked = c.get("/ping")
        assert blocked.status_code == 429


def test_rate_limit_window_expires():
    app = FastAPI()
    app.add_middleware(RateLimitMiddleware, max_requests=2, window_seconds=0.2)

    @app.get("/ping")
    def ping():
        return {"ok": True}

    with TestClient(app) as c:
        assert c.get("/ping").status_code == 200
        assert c.get("/ping").status_code == 200
        assert c.get("/ping").status_code == 429
        time.sleep(0.25)
        assert c.get("/ping").status_code == 200


def test_require_api_key_dependency_directly():
    with pytest.raises(HTTPException):
        asyncio.run(require_api_key(x_api_key="not-the-real-key"))
    # correct key does not raise
    asyncio.run(require_api_key(x_api_key=API_KEY))
