# PRAHARI -- one-command run for Windows (PowerShell)
#
#   Right-click this file -> "Run with PowerShell"
#   or from a terminal:  powershell -ExecutionPolicy Bypass -File run.ps1
#
# It creates a local virtual environment (first run only), installs the
# dependencies, starts the FastAPI backend on port 8000, and opens the
# PRAHARI dashboard in your browser. The dashboard and the API are served
# by the same process -- there is nothing else to start.
#
# NOTE: ErrorActionPreference is intentionally "Continue" -- Windows
# PowerShell 5.1 otherwise treats any text a native program prints to
# stderr (e.g. a Python "ModuleNotFoundError" from a probe) as a fatal
# error and aborts the script. We check $LASTEXITCODE explicitly instead.

$ErrorActionPreference = "Continue"
Set-Location -Path $PSScriptRoot

$venvDir    = Join-Path $PSScriptRoot ".venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"
$script:BasePy = $null

function Find-BasePython {
    if ($script:BasePy) { return $script:BasePy }
    foreach ($cand in @(@("py","-3.12"), @("py","-3"), @("python"), @("python3"))) {
        $exe = $cand[0]
        if (Get-Command $exe -ErrorAction SilentlyContinue) {
            & $exe @($cand[1..($cand.Length-1)]) --version *>$null
            if ($LASTEXITCODE -eq 0) { $script:BasePy = $cand; return $cand }
        }
    }
    Write-Host "No Python 3 interpreter found. Install Python 3.11+ from https://www.python.org/downloads/" -ForegroundColor Red
    exit 1
}

function New-Venv {
    param([switch]$SystemSitePackages)
    if (Test-Path $venvDir) { Remove-Item -Recurse -Force $venvDir }
    $py = Find-BasePython
    $venvArgs = @("-m","venv",".venv")
    if ($SystemSitePackages) { $venvArgs = @("-m","venv","--system-site-packages",".venv") }
    & $py[0] @($py[1..($py.Length-1)] + $venvArgs)
    if ($LASTEXITCODE -ne 0) { Write-Host "venv creation failed." -ForegroundColor Red; exit 1 }
}

function Test-Import {
    param([string]$Modules)
    & $venvPython -c "import $Modules" *>$null
    return ($LASTEXITCODE -eq 0)
}

# ---- [1/3] virtualenv ------------------------------------------------------
if (-not (Test-Path $venvPython)) {
    Write-Host "[1/3] Creating virtual environment (.venv) ..." -ForegroundColor Cyan
    New-Venv
} else {
    Write-Host "[1/3] Virtual environment already present." -ForegroundColor Cyan
}

# ---- [2/3] dependencies --------------------------------------------------
if (Test-Import "fastapi, sklearn, web3, pandas") {
    Write-Host "[2/3] Dependencies already installed." -ForegroundColor Cyan
} else {
    Write-Host "[2/3] Installing dependencies (first run can take a few minutes) ..." -ForegroundColor Cyan
    & $venvPython -m pip install --upgrade pip   # modern pip auto-allows eth-tester's beta-only releases
    & $venvPython -m pip install -r requirements.txt

    # On some locked-down Windows machines, "Smart App Control" blocks
    # freshly-downloaded compiled wheels (numpy / scipy / scikit-learn).
    # If that happened, rebuild the venv so it re-uses the packages already
    # present -- and already trusted -- in your base Python, and install
    # only the pure-Python extras on top.
    if (-not (Test-Import "numpy, scipy, sklearn, pandas")) {
        Write-Host "    ! compiled packages blocked by a system policy -- retrying against base Python ..." -ForegroundColor Yellow
        New-Venv -SystemSitePackages
        & $venvPython -m pip install --upgrade pip
        & $venvPython -m pip install web3 eth-tester py-evm fastapi uvicorn "pydantic>=2" httpx
    }

    if (-not (Test-Import "fastapi, pandas, sklearn")) {
        Write-Host ""
        Write-Host "Could not import the core stack." -ForegroundColor Red
        Write-Host "Install it once into your BASE Python, then re-run this script:" -ForegroundColor Red
        Write-Host "    py -3.12 -m pip install numpy scipy scikit-learn pandas joblib fastapi uvicorn" -ForegroundColor Red
        Write-Host "If it is Windows 'Smart App Control' blocking the .pyd files, turn it off in" -ForegroundColor Red
        Write-Host "Settings > Privacy and security > Windows Security > App and browser control." -ForegroundColor Red
        exit 1
    }
}

# ---- [3/3] serve -------------------------------------------------------
Write-Host "[3/3] Starting PRAHARI on http://127.0.0.1:8000/  (Ctrl+C to stop)" -ForegroundColor Cyan
Start-Process "http://127.0.0.1:8000/"
& $venvPython -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
