"""Tests for backend/threat_service.py."""
import pandas as pd
import pytest

from backend.forecasting_service import (
    DEMONSTRATION_MODE,
    ForecastResult,
    VALIDATED_MODEL_MODE,
)
from backend.threat_service import (
    RECOMMENDATIONS,
    ThreatEventStore,
    compute_severity,
    create_threat_event,
)

TS = pd.Timestamp("2017-07-07 03:56:00")

FORECAST_WINDOW = {
    "horizon_minutes": 30,
    "window_start_offset_minutes": 1,
    "window_end_offset_minutes": 30,
    "label": "next 30 minutes",
}


def _validated_result(probability, model_status="TRAINED", ready=True, attack_type="none", confidence=0.9,
                       suspicious_source=None, evidence=None):
    return ForecastResult(
        mode=VALIDATED_MODEL_MODE,
        probability=probability,
        attack_type=attack_type,
        model_status=model_status,
        confidence=confidence,
        explanation="test explanation",
        history_minutes_used=3,
        ready=ready,
        forecast_window=dict(FORECAST_WINDOW),
        suspicious_source=suspicious_source,
        evidence=evidence or [],
    )


def _demo_result(probability, attack_type="none", ready=True, confidence=0.5,
                  suspicious_source=None, evidence=None):
    return ForecastResult(
        mode=DEMONSTRATION_MODE,
        probability=probability,
        attack_type=attack_type,
        model_status="HEURISTIC_NOT_A_TRAINED_MODEL",
        confidence=confidence,
        explanation="heuristic explanation",
        history_minutes_used=3,
        ready=ready,
        forecast_window=dict(FORECAST_WINDOW),
        suspicious_source=suspicious_source,
        evidence=evidence or [],
    )


# --- severity mapping -------------------------------------------------

@pytest.mark.parametrize("probability,expected", [
    (0.0, "LOW"),
    (0.1, "LOW"),
    (0.24999, "LOW"),
    (0.25, "MEDIUM"),
    (0.4, "MEDIUM"),
    (0.5, "HIGH"),
    (0.6, "HIGH"),
    (0.75, "CRITICAL"),
    (0.99, "CRITICAL"),
    (1.0, "CRITICAL"),
])
def test_severity_thresholds(probability, expected):
    assert compute_severity(probability, model_status="TRAINED") == expected


def test_severity_is_unvalidated_for_degenerate_model_regardless_of_probability():
    # Even a "high-looking" probability must not be trusted from a model
    # that structurally cannot make a validated prediction.
    assert compute_severity(0.0, "DEGENERATE_SINGLE_CLASS_TRAINING") == "UNVALIDATED"
    assert compute_severity(0.9, "DEGENERATE_SINGLE_CLASS_TRAINING") == "UNVALIDATED"


def test_severity_is_unvalidated_for_single_episode_model_regardless_of_probability():
    assert compute_severity(0.0, "SINGLE_EPISODE_UNVALIDATED") == "UNVALIDATED"
    assert compute_severity(0.97, "SINGLE_EPISODE_UNVALIDATED") == "UNVALIDATED"


def test_every_severity_has_a_documented_recommendation_list():
    for severity in ("LOW", "MEDIUM", "HIGH", "CRITICAL", "UNVALIDATED"):
        assert severity in RECOMMENDATIONS
        assert isinstance(RECOMMENDATIONS[severity], list)
        assert len(RECOMMENDATIONS[severity]) > 0


# --- event creation -----------------------------------------------------

def test_create_threat_event_basic_fields():
    forecast = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    event = create_threat_event(forecast, as_of=TS)

    assert event is not None
    assert event.event_id.startswith("evt_")
    assert event.timestamp == TS.isoformat()
    assert event.forecast_mode == VALIDATED_MODEL_MODE
    assert event.model_status == "DEGENERATE_SINGLE_CLASS_TRAINING"
    assert event.attack_probability == 0.0
    assert event.forecast_window == FORECAST_WINDOW
    assert event.model_version == "window-random-forest-v1"


def test_degenerate_zero_probability_is_flagged_unvalidated_not_low():
    """The core requirement: probability=0 from a structurally-incapable
    model must not read as an ordinary reliable 'all clear'."""
    forecast = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    event = create_threat_event(forecast, as_of=TS)
    assert event.severity == "UNVALIDATED"
    joined = " ".join(event.recommended_actions).lower()
    assert "single-episode" in joined or "cannot" in joined


def test_demonstration_mode_preserves_its_own_labels():
    forecast = _demo_result(0.8, attack_type="DDoS (heuristic guess -- only attack type present in training data)")
    event = create_threat_event(forecast, as_of=TS)
    assert event.forecast_mode == DEMONSTRATION_MODE
    assert event.model_status == "HEURISTIC_NOT_A_TRAINED_MODEL"
    assert event.model_version == "heuristic-volume-zscore-v1"
    # Never silently upgraded to look like trained AI output.
    assert "HEURISTIC" in event.model_status


def test_event_carries_suspicious_source_and_evidence_when_available():
    source = {"source_ip": "172.16.0.1", "flow_count": 2438, "flow_share": 0.6641,
               "destination_ip": "192.168.10.50", "destination_port": 80}
    evidence = [{"signal": "top_source_ip_share", "value": 0.6641}]
    forecast = _demo_result(0.9, suspicious_source=source, evidence=evidence)
    event = create_threat_event(forecast, as_of=TS)
    assert event.suspicious_source == source
    assert event.evidence == evidence


def test_event_carries_a_pattern_match_that_is_honest_about_unavailability():
    forecast = _demo_result(0.9)
    event = create_threat_event(forecast, as_of=TS)
    assert event.pattern_match["status"] == "NOT_AVAILABLE"


def test_event_matches_a_known_pattern_when_minute_features_supplied():
    forecast = _demo_result(0.9, evidence=[{"signal": "traffic_volume_zscore", "value": 8.97}])
    minute_features = {
        "total_flows": 9164, "unique_destination_ports": 5, "unique_source_ips": 56,
        "destination_port": 80, "top_source_ip_flow_share": 0.71,
    }
    event = create_threat_event(forecast, as_of=TS, minute_features=minute_features)
    assert event.pattern_match["status"] == "MATCHED"
    assert event.pattern_match["matched_pattern_id"] == "ddos_volumetric"
    # A matched pattern adds its own recommendation on top of the severity-based list.
    assert any("Pattern match" in a for a in event.recommended_actions)


def test_event_carries_baseline_comparison_when_supplied():
    forecast = _demo_result(0.9)
    baseline_comparison = {"available": True, "overall_status": "FAR_ABOVE_NORMAL", "features": {}}
    event = create_threat_event(forecast, as_of=TS, baseline_comparison=baseline_comparison)
    assert event.baseline_comparison["overall_status"] == "FAR_ABOVE_NORMAL"


def test_event_carries_suspicious_sources_list():
    forecast = _demo_result(0.9)
    forecast.suspicious_sources = [
        {"rank": 1, "source_ip": "172.16.0.1", "flow_count": 6533, "flow_share": 0.71},
        {"rank": 2, "source_ip": "10.0.0.5", "flow_count": 200, "flow_share": 0.02},
    ]
    event = create_threat_event(forecast, as_of=TS)
    assert len(event.suspicious_sources) == 2
    assert event.suspicious_sources[0]["source_ip"] == "172.16.0.1"


def test_event_carries_risk_state_from_forecast():
    forecast = _validated_result(0.97, model_status="SINGLE_EPISODE_UNVALIDATED", confidence=None)
    forecast.risk_state = "UNVALIDATED"
    event = create_threat_event(forecast, as_of=TS)
    assert event.risk_state == "UNVALIDATED"


# --- deterministic IDs ----------------------------------------------------

def test_same_inputs_produce_same_event_id():
    f1 = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    f2 = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    e1 = create_threat_event(f1, as_of=TS)
    e2 = create_threat_event(f2, as_of=TS)
    assert e1.event_id == e2.event_id


def test_different_timestamp_produces_different_event_id():
    forecast = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    e1 = create_threat_event(forecast, as_of=TS)
    e2 = create_threat_event(forecast, as_of=TS + pd.Timedelta(minutes=1))
    assert e1.event_id != e2.event_id


def test_different_mode_produces_different_event_id_for_same_minute():
    validated = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    demo = _demo_result(0.0)
    e1 = create_threat_event(validated, as_of=TS)
    e2 = create_threat_event(demo, as_of=TS)
    assert e1.event_id != e2.event_id


# --- prevention of fabricated probability values --------------------------

def test_no_event_created_when_forecast_not_ready():
    not_ready = _validated_result(None, model_status="INSUFFICIENT_HISTORY", ready=False)
    assert create_threat_event(not_ready, as_of=TS) is None


def test_no_event_created_when_probability_is_none_even_if_marked_ready():
    # Defensive: probability must never be invented even if ready is
    # (incorrectly) True.
    weird = _validated_result(None, model_status="TRAINED", ready=True)
    assert create_threat_event(weird, as_of=TS) is None


# --- store: empty/no-threat behavior + idempotence ------------------------

def test_store_starts_empty():
    store = ThreatEventStore()
    assert len(store) == 0
    assert store.latest() is None
    assert store.list() == []


def test_store_add_and_latest():
    store = ThreatEventStore()
    forecast = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    event = create_threat_event(forecast, as_of=TS)
    added = store.add(event)
    assert added is True
    assert store.latest() == event
    assert len(store) == 1


def test_store_add_is_idempotent_for_duplicate_deterministic_id():
    store = ThreatEventStore()
    forecast = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    event1 = create_threat_event(forecast, as_of=TS)
    event2 = create_threat_event(forecast, as_of=TS)  # identical inputs -> identical event_id
    assert store.add(event1) is True
    assert store.add(event2) is False
    assert len(store) == 1


def test_store_list_is_most_recent_first():
    store = ThreatEventStore()
    f = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    e1 = create_threat_event(f, as_of=TS)
    e2 = create_threat_event(f, as_of=TS + pd.Timedelta(minutes=1))
    store.add(e1)
    store.add(e2)
    events = store.list()
    assert events[0].event_id == e2.event_id
    assert events[1].event_id == e1.event_id


def test_store_respects_max_events():
    store = ThreatEventStore(max_events=2)
    f = _validated_result(0.0, model_status="DEGENERATE_SINGLE_CLASS_TRAINING")
    for i in range(5):
        e = create_threat_event(f, as_of=TS + pd.Timedelta(minutes=i))
        store.add(e)
    assert len(store) == 2
