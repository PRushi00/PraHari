"""Tests for ai/preprocess.py: timestamp parsing, label normalization,
and NaN/infinite value handling."""
import numpy as np
import pandas as pd
import pytest

from ai.preprocess import (
    clean_dataset,
    detect_label_column,
    detect_timestamp_column,
    encode_labels,
    normalize_column_names,
    parse_timestamps,
)


def test_normalize_column_names_strips_and_snake_cases():
    df = pd.DataFrame(columns=[" Destination Port", "Flow Duration", "Fwd IAT Mean"])
    df = normalize_column_names(df)
    assert list(df.columns) == ["destination_port", "flow_duration", "fwd_iat_mean"]


def test_detect_timestamp_column_by_name():
    df = pd.DataFrame({"timestamp": ["1/1/2017 10:00:00"], "value": [1]})
    assert detect_timestamp_column(df) == "timestamp"


def test_detect_timestamp_column_by_content_sniffing():
    df = pd.DataFrame({
        "flow_id": ["a", "b", "c"],
        "capture_time": ["1/1/2017 10:00:00", "1/1/2017 10:00:01", "1/1/2017 10:00:02"],
    })
    assert detect_timestamp_column(df) == "capture_time"


def test_detect_label_column_by_name():
    df = pd.DataFrame({"label": ["BENIGN", "DDoS"], "value": [1, 2]})
    assert detect_label_column(df) == "label"


def test_detect_label_column_by_heuristic():
    df = pd.DataFrame({"outcome": ["BENIGN", "PortScan", "BENIGN"], "value": [1, 2, 3]})
    assert detect_label_column(df) == "outcome"


def test_parse_timestamps_converts_to_datetime():
    df = pd.DataFrame({"timestamp": ["1/1/2017 10:00:00", "not-a-date", "1/1/2017 10:00:02"]})
    df = parse_timestamps(df, "timestamp")
    assert pd.api.types.is_datetime64_any_dtype(df["timestamp"])
    assert df["timestamp"].isna().sum() == 1


def test_clean_dataset_replaces_infinite_values():
    df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2017-01-01", "2017-01-01", "2017-01-01"]),
        "label": ["BENIGN", "BENIGN", "BENIGN"],
        "flow_bytes_s": [1.0, np.inf, -np.inf],
    })
    cleaned = clean_dataset(df, "timestamp", "label")
    assert np.isfinite(cleaned["flow_bytes_s"]).all()


def test_clean_dataset_drops_constant_and_all_nan_columns():
    df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2017-01-01", "2017-01-01"]),
        "label": ["BENIGN", "DDoS"],
        "constant_col": [5, 5],
        "empty_col": [np.nan, np.nan],
        "useful_col": [1, 2],
    })
    cleaned = clean_dataset(df, "timestamp", "label")
    assert "constant_col" not in cleaned.columns
    assert "empty_col" not in cleaned.columns
    assert "useful_col" in cleaned.columns


def test_clean_dataset_drops_rows_missing_timestamp_or_label():
    df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2017-01-01", None, "2017-01-01"]),
        "label": ["BENIGN", "DDoS", None],
        "value": [1, 2, 3],
    })
    cleaned = clean_dataset(df, "timestamp", "label")
    assert len(cleaned) == 1


def test_encode_labels_marks_benign_and_attack(tmp_path, monkeypatch):
    import ai.preprocess as preprocess_module
    monkeypatch.setattr(preprocess_module, "PROCESSED_DATA_DIR", tmp_path)
    monkeypatch.setattr(preprocess_module, "LABEL_MAPPING_PATH", tmp_path / "label_mapping.json")

    df = pd.DataFrame({"label": ["BENIGN", "DDoS", "PortScan", "BENIGN"]})
    encoded = encode_labels(df, "label")
    assert list(encoded["is_attack"]) == [0, 1, 1, 0]
    assert encoded["label_encoded"].nunique() == 3
