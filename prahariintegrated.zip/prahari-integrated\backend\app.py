"""FastAPI backend for the AI Network Attack Forecasting MVP.

Exposes the forecasting service (backend/forecasting_service.py) and the
local traffic replay engine (backend/replay.py) over HTTP so a future
dashboard (not built yet) can poll system status, current traffic state,
and forecasts.

This is a single small FastAPI app -- no microservices, no message queue,
no database. State lives in process memory and is lost on restart, which
is appropriate for a local one-day MVP demo.

Run:
    uvicorn backend.app:app --reload --port 8000
"""
from __future__ import annotations

import asyncio
import json
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ai.config import LEAD_TIME_PATH, RUNTIME_DB_PATH
from backend.baseline import OrganizationalBaseline
from backend.forecasting_service import (
    DEMONSTRATION_MODE,
    FORECAST_HORIZON_MINUTES,
    ForecastingService,
    ForecastResult,
    VALIDATED_MODEL_MODE,
)
from backend.notifier import AdminNotifier
from backend.pattern_store import DEFAULT_PATTERN_STORE
from backend.replay import TrafficReplayEngine
from backend.security import RateLimitMiddleware, SecurityHeadersMiddleware, require_api_key
from backend.threat_service import ThreatEventStore, create_threat_event
from blockchain.ledger import LocalBlockchainLedger
from storage.persistence import SqlitePersistence

# The dashboard (frontend/) is served by this same app so the whole
# system runs from one command (`uvicorn backend.app:app --port 8000`)
# and the browser talks to the API same-origin -- no separate static
# server, no CORS surprises. Opening frontend/index.html straight from
# disk still works too (app.js falls back to http://127.0.0.1:8000).
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


def _load_lead_time_analysis() -> dict:
    """Load the precomputed Early-Warning Lead Time KPI (ai/analyze_forecast_
    lead_time.py), same load-once-at-startup convention as
    ForecastingService's own metrics file. Honest "not available" if the
    script hasn't been run yet -- never computed live per-request (it
    replays the whole dataset) and never fabricated."""
    if not LEAD_TIME_PATH.exists():
        return {
            "available": False,
            "note": (
                f"{LEAD_TIME_PATH} not found. Run `python ai/analyze_forecast_lead_time.py` first."
            ),
        }
    with open(LEAD_TIME_PATH) as fh:
        data = json.load(fh)
    return {"available": True, **data}


class AppState:
    def __init__(self) -> None:
        self.service = ForecastingService()
        self.replay = TrafficReplayEngine()
        self.replay_task: Optional[asyncio.Task] = None
        self.stop_event: asyncio.Event = asyncio.Event()
        self.current_minute: Optional[dict] = None
        self.latest_forecast: dict[str, ForecastResult] = {}
        self.minutes_replayed = 0

        # Real sqlite3-backed durable storage (storage/persistence.py) --
        # threat events and blockchain records now survive a process
        # restart, closing the gap where the in-process blockchain
        # simulation and the in-memory threat store both used to lose
        # state on restart. Never fabricated: a fresh clone/first run
        # starts with an empty database, exactly as it always started
        # with an empty in-memory store before this existed.
        self.persistence = SqlitePersistence(RUNTIME_DB_PATH)
        self.threats = ThreatEventStore(persistence=self.persistence)
        self.ledger = LocalBlockchainLedger(persistence=self.persistence)
        self.notifier = AdminNotifier()

        # Organizational baseline + pattern/history correlation are both
        # derived once, deterministically, from the same replayed
        # dataset's own per-minute aggregation and ground-truth labels --
        # never from a live feed, never fabricated.
        self.baseline = OrganizationalBaseline.from_history(self.replay.per_minute_df)
        DEFAULT_PATTERN_STORE.load_history(self.replay.per_minute_df)
        self.pattern_store = DEFAULT_PATTERN_STORE

        # Early-Warning Lead Time KPI: precomputed offline (it replays the
        # whole dataset), loaded once here, never recomputed per-request.
        self.lead_time_analysis = _load_lead_time_analysis()


state = AppState()


def _pattern_features(minute_row: Optional[dict], baseline_comparison: Optional[dict]) -> dict:
    """The raw observable signals backend/pattern_store.py's known-pattern
    rules match against, plus the baseline-derived status flags they use
    to judge "far above normal" -- assembled here (not inside
    ForecastingService) since both are real replay/baseline data, never
    model input."""
    if not minute_row:
        return {}
    features = {
        "total_flows": minute_row.get("total_flows"),
        "unique_destination_ports": minute_row.get("unique_destination_ports"),
        "unique_source_ips": minute_row.get("unique_source_ips"),
        "destination_port": minute_row.get("top_destination_port"),
        "top_source_ip_flow_share": minute_row.get("top_source_ip_flow_share"),
    }
    if baseline_comparison and baseline_comparison.get("available"):
        port_stats = baseline_comparison.get("features", {}).get("unique_destination_ports")
        if port_stats:
            features["unique_destination_ports_status"] = port_stats.get("status")

        # z_score for pattern matching comes from the organizational
        # baseline (real replay data, always available regardless of
        # forecasting mode) -- NOT from forecast.evidence, whose z_score
        # signal only exists for DEMONSTRATION_MODE. Reading it from
        # evidence would make the same real traffic minute match a
        # different pattern depending on which mode happened to generate
        # the threat event, which is not honest.
        volume_stats = baseline_comparison.get("features", {}).get("total_flows")
        if volume_stats and volume_stats.get("status") == "ABOVE_NORMAL":
            features["z_score"] = volume_stats.get("deviation_std_devs")
        else:
            features["z_score"] = 0.0
    return features


def _on_minute(row: dict, index: int, total: int) -> None:
    state.current_minute = row
    state.minutes_replayed = index
    state.service.observe_minute(row)
    state.latest_forecast[VALIDATED_MODEL_MODE] = state.service.forecast(VALIDATED_MODEL_MODE)
    state.latest_forecast[DEMONSTRATION_MODE] = state.service.forecast(DEMONSTRATION_MODE)


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    if state.replay_task is not None:
        state.stop_event.set()
        state.replay_task.cancel()


app = FastAPI(
    title="AI Network Attack Forecasting -- MVP Backend",
    version="0.1.0",
    lifespan=lifespan,
)

# The frontend (frontend/index.html) is a static file opened directly in a
# browser or served from a different local port -- either way it's a
# different origin from this API, so the browser enforces CORS. This is a
# local, single-user MVP with no auth and no cookies, so a permissive
# allow-all policy is appropriate (never used with allow_credentials=True).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
# Security role (backend/security.py): standard defensive headers on
# every response, and a simple in-memory per-IP rate limiter -- both real
# and always-on, appropriate for a single-process local prototype.
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RateLimitMiddleware)


def _forecast_to_dict(result: ForecastResult) -> dict:
    return {
        "mode": result.mode,
        "probability": result.probability,
        "attack_type": result.attack_type,
        "model_status": result.model_status,
        "confidence": result.confidence,
        "explanation": result.explanation,
        "risk_state": result.risk_state,
        "forecast_window": result.forecast_window,
        "evidence": result.evidence,
        "suspicious_source": result.suspicious_source,
        "suspicious_sources": result.suspicious_sources,
        "forecast_horizon_minutes": result.forecast_horizon_minutes,
        "history_minutes_used": result.history_minutes_used,
        "ready": result.ready,
        "extra": result.extra,
    }


@app.get("/api")
def api_index() -> dict:
    return {
        "system": "AI Network Attack Forecasting -- MVP",
        "dashboard": "/  (the PRAHARI dashboard is served at the site root)",
        "status": "This is a proof-of-concept prototype, not a production system.",
        "endpoints": [
            "/status", "/traffic/current", "/forecast", "/baseline", "/patterns/history",
            "/metrics/lead_time",
            "/replay/start", "/replay/stop", "/replay/reset", "/replay/seek",
            "/threats/generate", "/threats/latest", "/threats", "/alerts",
            "/blockchain/record", "/blockchain/records", "/blockchain/records/{event_id}",
            "/blockchain/verify/{event_id}",
        ],
        "docs": "/docs (Swagger UI) and /redoc -- interactive API reference, auto-generated by FastAPI",
        "auth": (
            "State-changing endpoints (POST /replay/*, /threats/generate, /blockchain/record) "
            "require an X-API-Key header. Read-only endpoints (GET) are open."
        ),
    }


@app.get("/status")
def get_status() -> dict:
    return {
        "system_status": "READY" if state.replay.loaded else "DATASET_UNAVAILABLE",
        "replay": {
            "loaded": state.replay.loaded,
            "load_error": state.replay.load_error,
            "running": state.replay_task is not None and not state.replay_task.done(),
            "current_minute_index": state.replay.index,
            "total_minutes": state.replay.total_minutes,
            "finished": state.replay.finished,
        },
        "model": {
            "model_loaded": state.service.model is not None,
            "model_load_error": state.service.model_load_error,
            "model_status": state.service.saved_model_status,
            "train_single_class": state.service.train_single_class,
        },
        "blockchain": {
            "available": state.ledger.available,
            "unavailable_reason": state.ledger.unavailable_reason,
            "chain_id": state.ledger.chain_id,
            "records_stored": len(state.ledger.list_records()),
        },
        "baseline": {
            "available": state.baseline.available,
            "sample_minutes": state.baseline.sample_minutes,
            "note": state.baseline.note,
        },
        "pattern_history": {
            "historical_incidents": len(state.pattern_store.historical_incidents),
        },
        "persistence": {
            "backend": "sqlite3",
            "db_path": str(state.persistence.db_path),
            "note": (
                "Threat events and blockchain records are durably written here (storage/"
                "persistence.py) -- both survive a process restart, not only an in-memory "
                "AppState reset."
            ),
        },
        "forecast_horizon_minutes": FORECAST_HORIZON_MINUTES,
        "disclaimer": (
            "Proof-of-concept prototype built on a single CICIDS2017 DDoS episode. "
            "Does not demonstrate generalization to unseen attacks or campaigns."
        ),
    }


@app.get("/traffic/current")
def get_current_traffic() -> dict:
    if state.current_minute is None:
        raise HTTPException(status_code=404, detail="no traffic observed yet -- start the replay first")

    row = dict(state.current_minute)
    ground_truth = {
        "attack_flows": row.pop("attack_flows", None),
        "benign_flows": row.pop("benign_flows", None),
        "attack_ratio": row.pop("attack_ratio", None),
    }
    row["timestamp"] = str(row["timestamp"])
    return {
        "observed_traffic": row,
        "ground_truth_label_for_this_minute": ground_truth,
        "note": (
            "ground_truth_label_for_this_minute comes from the historical dataset's own labels "
            "for display/comparison only -- it is never given to the forecasting model as an input."
        ),
    }


@app.get("/baseline")
def get_baseline() -> dict:
    """Current traffic vs. the organizational normal baseline (backend/
    baseline.py) -- computed once from the replayed dataset's own
    BENIGN-labeled minutes, never from a live feed."""
    return state.baseline.compare(state.current_minute)


@app.get("/patterns/history")
def get_pattern_history() -> dict:
    """Historical incidents derivable from the replayed dataset's own
    ground-truth labels (backend/pattern_store.py) -- real behaviour
    observed in the data this prototype runs on, not fabricated
    organizational history."""
    return {
        "count": len(state.pattern_store.historical_incidents),
        "incidents": [inc.to_dict() for inc in state.pattern_store.historical_incidents],
    }


@app.get("/metrics/lead_time")
def get_lead_time_metrics() -> dict:
    """Early-Warning Lead Time KPI (ai/analyze_forecast_lead_time.py) --
    how many minutes before the real recorded attack onset each
    forecasting mode first raised an alert, computed once offline by
    replaying the same dataset this backend replays live. See the
    module docstring for the full honesty caveats on each mode."""
    return state.lead_time_analysis


@app.get("/forecast")
def get_forecast(mode: str = Query(default=VALIDATED_MODEL_MODE)) -> dict:
    if mode not in (VALIDATED_MODEL_MODE, DEMONSTRATION_MODE):
        raise HTTPException(status_code=400, detail=f"mode must be one of {VALIDATED_MODEL_MODE!r}, {DEMONSTRATION_MODE!r}")

    if mode in state.latest_forecast:
        return _forecast_to_dict(state.latest_forecast[mode])

    result = state.service.forecast(mode)
    return _forecast_to_dict(result)


class ReplayStartRequest(BaseModel):
    minutes_per_second: float = 2.0


@app.post("/replay/start", dependencies=[Depends(require_api_key)])
async def start_replay(req: ReplayStartRequest = ReplayStartRequest()) -> dict:
    if not state.replay.loaded:
        raise HTTPException(status_code=409, detail=state.replay.load_error or "dataset not loaded")
    if state.replay_task is not None and not state.replay_task.done():
        raise HTTPException(status_code=409, detail="replay is already running")

    state.stop_event = asyncio.Event()
    state.replay_task = asyncio.create_task(
        state.replay.run_async(_on_minute, minutes_per_second=req.minutes_per_second, stop_event=state.stop_event)
    )
    return {"status": "started", "minutes_per_second": req.minutes_per_second}


@app.post("/replay/stop", dependencies=[Depends(require_api_key)])
def stop_replay() -> dict:
    if state.replay_task is None or state.replay_task.done():
        return {"status": "not_running"}
    state.stop_event.set()
    return {"status": "stopping"}


@app.post("/replay/reset", dependencies=[Depends(require_api_key)])
def reset_replay() -> dict:
    if state.replay_task is not None and not state.replay_task.done():
        raise HTTPException(status_code=409, detail="stop the replay before resetting")
    state.replay.reset()
    state.service.reset()
    state.current_minute = None
    state.latest_forecast = {}
    state.minutes_replayed = 0
    state.threats.clear()
    state.ledger.clear()
    state.notifier.clear()
    return {"status": "reset"}


class ReplaySeekRequest(BaseModel):
    minute: int


# Enough lead-up minutes to fully repopulate the forecasting service's
# rolling state before the target minute: it needs 3 minutes of lag
# history plus a 15-minute trailing baseline window, so 25 is generous.
_SEEK_WARMUP_MINUTES = 25


@app.post("/replay/seek", dependencies=[Depends(require_api_key)])
def seek_replay(req: ReplaySeekRequest) -> dict:
    """Jump the replay to a specific minute so a demo can be paused,
    rewound, and stepped through one minute at a time. The forecasting
    service is rebuilt deterministically by silently replaying the
    lead-up minutes, so the forecast shown at the target minute is
    exactly what a continuous replay would have produced there. Threat
    events / blockchain records are cleared and regenerate as the replay
    moves forward again (event IDs are deterministic, so nothing is
    duplicated or fabricated)."""
    if not state.replay.loaded:
        raise HTTPException(status_code=409, detail=state.replay.load_error or "dataset not loaded")
    if state.replay_task is not None and not state.replay_task.done():
        raise HTTPException(status_code=409, detail="stop the replay before seeking")

    total = state.replay.total_minutes
    target = max(0, min(int(req.minute), total))

    state.replay.reset()
    state.service.reset()
    state.current_minute = None
    state.latest_forecast = {}
    state.threats.clear()
    state.ledger.clear()
    state.notifier.clear()

    state.replay.index = max(0, target - _SEEK_WARMUP_MINUTES)
    while state.replay.index < target:
        row = state.replay.step()
        if row is None:
            break
        _on_minute(row, state.replay.index, total)
    state.minutes_replayed = state.replay.index

    return {
        "status": "seeked",
        "minute": state.replay.index,
        "total_minutes": total,
        "current_minute": str(state.current_minute["timestamp"]) if state.current_minute else None,
    }


@app.post("/threats/generate", dependencies=[Depends(require_api_key)])
def generate_threat(mode: str = Query(default=VALIDATED_MODEL_MODE)) -> dict:
    if mode not in (VALIDATED_MODEL_MODE, DEMONSTRATION_MODE):
        raise HTTPException(status_code=400, detail=f"mode must be one of {VALIDATED_MODEL_MODE!r}, {DEMONSTRATION_MODE!r}")
    if state.current_minute is None:
        raise HTTPException(status_code=409, detail="no traffic observed yet -- start the replay first")

    forecast = state.latest_forecast.get(mode) or state.service.forecast(mode)
    baseline_comparison = state.baseline.compare(state.current_minute)
    minute_features = _pattern_features(state.current_minute, baseline_comparison)
    event = create_threat_event(
        forecast, as_of=state.current_minute["timestamp"],
        minute_features=minute_features, baseline_comparison=baseline_comparison,
    )
    if event is None:
        return {
            "created": False,
            "reason": f"forecast not ready ({forecast.model_status}) -- no threat event generated",
        }

    is_new = state.threats.add(event)
    alert = state.notifier.notify_if_warranted(event.to_dict()) if is_new else None
    return {
        "created": is_new, "duplicate": not is_new, "event": event.to_dict(),
        "alert": alert.to_dict() if alert else None,
    }


@app.get("/alerts")
def list_alerts(limit: Optional[int] = Query(default=None, ge=1)) -> dict:
    """Administrator alert log (backend/notifier.py) -- every HIGH/
    CRITICAL threat event recorded here, real and inspectable. No email/
    SMS/push delivery in this prototype -- see each alert's own `note`."""
    alerts = state.notifier.list(limit=limit)
    return {"count": len(alerts), "alerts": [a.to_dict() for a in alerts]}


@app.get("/threats/latest")
def get_latest_threat() -> dict:
    event = state.threats.latest()
    if event is None:
        raise HTTPException(status_code=404, detail="no threat events generated yet")
    return event.to_dict()


@app.get("/threats")
def list_threats(limit: Optional[int] = Query(default=None, ge=1)) -> dict:
    events = state.threats.list(limit=limit)
    return {"count": len(events), "events": [e.to_dict() for e in events]}


class BlockchainRecordRequest(BaseModel):
    event_id: str


@app.post("/blockchain/record", dependencies=[Depends(require_api_key)])
def record_on_blockchain(req: BlockchainRecordRequest) -> dict:
    event = None
    for candidate in state.threats.list():
        if candidate.event_id == req.event_id:
            event = candidate
            break
    if event is None:
        raise HTTPException(status_code=404, detail=f"no threat event found with event_id={req.event_id!r}")

    return state.ledger.record_threat(event.to_dict())


@app.get("/blockchain/records")
def list_blockchain_records() -> dict:
    records = state.ledger.list_records()
    return {"count": len(records), "records": records}


@app.get("/blockchain/records/{event_id}")
def get_blockchain_record(event_id: str) -> dict:
    record = state.ledger.get_record(event_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"no blockchain record found for event_id={event_id!r}")
    return record


class BlockchainVerifyRequest(BaseModel):
    threat_event: Optional[dict] = None


@app.post("/blockchain/verify/{event_id}")
def verify_on_blockchain(event_id: str, req: BlockchainVerifyRequest = BlockchainVerifyRequest()) -> dict:
    if req.threat_event is not None:
        threat_event = req.threat_event
        if threat_event.get("event_id") != event_id:
            raise HTTPException(status_code=400, detail="body threat_event.event_id must match the path event_id")
    else:
        stored_event = None
        for candidate in state.threats.list():
            if candidate.event_id == event_id:
                stored_event = candidate
                break
        if stored_event is None:
            raise HTTPException(status_code=404, detail=f"no threat event found with event_id={event_id!r}")
        threat_event = stored_event.to_dict()

    return state.ledger.verify_threat(threat_event)


# --- Static dashboard --------------------------------------------------
# Mounted LAST so every API route above is matched first; this only
# handles the browser UI (index.html, style.css, app.js, classic.*).
# html=True makes "/" serve frontend/index.html.
if FRONTEND_DIR.is_dir():

    @app.get("/", include_in_schema=False)
    def dashboard_index() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "index.html")

    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
