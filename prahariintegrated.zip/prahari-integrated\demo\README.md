# Demo runner

`run_demo.sh` is a thin orchestration script -- it contains **no**
forecasting, replay, threat, or blockchain logic of its own. Every step
calls the exact same FastAPI endpoints `frontend/app.js` calls
(`backend/app.py`). It only automates the sequence a person would
otherwise run by hand with `curl` or by clicking buttons on the
dashboard, and prints numbered milestones as each real API response
comes back.

## Run

```bash
./demo/run_demo.sh
```

## What it does, in order

1. Checks `.venv` exists and the required packages/model artifacts are
   present (fails fast with a clear message if not -- in practice this
   passes immediately after a fresh clone, since `data/processed/`'s
   datasets and trained models are committed to the repository, not
   gitignored).
2. Starts `uvicorn backend.app:app` on `127.0.0.1:8000`, waits for
   `GET /status` to respond.
3. Serves `frontend/` with `python3 -m http.server` on `127.0.0.1:8080`
   (a plain static file server -- no framework, just what's needed to
   avoid `file://` CORS quirks in some browsers) and tries to open it.
4. Resets any previous replay/threat/blockchain state
   (`POST /replay/stop`, `POST /replay/reset`).
5. Starts the replay (`POST /replay/start`) over the real recorded
   CICIDS2017 dataset -- no synthetic traffic.
6. Polls `GET /forecast?mode=DEMONSTRATION_MODE` and
   `GET /traffic/current` (never guesses/hardcodes a minute index) until
   forecasting is active and the real historical attack interval is
   reached, printing the real `VALIDATED_MODEL_MODE` probability/status/
   risk_state alongside for honest comparison.
7. Generates a threat event (`POST /threats/generate?mode=DEMONSTRATION_MODE`),
   printing its severity, risk_state, suspicious source (if the replayed
   minute had one), and its first recommended action.
8. Records it on the local blockchain (`POST /blockchain/record`).
9. Verifies it (`POST /blockchain/verify/{event_id}`).
10. Leaves the backend and dashboard running so a judge can watch/interact
    with the dashboard live -- the dashboard's own polling loop keeps
    advancing the pipeline independently of this script. The dashboard
    itself shows one unified "SECURITY FORECAST" hero (not two competing
    panels) with a toggle to switch between the two modes; see README.md
    "RUNNING THE DASHBOARD" for the full layout.

## Stopping

Press `Ctrl+C` in the terminal running the script. It kills only the two
processes it started (the backend and the dashboard's static file
server) -- nothing else on the system.

## Why DEMONSTRATION_MODE drives the walkthrough

`VALIDATED_MODEL_MODE` runs the real trained window forecaster
(`ai/train_window_forecaster.py`), and its status is honestly
`SINGLE_EPISODE_UNVALIDATED`: the dataset has only one continuous attack
episode, so the model's test rows are the tail of the same episode it
trained on, not an independent occurrence. Its raw probability output
does vary (this run: `0.9`-`1.0` at the real attack onset), but its
`risk_state` and `severity` are always forced to `UNVALIDATED` --
never a graded LOW/MEDIUM/HIGH/CRITICAL alert -- regardless of that
number, so a walkthrough driven by it alone would never show the
escalating risk-state story a demo needs. `DEMONSTRATION_MODE` is a
transparent, rule-based heuristic -- explicitly labeled
`HEURISTIC_NOT_A_TRAINED_MODEL` in every place it appears, in this
script's output and on the dashboard -- so the demo has a real,
responsive NORMAL -> ELEVATED -> HIGH_RISK signal to show. The real
model's status, probability, and risk_state are still printed at step
`[3]` every run, never hidden.
