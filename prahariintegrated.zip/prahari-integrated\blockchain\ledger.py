"""Local Ethereum-compatible ledger for recording threat-event proof hashes.

Chosen implementation: web3.py's EthereumTesterProvider, backed by
eth-tester/py-evm -- a real, pure-Python EVM implementation that runs
entirely IN-PROCESS. This was chosen after inspecting what's actually
available: no `anvil`/`forge`/`ganache` binary was present, and installing
Foundry would mean managing a separate always-running node subprocess (a
small multi-service stack) just to record hashes. `pip install "web3[tester]"`
gives a genuinely Ethereum-compatible chain (real blocks, real transaction
hashes, real receipts) with:

  - no subprocess or external binary to start/stop/manage
  - no port to bind, no RPC server to keep alive
  - no network access at runtime (pure in-process simulation)
  - no public chain, no MetaMask, no external wallet
  - one pip dependency

This is the lightest option that is still honestly "a local blockchain"
rather than a hand-rolled toy hash-chain pretending to be one.

The chain never stores the raw threat event or any dataset -- only the
SHA-256 hash of a canonical JSON encoding of the event, written as
transaction calldata. If the backend fails to initialize for any reason,
every ledger call degrades to chain_status="BLOCKCHAIN_UNAVAILABLE"
instead of raising or fabricating a transaction ID.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from storage.persistence import SqlitePersistence

CHAIN_STATUS_UNAVAILABLE = "BLOCKCHAIN_UNAVAILABLE"
CHAIN_STATUS_CONFIRMED = "CONFIRMED"
CHAIN_STATUS_FAILED = "FAILED"


def canonicalize(threat_event: dict) -> bytes:
    """Deterministic serialization of a threat event: recursively sorted
    keys, compact stable JSON encoding. This -- never repr() -- is what
    gets hashed, so the same logical event always produces the same
    bytes regardless of Python dict ordering or process."""
    return json.dumps(threat_event, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def compute_threat_hash(threat_event: dict) -> str:
    """SHA-256 of the canonical encoding, as a 0x-prefixed hex string."""
    return "0x" + hashlib.sha256(canonicalize(threat_event)).hexdigest()


class LocalBlockchainLedger:
    """Records threat-event hashes on a local, in-process Ethereum-
    compatible test chain, and verifies them later by recomputing the
    hash and comparing to what was actually recorded on-chain.

    The chain itself (EthereumTesterProvider) runs entirely in-process --
    it, and this class's own self._records index, do not survive a
    process restart on their own. Pass a storage.persistence.SqlitePersistence
    to make records genuinely durable: every record_threat() call is also
    written to a real sqlite3 file, and __init__ reloads whatever records
    already exist there. Without one, behavior is unchanged from before
    this option existed -- in-memory only."""

    def __init__(self, persistence: Optional[SqlitePersistence] = None):
        self.available = False
        self.unavailable_reason: Optional[str] = None
        self._w3 = None
        self._account: Optional[str] = None
        self.chain_id: Optional[int] = None
        self.persistence = persistence
        self._records: dict[str, dict] = {}
        if persistence is not None:
            self._records.update(persistence.load_blockchain_records())

        try:
            from web3 import EthereumTesterProvider, Web3

            w3 = Web3(EthereumTesterProvider())
            if not w3.is_connected():
                raise RuntimeError("EthereumTesterProvider did not connect")
            accounts = w3.eth.accounts
            if not accounts:
                raise RuntimeError("local test chain returned no accounts")

            self._w3 = w3
            self._account = accounts[0]
            self.chain_id = w3.eth.chain_id
            self.available = True
        except Exception as exc:  # pragma: no cover - depends on environment
            self.unavailable_reason = f"{type(exc).__name__}: {exc}"

    def _unavailable_record(self, event_id: str, threat_hash: str) -> dict:
        return {
            "event_id": event_id,
            "threat_hash": threat_hash,
            "blockchain_transaction_id": None,
            "block_number": None,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
            "chain_status": CHAIN_STATUS_UNAVAILABLE,
            "chain_status_detail": self.unavailable_reason,
        }

    def record_threat(self, threat_event: dict) -> dict:
        """Hash the given threat event and write that hash to the local
        chain. Idempotent by event_id: recording the same event_id again
        returns the existing record rather than writing a second
        transaction (matches the deterministic-event-ID design of
        backend/threat_service.py)."""
        event_id = threat_event["event_id"]
        threat_hash = compute_threat_hash(threat_event)

        if event_id in self._records:
            return self._records[event_id]

        if not self.available:
            record = self._unavailable_record(event_id, threat_hash)
            self._records[event_id] = record
            if self.persistence is not None:
                self.persistence.save_blockchain_record(event_id, record)
            return record

        try:
            tx_hash = self._w3.eth.send_transaction({
                "from": self._account,
                "to": self._account,
                "value": 0,
                "data": threat_hash,
            })
            receipt = self._w3.eth.wait_for_transaction_receipt(tx_hash)
            chain_status = CHAIN_STATUS_CONFIRMED if receipt.status == 1 else CHAIN_STATUS_FAILED
            tx_hex = receipt.transactionHash.hex()
            if not tx_hex.startswith("0x"):
                tx_hex = "0x" + tx_hex
            record = {
                "event_id": event_id,
                "threat_hash": threat_hash,
                "blockchain_transaction_id": tx_hex,
                "block_number": receipt.blockNumber,
                "recorded_at": datetime.now(timezone.utc).isoformat(),
                "chain_status": chain_status,
                "chain_status_detail": None,
                "chain_id": self.chain_id,
            }
        except Exception as exc:  # pragma: no cover - defensive
            record = self._unavailable_record(event_id, threat_hash)
            record["chain_status"] = CHAIN_STATUS_FAILED
            record["chain_status_detail"] = f"{type(exc).__name__}: {exc}"

        self._records[event_id] = record
        if self.persistence is not None:
            self.persistence.save_blockchain_record(event_id, record)
        return record

    def get_record(self, event_id: str) -> Optional[dict]:
        return self._records.get(event_id)

    def list_records(self) -> list[dict]:
        """Most-recent-first."""
        return list(reversed(self._records.values()))

    def verify_threat(self, threat_event: dict, stored_record: Optional[dict] = None) -> dict:
        """Recompute the hash of the SUPPLIED threat_event (which may be
        tampered) and compare it against the hash actually stored on the
        chain for that event_id. Never trusts the supplied event's own
        fields as truth -- only the independently recomputed hash."""
        event_id = threat_event["event_id"]
        if stored_record is None:
            stored_record = self.get_record(event_id)

        recomputed_hash = compute_threat_hash(threat_event)

        if stored_record is None:
            return {
                "event_id": event_id,
                "verified": False,
                "reason": "no blockchain record found for this event_id",
                "recomputed_hash": recomputed_hash,
                "stored_hash": None,
                "checked_at": datetime.now(timezone.utc).isoformat(),
            }

        stored_hash = stored_record.get("threat_hash")
        verified = recomputed_hash == stored_hash

        return {
            "event_id": event_id,
            "verified": verified,
            "reason": None if verified else "recomputed hash does not match the hash recorded on-chain",
            "recomputed_hash": recomputed_hash,
            "stored_hash": stored_hash,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    def clear(self) -> None:
        self._records.clear()
        if self.persistence is not None:
            self.persistence.clear_blockchain_records()
