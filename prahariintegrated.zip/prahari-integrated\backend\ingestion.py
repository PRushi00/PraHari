"""Traffic ingestion abstraction: the "24x7 network monitoring / continuous
traffic telemetry" stage of the target architecture.

This prototype only ever replays a real, already-recorded dataset -- it
never fabricates live traffic. But the rest of the pipeline (forecasting,
suspicious-source tracking, threat events, blockchain) should not need to
change if a future phase swaps the data source for a live packet/flow
feed. `TrafficSource` names the minimal interface any traffic origin
(replay today; a live capture agent, a message-queue consumer, or a
different recorded dataset tomorrow) must implement so the rest of the
backend can depend on the interface, not on "replay" specifically.

`backend.replay.TrafficReplayEngine` implements this interface today. No
live-capture implementation exists in this repository -- that is explicit
future work (see README.md), not claimed here.
"""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from typing import Callable, Optional


class TrafficSource(ABC):
    """Minimal contract the rest of the backend depends on: something
    that can be stepped one aggregated minute at a time, in chronological
    order, and reports whether/why it failed to load. A live-telemetry
    source would implement the same interface -- `step()` would return
    the next real aggregated minute instead of the next replayed one, and
    `total_minutes`/`finished` would track a live session instead of a
    fixed historical file.

    Every implementation is also expected to expose a plain
    `load_error: Optional[str]` attribute (the human-readable reason
    `loaded` is False, or None) -- not declared as an abstract property
    here because implementations set it as a simple instance attribute in
    __init__, which a property of the same name on this base class would
    block."""

    @property
    @abstractmethod
    def loaded(self) -> bool:
        """True once this source has a traffic stream ready to step through."""

    @property
    @abstractmethod
    def total_minutes(self) -> int:
        """Total minutes available (0 for an open-ended live source)."""

    @property
    @abstractmethod
    def finished(self) -> bool:
        """True once there is no more traffic to step through."""

    @abstractmethod
    def reset(self) -> None:
        """Return to the start of the stream (replay) or clear state (live)."""

    @abstractmethod
    def step(self) -> Optional[dict]:
        """Return the next chronological minute's aggregated row as a
        plain dict, or None if there is nothing new yet / the stream has
        ended."""

    @abstractmethod
    def run(
        self,
        on_minute: Callable[[dict, int, int], None],
        minutes_per_second: float = 2.0,
        max_minutes: Optional[int] = None,
    ) -> None:
        """Synchronous loop calling on_minute(row, index, total) once per
        available minute."""

    @abstractmethod
    async def run_async(
        self,
        on_minute: Callable[[dict, int, int], None],
        minutes_per_second: float = 2.0,
        stop_event: Optional[asyncio.Event] = None,
    ) -> None:
        """Async version of run(), for embedding in a FastAPI background task."""
