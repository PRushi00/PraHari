"""Build the leakage-safe 3-minute-lookback supervised forecasting dataset.

Reads data/processed/forecasting_dataset.csv (92 rows, one per minute) and
writes data/processed/lagged_forecasting_dataset.csv: one row per
prediction time t, whose predictors are drawn ONLY from t-2, t-1, and t,
and whose target is attack_next_minute at t (i.e. the true label for
t+1). This is the locked first-baseline formulation:

    history/lookback = 3 minutes
    forecast horizon = 1 minute
    target            = attack_next_minute

No model is trained here -- this script only constructs and validates the
supervised feature matrix.

Run:
    python ai/build_lagged_forecasting_dataset.py
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from ai.config import FORECASTING_DATASET_PATH, LAGGED_FORECASTING_DATASET_PATH

# Approved raw-telemetry predictors -- lagged at t-2, t-1, t.
PRIMARY_FEATURES = [
    "total_flows",
    "total_fwd_packets",
    "total_backward_packets",
    "total_bytes",
    "total_packets",
    "mean_flow_duration",
    "mean_flow_packets_s",
    "mean_flow_bytes_s",
    "unique_source_ips",
    "unique_destination_ips",
    "unique_destination_ports",
]

# Calendar predictors -- current minute (t) only, never lagged.
CALENDAR_FEATURES = ["minute_of_hour", "hour"]

TARGET_COLUMN = "attack_next_minute"

# Must never appear as a predictor anywhere in the output.
EXCLUDED_COLUMNS = [
    "benign_flows",
    "attack_flows",
    "attack_ratio",
    "attack_next_minute",
    "attack_count_next_minute",
    "attack_ratio_next_minute",
    "day_of_week",
]

LAG_OFFSETS = [2, 1, 0]  # t-2, t-1, t (current)


def load_forecasting_dataset(path: Path = FORECASTING_DATASET_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python ai/build_forecasting_dataset.py` first."
        )
    df = pd.read_csv(path, low_memory=False)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    missing = [c for c in PRIMARY_FEATURES + CALENDAR_FEATURES + [TARGET_COLUMN] if c not in df.columns]
    if missing:
        raise ValueError(f"forecasting dataset is missing expected column(s): {missing}")
    return df.sort_values("timestamp").reset_index(drop=True)


def build_lagged_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Construct one row per prediction time t with lag2/lag1/lag0 features.

    Each lag is resolved by an explicit timestamp lookup (t - offset
    minutes), not a positional shift, so a row is only built when true
    1-minute-spaced history genuinely exists at t-2 and t-1 -- if a minute
    were ever missing, that prediction time is skipped rather than silently
    paired with the wrong neighbor.
    """
    indexed = df.set_index("timestamp")
    one_min = pd.Timedelta(minutes=1)

    rows = []
    skipped = []
    for t in df["timestamp"]:
        required_ts = [t - offset * one_min for offset in LAG_OFFSETS]  # [t-2, t-1, t]
        if not all(ts in indexed.index for ts in required_ts):
            skipped.append(t)
            continue

        row = {"timestamp": t}
        for offset, ts in zip(LAG_OFFSETS, required_ts):
            source_row = indexed.loc[ts]
            for feature in PRIMARY_FEATURES:
                row[f"lag{offset}_{feature}"] = source_row[feature]
        for feature in CALENDAR_FEATURES:
            row[feature] = indexed.loc[t, feature]
        row[TARGET_COLUMN] = indexed.loc[t, TARGET_COLUMN]
        rows.append(row)

    lagged = pd.DataFrame(rows)

    column_order = ["timestamp"]
    for offset in LAG_OFFSETS:
        column_order += [f"lag{offset}_{f}" for f in PRIMARY_FEATURES]
    column_order += CALENDAR_FEATURES + [TARGET_COLUMN]
    lagged = lagged[column_order].sort_values("timestamp").reset_index(drop=True)

    return lagged, len(skipped)


def get_predictor_columns(lagged: pd.DataFrame) -> list[str]:
    return [c for c in lagged.columns if c not in ("timestamp", TARGET_COLUMN)]


def run_sanity_checks(lagged: pd.DataFrame, source: pd.DataFrame) -> None:
    # 1. chronological
    assert lagged["timestamp"].is_monotonic_increasing, "timestamps are not sorted ascending"
    # 2. no duplicate timestamps
    assert lagged["timestamp"].duplicated().sum() == 0, "duplicate timestamps found"
    # 3. no missing values
    n_nan = int(lagged.isna().sum().sum())
    assert n_nan == 0, f"{n_nan} NaN values remain in the lagged dataset"

    predictor_cols = get_predictor_columns(lagged)

    # 4. every predictor belongs to the approved set (lagN_<primary feature> or a calendar feature)
    approved_base_names = set(PRIMARY_FEATURES) | set(CALENDAR_FEATURES)
    for col in predictor_cols:
        if col in CALENDAR_FEATURES:
            continue
        parts = col.split("_", 1)
        assert len(parts) == 2 and parts[0] in {f"lag{o}" for o in LAG_OFFSETS}, (
            f"unexpected predictor column name: {col!r}"
        )
        base_name = parts[1]
        assert base_name in approved_base_names, f"predictor {col!r} is not in the approved feature set"

    # 5. none of the excluded leakage columns appear anywhere as predictors
    for excluded in EXCLUDED_COLUMNS:
        for col in predictor_cols:
            assert excluded not in col, f"excluded column {excluded!r} leaked into predictor {col!r}"

    # 6/7/8. each lag column and the target correspond to the correct timestamp,
    # re-derived independently from the source (un-lagged) dataset -- this
    # also proves no t+1-or-later information was ever used (lag0 == t,
    # never t+1; target is looked up at t, not shifted from a later row).
    indexed_source = source.set_index("timestamp")
    one_min = pd.Timedelta(minutes=1)
    sample = lagged if len(lagged) <= 50 else lagged.sample(50, random_state=0)
    for _, row in sample.iterrows():
        t = row["timestamp"]
        for offset in LAG_OFFSETS:
            ts = t - offset * one_min
            expected_row = indexed_source.loc[ts]
            for feature in PRIMARY_FEATURES:
                got = row[f"lag{offset}_{feature}"]
                expected = expected_row[feature]
                assert got == expected, (
                    f"lag{offset}_{feature} at {t} does not match source value at {ts}: "
                    f"got {got}, expected {expected}"
                )
        for feature in CALENDAR_FEATURES:
            assert row[feature] == indexed_source.loc[t, feature], (
                f"calendar feature {feature} at {t} does not match current-minute source value"
            )
        expected_target = indexed_source.loc[t, TARGET_COLUMN]
        assert row[TARGET_COLUMN] == expected_target, (
            f"target at {t} does not match source attack_next_minute: "
            f"got {row[TARGET_COLUMN]}, expected {expected_target}"
        )


def print_report(input_df: pd.DataFrame, lagged: pd.DataFrame, n_skipped: int) -> None:
    predictor_cols = get_predictor_columns(lagged)
    n_pos = int(lagged[TARGET_COLUMN].sum())
    n_neg = len(lagged) - n_pos
    pct_pos = 100 * n_pos / len(lagged) if len(lagged) else 0.0
    n_removed = len(input_df) - len(lagged)

    print(f"\ninput shape:  {input_df.shape}")
    print(f"output shape: {lagged.shape}")

    print(f"\ncomplete predictor list ({len(predictor_cols)}):")
    for c in predictor_cols:
        print(f"  - {c}")
    print(f"\ntarget name: {TARGET_COLUMN!r}")

    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", 250)
    print("\n--- first 5 rows ---")
    print(lagged.head(5).to_string())
    print("\n--- last 5 rows ---")
    print(lagged.tail(5).to_string())

    print(f"\npositive target count: {n_pos}")
    print(f"negative target count: {n_neg}")
    print(f"positive percentage:   {pct_pos:.2f}%")

    print(f"\nearliest prediction timestamp: {lagged['timestamp'].min()}")
    print(f"latest prediction timestamp:   {lagged['timestamp'].max()}")

    print(f"\nrows removed for history construction: {n_removed} "
          f"(expected 3 for the initial 3-minute lookback"
          + (f"; {n_skipped} additional row(s) skipped due to missing history" if n_skipped else "")
          + ")")


def main() -> None:
    input_df = load_forecasting_dataset()
    print(f"Loaded {len(input_df)} rows from {FORECASTING_DATASET_PATH}")

    lagged, n_skipped = build_lagged_dataset(input_df)

    run_sanity_checks(lagged, input_df)
    print("All sanity checks passed.")

    print_report(input_df, lagged, n_skipped)

    LAGGED_FORECASTING_DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    lagged.to_csv(LAGGED_FORECASTING_DATASET_PATH, index=False)
    print(f"\nSaved lagged forecasting dataset to {LAGGED_FORECASTING_DATASET_PATH} "
          f"({lagged.shape[0]} rows, {lagged.shape[1]} cols)")


if __name__ == "__main__":
    main()
