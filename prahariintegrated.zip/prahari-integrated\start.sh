#!/usr/bin/env bash
# Environment validation only -- checks Python, dependencies, and dataset
# presence. Does NOT start any services itself; for that, use
# ./demo/run_demo.sh (full backend + dashboard + demo walkthrough) or
# `uvicorn backend.app:app --port 8000` (backend only).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "SYSTEM: AI Network Attack Forecasting"
echo "PHASE: Environment Check"

fail() {
    echo "STATUS: FAILED - $1"
    exit 1
}

command -v python3 >/dev/null 2>&1 || fail "python3 not found"

PYTHON_VERSION=$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)
if [ "$PYTHON_MAJOR" -lt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]; }; then
    echo "  ! warning: Python $PYTHON_VERSION detected, 3.11+ recommended"
fi

for pkg in pandas numpy sklearn xgboost fastapi uvicorn joblib web3; do
    python3 -c "import $pkg" >/dev/null 2>&1 || fail "required package '$pkg' not installed (run: pip install -r requirements.txt)"
done

[ -d data/raw ] || fail "data/raw directory missing"
[ -d data/processed ] || fail "data/processed directory missing"

RAW_FILE_COUNT=$(find data/raw -name '*.csv' | wc -l)
if [ "$RAW_FILE_COUNT" -eq 0 ]; then
    echo "  ! note: no CSV files found in data/raw yet (see README's Dataset placement section)"
else
    echo "  found $RAW_FILE_COUNT CSV file(s) in data/raw"
fi

if [ -f data/processed/baseline_random_forest.joblib ] && [ -f data/processed/cleaned.csv ]; then
    echo "  forecasting pipeline artifacts present -- ready for ./demo/run_demo.sh"
else
    echo "  ! note: forecasting pipeline not yet built -- run the Commands in README before ./demo/run_demo.sh"
fi

echo "STATUS: READY"
