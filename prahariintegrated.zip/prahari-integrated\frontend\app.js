/* PRAHARI -- Network Attack Forecasting dashboard (Operational Clarity UI)
 *
 * Plain vanilla JS, no framework, no build step. Talks only to the real
 * FastAPI backend (backend/app.py). Nothing here invents a probability,
 * a transaction id, or a chart value that did not come back from the API.
 *
 * The page is served by the backend itself, so requests are same-origin.
 * Opened straight from disk (file://) it falls back to the documented
 * local backend at http://127.0.0.1:8000.
 *
 * One "hero" reading drives the whole first impression -- current risk,
 * predicted attack, forecast window, suspicious source/asset, why it was
 * flagged, recommended actions, and the blockchain proof for that exact
 * reading. A toggle switches which forecasting mode feeds the hero:
 *   - DEMONSTRATION_MODE  -- transparent rule-based heuristic (default,
 *     because it is the mode that earns a genuinely graded risk reading)
 *   - VALIDATED_MODEL_MODE -- the real trained RandomForest, honestly
 *     reported as UNVALIDATED (single-episode training data).
 * Both modes are fetched and cached every tick, so toggling is instant
 * and never blends the two.
 */
(() => {
  "use strict";

  // Where the API lives. The integrated build serves this page AND the
  // API from the same origin on port 8000, so same-origin ("") is right.
  // If the page is opened from disk (file://) or served separately on a
  // different port (e.g. demo/run_demo.sh's static server on :8080), fall
  // back to the documented local backend. Override explicitly with
  // ?api=http://host:port or window.PRAHARI_API_BASE if you run uvicorn
  // on a non-default port.
  const LOCAL_BACKEND = "http://127.0.0.1:8000";
  function resolveApiBase() {
    const q = new URLSearchParams(location.search).get("api");
    if (q) return q.replace(/\/$/, "");
    if (typeof window.PRAHARI_API_BASE === "string") return window.PRAHARI_API_BASE.replace(/\/$/, "");
    const isHttp = location.protocol === "http:" || location.protocol === "https:";
    const sameOriginServesApi = isHttp && (location.port === "8000" || location.port === "");
    return sameOriginServesApi ? "" : LOCAL_BACKEND;
  }
  const API_BASE = resolveApiBase();

  const POLL_INTERVAL_MS = 1000;
  const MODES = ["VALIDATED_MODEL_MODE", "DEMONSTRATION_MODE"];

  // Playback pace, in dataset-minutes per real second. The transport bar
  // lets a presenter slow this right down (Slow = 1 min/s) so a judge can
  // read each minute, pause on any minute, step one minute at a time, or
  // rewind to the start.
  const SPEED_LABEL = { 1: "Slow", 2: "Normal", 5: "Fast" };
  let playbackSpeed = 2;

  // Demo/local API key -- matches backend/security.py's PRAHARI_API_KEY
  // fallback. Not a production secret.
  const API_KEY_HEADER = "X-API-Key";
  const API_KEY = "demo-local-admin-key";

  let pollTimer = null;
  let heroMode = "DEMONSTRATION_MODE";

  let latestStatus = null;
  let leadTime = null;
  let currentForecasts = {};
  let currentEvents = {};
  let currentChain = {};

  const TREND_MAX = 48;
  let trend = []; // [{flows, baseline}] -- real observed values only
  let lastTrendMinute = -1; // only append a trend point when the replay minute advances

  // ---- fetch helpers: never throw ----------------------------------------

  async function apiGet(path) {
    try {
      const res = await fetch(API_BASE + path, { method: "GET" });
      return { ok: res.ok, status: res.status, data: await safeJson(res) };
    } catch (_) {
      return { ok: false, status: 0, data: null, networkError: true };
    }
  }

  async function apiPost(path, body) {
    try {
      const headers = { [API_KEY_HEADER]: API_KEY };
      if (body !== undefined) headers["Content-Type"] = "application/json";
      const res = await fetch(API_BASE + path, {
        method: "POST",
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      return { ok: res.ok, status: res.status, data: await safeJson(res) };
    } catch (_) {
      return { ok: false, status: 0, data: null, networkError: true };
    }
  }

  async function safeJson(res) {
    try { return await res.json(); } catch (_) { return null; }
  }

  // ---- tiny DOM helpers -------------------------------------------------

  const $ = (id) => document.getElementById(id);
  function text(id, value) { const el = $(id); if (el) el.textContent = value; }
  function textTip(id, value) { const el = $(id); if (el) { el.textContent = value; el.title = value; } }

  function pct(p) {
    if (p === null || p === undefined) return "n/a";
    return Math.round(p * 100) + "%";
  }
  function num(n) {
    if (n === null || n === undefined) return "--";
    return Number(n).toLocaleString();
  }

  function riskWord(rs) {
    switch (rs) {
      case "HIGH_RISK": return "HIGH RISK";
      case "CRITICAL": return "CRITICAL";
      case "ELEVATED": return "ELEVATED";
      case "NORMAL": return "NORMAL";
      case "UNVALIDATED": return "UNVALIDATED";
      default: return "--";
    }
  }

  // ---- connectivity / status -----------------------------------------

  function setOnline(isOnline, running) {
    const pill = $("conn-pill");
    pill.dataset.online = isOnline ? "true" : "false";
    text("conn-label", !isOnline ? "Offline" : running ? "Monitoring" : "Connected");
  }

  function renderStatus(status) {
    latestStatus = status;
    const r = status.replay || {};
    const idx = r.current_minute_index || 0;
    const total = r.total_minutes || 0;
    let feed = "Idle";
    if (!r.loaded) feed = "Dataset unavailable";
    else if (r.finished) feed = "Replay finished";
    else if (r.running) feed = `Live · min ${idx}/${total}`;
    else if (idx > 0) feed = `Paused · min ${idx}/${total}`;
    text("feed-status", feed);
    renderTransport(r);

    text("tech-replay", r.loaded ? `min ${idx}/${total}` : "unavailable");
    text("tech-model-loaded", status.model && status.model.model_loaded ? "yes" : "no");
    const bc = status.blockchain || {};
    text("tech-chain-id", bc.available ? bc.chain_id : (bc.unavailable_reason || "unavailable"));
    text("tech-chain-count", bc.records_stored !== undefined ? String(bc.records_stored) : "--");
    text("system-disclaimer", status.disclaimer || "");
  }

  // ---- transport bar (play / pause / step / rewind / speed) -----------

  function renderTransport(r) {
    const idx = r.current_minute_index || 0;
    const total = r.total_minutes || 0;
    const running = !!r.running;
    const finished = !!r.finished;

    text("replay-clock", r.loaded ? `min ${idx} / ${total}` : "dataset unavailable");

    const icon = $("pp-icon");
    const label = $("pp-label");
    if (icon && label) {
      if (running) { icon.textContent = "pause"; label.textContent = "Pause"; }
      else if (finished) { icon.textContent = "replay"; label.textContent = "Replay"; }
      else if (idx > 0) { icon.textContent = "play_arrow"; label.textContent = "Resume"; }
      else { icon.textContent = "play_arrow"; label.textContent = "Play"; }
    }

    // Stepping and rewinding only make sense while the replay is paused.
    const setDisabled = (id, v) => { const el = $(id); if (el) el.disabled = v; };
    setDisabled("btn-step-back", running || !r.loaded || idx <= 0);
    setDisabled("btn-step-fwd", running || !r.loaded || idx >= total);
    setDisabled("btn-restart", !r.loaded);
  }

  function setSpeedButtons() {
    document.querySelectorAll(".speed-btn").forEach((b) => {
      b.setAttribute("aria-selected", Number(b.dataset.mps) === playbackSpeed ? "true" : "false");
    });
  }

  // stop_replay() only signals the loop; it exits after finishing its
  // current sleep. Give it a moment so a follow-up start/seek doesn't 409.
  async function waitUntilStopped(maxTries) {
    for (let i = 0; i < (maxTries || 25); i++) {
      const s = await apiGet("/status");
      if (!s.ok || !s.data.replay || !s.data.replay.running) return;
      await new Promise((res) => setTimeout(res, 120));
    }
  }

  function resetLocalCaches() {
    trend = [];
    currentForecasts = {};
    currentEvents = {};
    currentChain = {};
  }

  function renderLeadTime() {
    if (!leadTime || leadTime.available === false) { text("tech-lead-time", "not computed"); return; }
    const d = leadTime.demonstration_mode;
    if (d && d.lead_time_minutes !== undefined && d.lead_time_minutes !== null) {
      text("tech-lead-time", `${d.lead_time_minutes} min (heuristic)`);
    } else {
      text("tech-lead-time", "n/a");
    }
  }

  // ---- traffic trend sparkline -------------------------------------------

  function pushTrend(flows, baseline) {
    trend.push({ flows, baseline });
    if (trend.length > TREND_MAX) trend.shift();
  }

  function renderSparkline() {
    const empty = $("chart-empty");
    if (trend.length < 2) {
      empty.hidden = false;
      ["spark-actual", "spark-area", "spark-baseline"].forEach((id) => {
        const el = $(id);
        if (el) el.setAttribute("d", "");
      });
      const dot = $("spark-dot");
      if (dot) dot.style.display = "none";
      text("spark-baseline-label", "Baseline: --");
      return;
    }
    empty.hidden = true;

    const W = 300, H = 80, PAD = 4;
    const flows = trend.map((p) => p.flows);
    const baselines = trend.map((p) => p.baseline).filter((v) => v !== null && v !== undefined);
    const maxV = Math.max(...flows, ...baselines, 1) * 1.12;
    const n = trend.length;
    const xStep = n > 1 ? (W - 2 * PAD) / (n - 1) : 0;
    const yFor = (v) => H - PAD - (v / maxV) * (H - 2 * PAD);
    const xFor = (i) => PAD + i * xStep;

    const linePts = flows.map((v, i) => `${xFor(i).toFixed(1)} ${yFor(v).toFixed(1)}`);
    const actualPath = "M" + linePts.join(" L");
    const areaPath =
      `M${xFor(0).toFixed(1)} ${H} L` + linePts.join(" L") + ` L${xFor(n - 1).toFixed(1)} ${H} Z`;

    $("spark-actual").setAttribute("d", actualPath);
    $("spark-area").setAttribute("d", areaPath);

    const latestBaseline = trend[trend.length - 1].baseline;
    if (latestBaseline !== null && latestBaseline !== undefined) {
      const y = yFor(latestBaseline).toFixed(1);
      $("spark-baseline").setAttribute("d", `M${PAD} ${y} L${W - PAD} ${y}`);
      $("spark-baseline-label").textContent = `Baseline: ${Math.round(latestBaseline).toLocaleString()} flows/min`;
    } else {
      $("spark-baseline").setAttribute("d", "");
      $("spark-baseline-label").textContent = "Baseline: not available";
    }

    const dot = $("spark-dot");
    dot.setAttribute("cx", xFor(n - 1).toFixed(1));
    dot.setAttribute("cy", yFor(flows[flows.length - 1]).toFixed(1));
    dot.style.display = "";

    text("spark-tmin", `-${n - 1} min`);
  }

  function renderDeviation(baselineRes) {
    const d = baselineRes && baselineRes.data;
    if (!d || !d.available || !d.features || !d.features.total_flows) {
      text("spark-deviation", "baseline n/a");
      return;
    }
    const tf = d.features.total_flows;
    const dev = tf.deviation_std_devs;
    if (dev === null || dev === undefined) { text("spark-deviation", "--"); return; }
    const sign = dev >= 0 ? "+" : "";
    text("spark-deviation", `${sign}${dev.toFixed(1)}σ vs baseline`);
  }

  // ---- hero + evidence -------------------------------------------------

  function fillList(el, items, emptyMsg, pick) {
    el.innerHTML = "";
    if (!items || items.length === 0) {
      const li = document.createElement("li");
      li.className = "empty-item";
      li.textContent = emptyMsg;
      el.appendChild(li);
      return;
    }
    for (const it of items) {
      const li = document.createElement("li");
      li.textContent = pick(it);
      el.appendChild(li);
    }
  }

  function patternText(pm) {
    if (!pm || pm.status === "NOT_AVAILABLE") return "not available";
    if (pm.status === "NO_MATCH") return `no match (best ${pct(pm.similarity_score)})`;
    return `${pm.matched_pattern_name} (${pct(pm.similarity_score)})`;
  }

  function baselineShift(bc) {
    if (!bc || !bc.available) return "not available";
    const label = (bc.overall_status || "UNKNOWN").replace(/_/g, " ").toLowerCase();
    const tf = bc.features && bc.features.total_flows;
    if (tf && tf.deviation_std_devs !== null && tf.deviation_std_devs !== undefined) {
      const s = tf.deviation_std_devs >= 0 ? "+" : "";
      return `${label} (${s}${tf.deviation_std_devs.toFixed(1)}σ)`;
    }
    return label;
  }

  function renderHero(mode) {
    const f = currentForecasts[mode];
    const ev = currentEvents[mode];
    const chain = currentChain[mode] || { record: null, verify: null };

    const scopes = document.querySelectorAll(".risk-scope");

    const footnote = $("hero-footnote");
    if (mode === "VALIDATED_MODEL_MODE") {
      footnote.innerHTML =
        "Reading shown is <strong>VALIDATED_MODEL_MODE</strong> -- the real trained RandomForestClassifier, " +
        "run as-is. Its risk reading is always shown as <strong>UNVALIDATED</strong> (single-episode training " +
        "data, no independent held-out attack). This is <strong>NOT a trained AI model</strong> result you " +
        "should act on yet -- see Technical &amp; Validation Details.";
    } else {
      footnote.innerHTML =
        "Reading shown is <strong>DEMONSTRATION_MODE</strong> -- a transparent rule-based <strong>HEURISTIC</strong>, " +
        "<strong>NOT a trained AI model</strong>. Switch the toggle to see the real trained RandomForest " +
        "(<strong>VALIDATED_MODEL_MODE</strong>), reported honestly.";
    }

    if (!f || !f.ready) {
      scopes.forEach((s) => (s.dataset.risk = "UNKNOWN"));
      text("hero-event-id", "--");
      text("triage-event-id", "no event yet");
      text("hero-risk-state", f && f.model_status ? f.model_status.replace(/_/g, " ") : "waiting");
      text("hero-risk-score", "--");
      text("hero-trend", "--");
      text("hero-asof", "--");
      $("hero-headline").textContent = "Is an attack likely in the next 30 minutes?";
      fillList($("hero-evidence"), null, "No evidence yet -- press Play.", () => "");
      fillList($("hero-actions"), null, "No threat event generated yet.", () => "");
      text("analysis-summary", "Waiting for the first forecast…");
      text("ai-assessment", "Awaiting model output…");
      text("ai-confidence", "--");
      ["ev-attack", "ev-window", "ev-source", "ev-asset", "ev-shift", "ev-pattern"].forEach((i) => text(i, "--"));
      renderProof(null, null, null);
      return;
    }

    const rs = f.risk_state || "UNKNOWN";
    scopes.forEach((s) => (s.dataset.risk = rs));

    text("hero-event-id", ev ? ev.event_id : "pending");
    text("triage-event-id", ev ? ev.event_id : "no event yet");
    text("hero-risk-state", riskWord(rs));

    text("hero-risk-score", rs === "UNVALIDATED" ? "n/a" : pct(f.probability));

    // Trend from the sparkline direction (real observed flows).
    let trendWord = "Stable", trendIcon = "trending_flat";
    if (trend.length >= 3) {
      const a = trend[trend.length - 3].flows, b = trend[trend.length - 1].flows;
      if (b > a * 1.05) { trendWord = "Increasing"; trendIcon = "trending_up"; }
      else if (b < a * 0.95) { trendWord = "Decreasing"; trendIcon = "trending_down"; }
    }
    text("hero-trend", trendWord);
    $("hero-trend-icon").textContent = trendIcon;

    text("hero-asof", latestStatus && latestStatus.replay
      ? `min ${latestStatus.replay.current_minute_index}` : "--");

    const src = f.suspicious_source;
    if (rs === "HIGH_RISK" || rs === "CRITICAL" || rs === "ELEVATED") {
      const where = src && src.destination_ip ? ` on ${src.destination_ip}` : "";
      $("hero-headline").textContent = `${f.attack_type || "Attack"} risk in the next 30 minutes${where}`;
    } else if (rs === "UNVALIDATED") {
      $("hero-headline").textContent = "Trained model output (unvalidated) for the next 30 minutes";
    } else {
      $("hero-headline").textContent = "No elevated attack risk in the next 30 minutes";
    }

    fillList($("hero-evidence"), f.evidence, "No evidence signals this minute.",
      (it) => it.description || it.signal);
    fillList($("hero-actions"), ev && ev.recommended_actions, "No threat event generated yet.",
      (a) => a);

    text("analysis-summary", f.explanation || "--");
    text("ai-assessment", f.explanation || "--");
    text("ai-confidence",
      f.confidence === null || f.confidence === undefined ? "n/a (unvalidated)" : f.confidence.toFixed(2));

    textTip("ev-attack", f.attack_type || "none");
    text("ev-window", (f.forecast_window && f.forecast_window.label) || "--");
    if (src && src.source_ip) {
      const share = src.flow_share !== null && src.flow_share !== undefined
        ? ` (${pct(src.flow_share)} of flows)` : "";
      textTip("ev-source", `${src.source_ip}${share}`);
      textTip("ev-asset", src.destination_ip
        ? `${src.destination_ip}${src.destination_port !== null && src.destination_port !== undefined ? ":" + src.destination_port : ""}`
        : "none identified this minute");
    } else {
      text("ev-source", "none identified this minute");
      text("ev-asset", "none identified this minute");
    }
    textTip("ev-shift", baselineShift(ev && ev.baseline_comparison));
    textTip("ev-pattern", patternText(ev && ev.pattern_match));

    renderProof(ev, chain.record, chain.verify);
  }

  function renderProof(event, record, verify) {
    $("proof-threat").classList.toggle("is-done", !!event);
    text("proof-threat-text", event ? "created" : "pending");

    const recorded = !!(record && record.chain_status && record.chain_status !== "BLOCKCHAIN_UNAVAILABLE");
    $("proof-chain").classList.toggle("is-done", recorded);
    text("proof-chain-text", record && record.chain_status ? record.chain_status.toLowerCase() : "pending");

    const verified = !!(verify && verify.verified);
    $("proof-verify").classList.toggle("is-done", verified);
    text("proof-verify-text", verify ? (verify.verified ? "verified" : "not verified") : "pending");

    textTip("proof-tx", record && record.blockchain_transaction_id ? record.blockchain_transaction_id : "--");
    text("proof-block",
      record && record.block_number !== null && record.block_number !== undefined ? record.block_number : "--");
  }

  function renderEntities(sources) {
    const el = $("entities-strip");
    el.innerHTML = "";
    if (!sources || sources.length === 0) {
      el.innerHTML = '<div class="text-[12px] text-on-surface-variant italic">None tracked yet -- press Play.</div>';
      return;
    }
    for (const s of sources) {
      const share = Math.round((s.flow_share || 0) * 100);
      const row = document.createElement("div");
      row.className = "flex items-center gap-2 p-2 bg-surface-container-low rounded-lg";
      row.innerHTML =
        `<span class="text-[11px] font-bold ${s.rank === 1 ? "text-error" : "text-on-surface-variant"} w-6 shrink-0">#${s.rank}</span>` +
        `<span class="font-mono text-[12px] text-on-surface w-32 shrink-0 truncate">${s.source_ip}</span>` +
        `<span class="flex-1 h-1.5 rounded-full bg-surface-container-high overflow-hidden"><span class="block h-full bg-secondary" style="width:${Math.min(100, share)}%"></span></span>` +
        `<span class="font-mono text-[11px] text-on-surface-variant shrink-0">${num(s.flow_count)} · ${share}%</span>`;
      el.appendChild(row);
    }
  }

  // ---- technical panel -----------------------------------------------

  function renderTech() {
    const fill = (prefix, f) => {
      if (!f) {
        ["status", "score", "confidence", "risk", "explanation"].forEach((k) => text(`tech-${prefix}-${k}`, "--"));
        return;
      }
      text(`tech-${prefix}-status`, f.model_status || "--");
      text(`tech-${prefix}-score`, f.ready ? pct(f.probability) : "not ready");
      text(`tech-${prefix}-confidence`,
        f.ready && f.confidence !== null && f.confidence !== undefined ? f.confidence.toFixed(2) : "--");
      text(`tech-${prefix}-risk`, f.risk_state || "--");
      text(`tech-${prefix}-explanation`, f.explanation || "--");
    };
    fill("demo", currentForecasts["DEMONSTRATION_MODE"]);
    fill("validated", currentForecasts["VALIDATED_MODEL_MODE"]);

    const ev = currentEvents[heroMode];
    const pm = ev && ev.pattern_match;
    if (!pm || pm.status === "NOT_AVAILABLE") {
      text("tech-pattern-name", "not available");
      text("tech-pattern-score", "--");
      text("tech-pattern-incidents", "--");
      text("tech-pattern-mitre", "--");
    } else {
      text("tech-pattern-name", pm.status === "NO_MATCH" ? "no known pattern matched" : pm.matched_pattern_name);
      text("tech-pattern-score", pct(pm.similarity_score));
      text("tech-pattern-incidents", String((pm.matched_historical_incidents || []).length));
      text("tech-pattern-mitre",
        pm.mitre_technique ? `${pm.mitre_tactic || ""} / ${pm.mitre_technique}`.replace(/^ \/ /, "") : "--");
    }
  }

  // ---- poll loop ------------------------------------------------------

  async function pollOnce() {
    const status = await apiGet("/status");
    if (!status.ok) {
      setOnline(false, false);
      text("feed-status", "Backend offline");
      return;
    }
    const running = !!(status.data.replay && status.data.replay.running);
    setOnline(true, running);
    renderStatus(status.data);

    if (leadTime === null) {
      const lt = await apiGet("/metrics/lead_time");
      leadTime = lt.ok ? lt.data : { available: false };
      renderLeadTime();
    }

    const minuteNow = (status.data.replay && status.data.replay.current_minute_index) || 0;
    const trafficRes = await apiGet("/traffic/current");
    let baselineRes = { ok: false, data: null };
    if (trafficRes.ok && trafficRes.data && trafficRes.data.observed_traffic) {
      baselineRes = await apiGet("/baseline");
      const baseMean =
        baselineRes.ok && baselineRes.data && baselineRes.data.available
          ? (baselineRes.data.features.total_flows && baselineRes.data.features.total_flows.normal_mean)
          : null;
      // Only record a new trend point when the replay minute actually
      // advanced -- so pausing (or a step) doesn't pile up flat points.
      if (minuteNow !== lastTrendMinute) {
        pushTrend(trafficRes.data.observed_traffic.total_flows, baseMean);
        lastTrendMinute = minuteNow;
      }
    }
    renderSparkline();
    renderDeviation(baselineRes);

    for (const mode of MODES) {
      const r = await apiGet(`/forecast?mode=${mode}`);
      currentForecasts[mode] = r.ok ? r.data : null;
    }

    // Drive the threat + blockchain pipeline forward for each ready mode.
    // Idempotent on the backend (deterministic event_id), safe to repeat.
    if (trafficRes.ok) {
      for (const mode of MODES) {
        if (currentForecasts[mode] && currentForecasts[mode].ready) {
          const gen = await apiPost(`/threats/generate?mode=${mode}`);
          if (gen.ok && gen.data && gen.data.event) {
            await apiPost("/blockchain/record", { event_id: gen.data.event.event_id });
          }
        }
      }
    }

    const threatsRes = await apiGet("/threats");
    const latestByMode = {};
    if (threatsRes.ok && threatsRes.data && threatsRes.data.events) {
      for (const e of threatsRes.data.events) {
        if (!latestByMode[e.forecast_mode]) latestByMode[e.forecast_mode] = e;
      }
    }
    currentEvents = latestByMode;

    for (const mode of MODES) {
      const e = latestByMode[mode] || null;
      if (e) {
        const rec = await apiGet(`/blockchain/records/${e.event_id}`);
        let ver = null;
        if (rec.ok) ver = await apiPost(`/blockchain/verify/${e.event_id}`);
        currentChain[mode] = {
          record: rec.ok ? rec.data : null,
          verify: ver && ver.ok ? ver.data : null,
        };
      } else {
        currentChain[mode] = { record: null, verify: null };
      }
    }

    renderEntities(currentForecasts[heroMode] && currentForecasts[heroMode].suspicious_sources);
    renderHero(heroMode);
    renderTech();
  }

  function startPolling() {
    if (pollTimer) return;
    pollOnce();
    pollTimer = setInterval(pollOnce, POLL_INTERVAL_MS);
  }

  // ---- controls -----------------------------------------------------

  function setControlMessage(msg) { text("control-message", msg || ""); }

  document.querySelectorAll(".mode-toggle-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      heroMode = btn.dataset.mode;
      document.querySelectorAll(".mode-toggle-btn").forEach((b) => {
        b.setAttribute("aria-selected", b === btn ? "true" : "false");
      });
      renderEntities(currentForecasts[heroMode] && currentForecasts[heroMode].suspicious_sources);
      renderHero(heroMode);
      renderTech();
    });
  });

  // --- speed selector: 1 / 2 / 5 dataset-minutes per real second ------
  document.querySelectorAll(".speed-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      playbackSpeed = Number(btn.dataset.mps);
      setSpeedButtons();
      const s = await apiGet("/status");
      const wasRunning = s.ok && s.data.replay && s.data.replay.running;
      if (wasRunning) {
        // Re-launch at the new pace; run_async resumes from the current
        // minute, so the speed change is seamless.
        await apiPost("/replay/stop");
        await waitUntilStopped();
        await apiPost("/replay/start", { minutes_per_second: playbackSpeed });
        setControlMessage(`Speed: ${SPEED_LABEL[playbackSpeed]} (${playbackSpeed} min/s).`);
      } else {
        setControlMessage(`Speed set to ${SPEED_LABEL[playbackSpeed]} (${playbackSpeed} min/s). Press Play.`);
      }
      pollOnce();
    });
  });

  // --- play / pause / resume / replay -------------------------------
  $("btn-playpause").addEventListener("click", async () => {
    const s = await apiGet("/status");
    const r = (s.ok && s.data.replay) || {};
    if (r.running) {
      await apiPost("/replay/stop");
      setControlMessage(`Paused at minute ${r.current_minute_index}.`);
    } else if (r.finished) {
      await apiPost("/replay/stop");
      await waitUntilStopped();
      await apiPost("/replay/reset");
      resetLocalCaches();
      lastTrendMinute = -1;
      await apiPost("/replay/start", { minutes_per_second: playbackSpeed });
      setControlMessage(`Replaying from the start at ${SPEED_LABEL[playbackSpeed]} speed.`);
    } else {
      const res = await apiPost("/replay/start", { minutes_per_second: playbackSpeed });
      if (res.ok) {
        setControlMessage(
          (r.current_minute_index > 0 ? "Resumed" : "Playing") +
            ` at ${SPEED_LABEL[playbackSpeed]} speed (${playbackSpeed} min/s).`
        );
      } else if (res.status === 409) {
        setControlMessage((res.data && res.data.detail) || "Replay already running.");
      } else {
        setControlMessage("Could not start replay -- backend unreachable?");
      }
    }
    pollOnce();
  });

  // --- rewind to the beginning and play again ----------------------
  $("btn-restart").addEventListener("click", async () => {
    setControlMessage("Rewinding to the beginning…");
    await apiPost("/replay/stop");
    await waitUntilStopped();
    await apiPost("/replay/reset");
    resetLocalCaches();
    lastTrendMinute = -1;
    await apiPost("/replay/start", { minutes_per_second: playbackSpeed });
    setControlMessage(`Replaying from minute 0 at ${SPEED_LABEL[playbackSpeed]} speed.`);
    pollOnce();
  });

  // --- step one minute back / forward (while paused) --------------
  async function stepBy(delta) {
    const s = await apiGet("/status");
    const r = (s.ok && s.data.replay) || {};
    if (r.running) {
      await apiPost("/replay/stop");
      await waitUntilStopped();
    }
    const total = r.total_minutes || 0;
    const target = Math.max(0, Math.min((r.current_minute_index || 0) + delta, total));
    const res = await apiPost("/replay/seek", { minute: target });
    // The backend rebuilds forecasting state for `target`; our trend
    // history no longer matches, so restart it from this point.
    trend = [];
    lastTrendMinute = -1;
    currentEvents = {};
    currentChain = {};
    if (res.ok) setControlMessage(`Stepped to minute ${(res.data && res.data.minute) != null ? res.data.minute : target}.`);
    else setControlMessage((res.data && res.data.detail) || "Step failed -- backend unreachable?");
    pollOnce();
  }
  $("btn-step-back").addEventListener("click", () => stepBy(-1));
  $("btn-step-fwd").addEventListener("click", () => stepBy(1));

  // --- clear everything -------------------------------------------
  $("btn-reset").addEventListener("click", async () => {
    setControlMessage("Clearing all state…");
    await apiPost("/replay/stop");
    await waitUntilStopped();
    const res = await apiPost("/replay/reset");
    resetLocalCaches();
    lastTrendMinute = -1;
    setControlMessage(res.ok
      ? "Cleared. Press Play to begin again."
      : (res.data && res.data.detail) || "Reset failed -- backend unreachable?");
    pollOnce();
  });

  setSpeedButtons();
  startPolling();
})();
