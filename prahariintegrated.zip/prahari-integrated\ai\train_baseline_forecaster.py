"""Train and evaluate ONE baseline forecasting model.

Reads data/processed/lagged_forecasting_dataset.csv (the locked 3-minute
lookback / 1-minute horizon formulation) and trains a single
RandomForestClassifier on a strict chronological split, chosen so the test
portion contains the dataset's one attack episode in full (onset through
offset) -- this is a proof-of-concept baseline, not a tuned or compared
model. See the printed disclaimer at the end of this script's output.

Run:
    python ai/train_baseline_forecaster.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from ai.config import PROCESSED_DATA_DIR

LAGGED_DATASET_PATH = PROCESSED_DATA_DIR / "lagged_forecasting_dataset.csv"
MODEL_PATH = PROCESSED_DATA_DIR / "baseline_random_forest.joblib"
PREDICTIONS_PATH = PROCESSED_DATA_DIR / "baseline_predictions.csv"
METRICS_PATH = PROCESSED_DATA_DIR / "baseline_metrics.json"

TARGET_COLUMN = "attack_next_minute"

# Must never appear as predictor columns (Task 5 leakage guard).
EXCLUDED_COLUMNS = [
    "benign_flows",
    "attack_flows",
    "attack_ratio",
    "attack_next_minute",
    "attack_count_next_minute",
    "attack_ratio_next_minute",
    "day_of_week",
]

DISCLAIMER = (
    "This is a proof-of-concept baseline on a single attack episode.\n"
    "The evaluation does not establish generalization to unseen attacks/campaigns."
)


def load_dataset(path: Path = LAGGED_DATASET_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python ai/build_lagged_forecasting_dataset.py` first."
        )
    df = pd.read_csv(path, low_memory=False)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df.sort_values("timestamp").reset_index(drop=True)


def guard_against_leakage(df: pd.DataFrame) -> list[str]:
    """Task 5: assert no excluded column exists anywhere, and build the
    approved predictor list (everything except timestamp and the target)."""
    # attack_next_minute is the target itself (legitimately present, as a
    # label, not a predictor); every OTHER excluded column must be fully
    # absent from the dataset -- the lagged dataset was built to never
    # include them at all, so their presence would indicate a pipeline bug.
    other_excluded = [c for c in EXCLUDED_COLUMNS if c != TARGET_COLUMN]
    present_excluded = [c for c in other_excluded if c in df.columns]
    assert not present_excluded, (
        f"Leakage-excluded column(s) found in dataset: {present_excluded}. "
        "These must never be available to the model."
    )
    assert TARGET_COLUMN in df.columns, f"target column {TARGET_COLUMN!r} missing from dataset"

    predictor_columns = [c for c in df.columns if c not in ("timestamp", TARGET_COLUMN)]
    for col in EXCLUDED_COLUMNS:
        assert col not in predictor_columns, f"excluded column {col!r} found among predictors"
    assert TARGET_COLUMN not in predictor_columns, "target column leaked into predictor set"

    return predictor_columns


def chronological_split(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, int]:
    """Choose a split boundary from label structure alone (no model peeking).

    A plain 70-80% row-count split would place this dataset's entire single
    attack episode (rows 23-43, timestamps 03:55-04:15) inside the training
    portion, leaving a 100%-benign test set -- useless for evaluating
    forecasting of an attack. Instead, the boundary is placed immediately
    before the first attack_next_minute=1 row, so the test set captures the
    full episode (onset through offset) plus trailing calm traffic. This
    deviates from the generic 70-80%-train guideline; the resulting split
    percentages are reported explicitly below rather than hidden.
    """
    positive_idx = df.index[df[TARGET_COLUMN] == 1]
    if len(positive_idx) == 0:
        raise ValueError("no positive attack_next_minute rows found; cannot choose a meaningful split")

    split_idx = int(positive_idx.min())
    train_df = df.iloc[:split_idx].reset_index(drop=True)
    test_df = df.iloc[split_idx:].reset_index(drop=True)
    return train_df, test_df, split_idx


def print_split_report(df: pd.DataFrame, train_df: pd.DataFrame, test_df: pd.DataFrame) -> None:
    total = len(df)
    total_pos = int(df[TARGET_COLUMN].sum())
    total_neg = total - total_pos

    print("\n--- Dataset overview ---")
    print(f"total rows: {total}")
    print(f"positive (attack_next_minute=1): {total_pos}")
    print(f"negative (attack_next_minute=0): {total_neg}")

    print("\n--- Chronological split ---")
    print("Split boundary chosen from label structure: a plain 70-80% row-count "
          "split would place the entire (single) attack episode inside training, "
          "leaving test 100% benign and unable to evaluate forecasting of the "
          "attack. Boundary is placed immediately before the first positive row "
          "instead, so test captures the full episode plus trailing calm traffic.")
    print(f"train end timestamp (last train row):  {train_df['timestamp'].iloc[-1]}")
    print(f"test start timestamp (first test row): {test_df['timestamp'].iloc[0]}")
    print(f"train rows: {len(train_df)} ({100*len(train_df)/total:.1f}% of total)")
    print(f"  positive: {int(train_df[TARGET_COLUMN].sum())}  negative: {int((train_df[TARGET_COLUMN]==0).sum())}")
    print(f"test rows:  {len(test_df)} ({100*len(test_df)/total:.1f}% of total)")
    print(f"  positive: {int(test_df[TARGET_COLUMN].sum())}  negative: {int((test_df[TARGET_COLUMN]==0).sum())}")

    if train_df[TARGET_COLUMN].nunique() < 2:
        print("\n! WARNING: training portion contains only a single class "
              f"({sorted(train_df[TARGET_COLUMN].unique())}). This is a direct "
              "consequence of having only one attack episode in the whole dataset. "
              "The model below cannot learn to discriminate attack vs. benign from "
              "training data alone -- see the honesty disclaimer at the end.")


def train_model(train_df: pd.DataFrame, predictor_columns: list[str]) -> RandomForestClassifier:
    X_train = train_df[predictor_columns].to_numpy()
    y_train = train_df[TARGET_COLUMN].to_numpy()
    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        class_weight="balanced",
    )
    model.fit(X_train, y_train)
    return model


def predict_positive_proba(model: RandomForestClassifier, X: np.ndarray) -> np.ndarray:
    """Probability of class 1, robust to a model that never saw class 1
    during training (predict_proba would otherwise only have one column)."""
    classes = list(model.classes_)
    proba = model.predict_proba(X)
    if 1 in classes:
        return proba[:, classes.index(1)]
    return np.zeros(len(X))


def evaluate(model: RandomForestClassifier, test_df: pd.DataFrame, predictor_columns: list[str]) -> dict:
    X_test = test_df[predictor_columns].to_numpy()
    y_test = test_df[TARGET_COLUMN].to_numpy()

    y_pred = model.predict(X_test)
    y_proba = predict_positive_proba(model, X_test)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

    roc_auc = None
    roc_auc_note = None
    if len(np.unique(y_test)) == 2:
        roc_auc = float(roc_auc_score(y_test, y_proba))
    else:
        roc_auc_note = "ROC-AUC not computed: test set does not contain both classes."

    n_pred_pos = int((y_pred == 1).sum())
    if n_pred_pos == 0:
        precision_note = "undefined (model made zero positive predictions on the test set)"
    else:
        precision_note = None

    return {
        "y_test": y_test,
        "y_pred": y_pred,
        "y_proba": y_proba,
        "accuracy": accuracy,
        "precision": precision,
        "precision_note": precision_note,
        "recall": recall,
        "f1": f1,
        "confusion_matrix": cm,
        "roc_auc": roc_auc,
        "roc_auc_note": roc_auc_note,
    }


def analyze_forecast_timing(test_df: pd.DataFrame, y_pred: np.ndarray) -> dict:
    """Attack onset time, first CORRECT positive forecast, and lead time.

    'Correct' means a true positive: the model predicted 1 AND the actual
    target was also 1 -- a positive prediction on a benign minute does not
    count. Lead time is only ever reported as computed from real values;
    if the first correct forecast happens at/after the attack has begun,
    the resulting (zero or negative) lead time is reported as such, never
    inflated into a fabricated positive number.
    """
    one_min = pd.Timedelta(minutes=1)
    y_actual = test_df[TARGET_COLUMN].to_numpy()
    timestamps = test_df["timestamp"].to_numpy()

    first_pos_idx = np.argmax(y_actual == 1)  # y_actual guaranteed to contain a 1 by split construction
    attack_onset_time = pd.Timestamp(timestamps[first_pos_idx]) + one_min

    correct_positive_mask = (y_pred == 1) & (y_actual == 1)
    if correct_positive_mask.any():
        first_correct_idx = np.argmax(correct_positive_mask)
        first_correct_forecast_time = pd.Timestamp(timestamps[first_correct_idx])
        forecast_target_time = first_correct_forecast_time + one_min
        lead_time_minutes = (attack_onset_time - forecast_target_time).total_seconds() / 60
    else:
        first_correct_forecast_time = None
        forecast_target_time = None
        lead_time_minutes = None

    return {
        "attack_onset_time_in_test": attack_onset_time,
        "first_correct_positive_forecast_time": first_correct_forecast_time,
        "forecast_target_time": forecast_target_time,
        "forecast_lead_time_minutes": lead_time_minutes,
    }


def print_evaluation(results: dict, timing: dict) -> None:
    print("\n--- Evaluation (test set) ---")
    print(f"accuracy:  {results['accuracy']:.4f}")
    print(f"precision: {results['precision']:.4f}" + (f"  ({results['precision_note']})" if results['precision_note'] else ""))
    print(f"recall:    {results['recall']:.4f}")
    print(f"f1:        {results['f1']:.4f}")
    print("confusion matrix (rows=actual [0,1], cols=predicted [0,1]):")
    print(results["confusion_matrix"])
    if results["roc_auc"] is not None:
        print(f"roc_auc:   {results['roc_auc']:.4f}")
    else:
        print(f"roc_auc:   not reported -- {results['roc_auc_note']}")

    print("\n--- Forecast timing analysis ---")
    print(f"attack_onset_time_in_test: {timing['attack_onset_time_in_test']}")
    if timing["first_correct_positive_forecast_time"] is not None:
        print(f"first_correct_positive_forecast_time: {timing['first_correct_positive_forecast_time']}")
        print(f"  (forecast target time: {timing['forecast_target_time']})")
        lead = timing["forecast_lead_time_minutes"]
        if lead > 0:
            print(f"forecast lead time: {lead:.0f} minute(s) BEFORE actual onset (advance warning)")
        elif lead == 0:
            print(f"forecast lead time: 0 minutes (correctly forecasted exactly the onset minute, no earlier)")
        else:
            print(f"forecast lead time: {lead:.0f} minute(s) -- NEGATIVE: first correct forecast came "
                  f"AFTER the attack had already begun (no advance warning)")
    else:
        print("first_correct_positive_forecast_time: None -- the model never correctly predicted "
              "attack_next_minute=1 anywhere in the test set")
        print("forecast lead time: N/A (no correct positive forecast to measure from)")


def print_per_row_predictions(test_df: pd.DataFrame, results: dict) -> pd.DataFrame:
    out = pd.DataFrame({
        "timestamp": test_df["timestamp"],
        "actual": results["y_test"],
        "predicted": results["y_pred"],
        "predicted_probability": results["y_proba"],
    })
    print("\n--- Per-row test predictions ---")
    print(out.to_string(index=False))
    return out


def main() -> None:
    df = load_dataset()
    predictor_columns = guard_against_leakage(df)
    print(f"Loaded {len(df)} rows, {len(predictor_columns)} approved predictor columns, "
          f"target={TARGET_COLUMN!r}")

    train_df, test_df, split_idx = chronological_split(df)
    print_split_report(df, train_df, test_df)

    model = train_model(train_df, predictor_columns)
    results = evaluate(model, test_df, predictor_columns)
    timing = analyze_forecast_timing(test_df, results["y_pred"])

    print_evaluation(results, timing)
    predictions_df = print_per_row_predictions(test_df, results)

    # --- Save artifacts (Task 4) ---
    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    predictions_df.to_csv(PREDICTIONS_PATH, index=False)

    metrics = {
        "formulation": {
            "history_minutes": 3,
            "forecast_horizon_minutes": 1,
            "target": TARGET_COLUMN,
            "n_predictors": len(predictor_columns),
        },
        "split": {
            "total_rows": len(df),
            "train_rows": len(train_df),
            "test_rows": len(test_df),
            "train_positive": int(train_df[TARGET_COLUMN].sum()),
            "test_positive": int(test_df[TARGET_COLUMN].sum()),
            "train_end_timestamp": str(train_df["timestamp"].iloc[-1]),
            "test_start_timestamp": str(test_df["timestamp"].iloc[0]),
            "train_single_class": bool(train_df[TARGET_COLUMN].nunique() < 2),
        },
        "metrics": {
            "accuracy": results["accuracy"],
            "precision": results["precision"],
            "precision_note": results["precision_note"],
            "recall": results["recall"],
            "f1": results["f1"],
            "confusion_matrix": results["confusion_matrix"].tolist(),
            "roc_auc": results["roc_auc"],
            "roc_auc_note": results["roc_auc_note"],
        },
        "forecast_timing": {
            "attack_onset_time_in_test": str(timing["attack_onset_time_in_test"]),
            "first_correct_positive_forecast_time": (
                str(timing["first_correct_positive_forecast_time"])
                if timing["first_correct_positive_forecast_time"] is not None else None
            ),
            "forecast_lead_time_minutes": timing["forecast_lead_time_minutes"],
        },
        "disclaimer": DISCLAIMER,
    }
    with open(METRICS_PATH, "w") as fh:
        json.dump(metrics, fh, indent=2, default=str)

    print(f"\nSaved model to:       {MODEL_PATH}")
    print(f"Saved predictions to: {PREDICTIONS_PATH}")
    print(f"Saved metrics to:     {METRICS_PATH}")

    print("\n" + "=" * 70)
    print(DISCLAIMER)
    print("=" * 70)


if __name__ == "__main__":
    main()
