"""Train the operational-window forecaster (Phase 1 evolution).

Trains a RandomForestClassifier on data/processed/window_forecast_dataset.csv
(attack_within_next_window, a 30-minute forecast window instead of the
original 1-minute one). This does NOT replace or retrain
ai/train_baseline_forecaster.py's model -- both are kept, side by side, as
two honestly-reported experiments on the same single-episode dataset.

SPLIT SELECTION -- chosen from label structure alone, never from a peek at
model performance:

This dataset has exactly one contiguous positive block (03:32-04:15,
44 rows) followed by exactly one contiguous negative block (04:16-04:32,
17 rows) -- a direct consequence of the source dataset containing exactly
one attack episode. With only one class transition, any chronological
split can give at most ONE side both classes; the other side is
necessarily single-class. This script tries standard train fractions in
increasing order (0.70, 0.75, 0.80, 0.85, 0.90) and uses the smallest one
whose TRAINING portion contains both classes -- so the model is at least
fit on a non-degenerate problem, rather than mechanically forced to
always predict one class as the 1-minute baseline was. It reports
whichever fraction that turns out to be, and reports plainly if none of
them work.

HONESTY NOTE, stated once here and repeated in every printed/saved
report: with only one attack episode, no split of this dataset can
produce a scientifically validated 30-minute forecaster. The training
set has only 1-2 examples of whichever class is scarce, and the test
set (whatever's left, chronologically after training) is not a
genuinely independent attack episode -- it is the tail of the same one
episode this model trained on. Metrics below are reported exactly as
computed, however poor, never adjusted or re-split to look better.

Run:
    python ai/train_window_forecaster.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from ai.build_window_forecast_dataset import (
    PREDICTOR_COLUMN_ORDER,
    TARGET_COLUMN,
    WINDOW_ATTACK_MINUTES_COLUMN,
)
from ai.config import (
    FORECAST_WINDOW_MINUTES,
    WINDOW_FORECAST_DATASET_PATH,
    WINDOW_METRICS_PATH,
    WINDOW_MODEL_PATH,
)

CANDIDATE_TRAIN_FRACTIONS = [0.70, 0.75, 0.80, 0.85, 0.90]

DISCLAIMER = (
    "This is a proof-of-concept experiment on a single attack episode, reformulated "
    "as a 30-minute forecast window. It is NOT a scientifically validated 30-minute "
    "forecaster: with only one contiguous attack episode, the test portion below is "
    "the tail of the SAME episode used for training, not an independent occurrence. "
    "Report the metrics exactly as computed -- including if they are poor."
)


def load_dataset(path: Path = WINDOW_FORECAST_DATASET_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python ai/build_window_forecast_dataset.py` first."
        )
    df = pd.read_csv(path, low_memory=False)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df.sort_values("timestamp").reset_index(drop=True)


def choose_split(df: pd.DataFrame) -> tuple[int, float, list[dict]]:
    """Try standard train fractions in increasing order; use the smallest
    one whose training portion contains both classes. Returns
    (split_idx, fraction_used, all_candidates_tried) -- the candidates
    list is for transparent reporting of what was tried and rejected."""
    y = df[TARGET_COLUMN].to_numpy()
    n = len(df)
    candidates = []
    chosen_idx: Optional[int] = None
    chosen_frac: Optional[float] = None

    for frac in CANDIDATE_TRAIN_FRACTIONS:
        split_idx = int(round(frac * n))
        split_idx = max(1, min(n - 1, split_idx))
        train_classes = sorted(set(y[:split_idx].tolist()))
        test_classes = sorted(set(y[split_idx:].tolist()))
        candidates.append({
            "train_fraction": frac,
            "split_idx": split_idx,
            "train_classes": train_classes,
            "test_classes": test_classes,
            "train_both_classes": len(train_classes) == 2,
        })
        if chosen_idx is None and len(train_classes) == 2:
            chosen_idx = split_idx
            chosen_frac = frac

    if chosen_idx is None:
        # No candidate gives training both classes -- fall back to the
        # smallest fraction tried (matches the 1-minute baseline's
        # behavior: report the degenerate result honestly rather than
        # search further for a split that "looks better").
        chosen_idx = candidates[0]["split_idx"]
        chosen_frac = candidates[0]["train_fraction"]

    return chosen_idx, chosen_frac, candidates


def train_and_evaluate(df: pd.DataFrame, split_idx: int) -> dict:
    X = df[PREDICTOR_COLUMN_ORDER].to_numpy()
    y = df[TARGET_COLUMN].to_numpy()

    X_train, y_train = X[:split_idx], y[:split_idx]
    X_test, y_test = X[split_idx:], y[split_idx:]

    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight="balanced")
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    classes = list(model.classes_)
    proba = model.predict_proba(X_test)
    y_proba = proba[:, classes.index(1)] if 1 in classes else np.zeros(len(X_test))

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

    roc_auc = None
    roc_auc_note = None
    if len(np.unique(y_test)) == 2:
        roc_auc = float(roc_auc_score(y_test, y_proba))
    else:
        roc_auc_note = "ROC-AUC not computed: test set does not contain both classes."

    n_pred_pos = int((y_pred == 1).sum())
    false_positive_rate = None
    if (y_test == 0).sum() > 0:
        false_positive_rate = float(((y_pred == 1) & (y_test == 0)).sum() / (y_test == 0).sum())

    importances = sorted(
        zip(PREDICTOR_COLUMN_ORDER, model.feature_importances_.tolist()),
        key=lambda kv: -kv[1],
    )

    return {
        "model": model,
        "train_size": len(y_train),
        "test_size": len(y_test),
        "train_positive": int(y_train.sum()),
        "test_positive": int(y_test.sum()),
        "train_single_class": len(set(y_train.tolist())) < 2,
        "test_single_class": len(set(y_test.tolist())) < 2,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "confusion_matrix": cm.tolist(),
        "roc_auc": roc_auc,
        "roc_auc_note": roc_auc_note,
        "false_positive_rate_on_test": false_positive_rate,
        "n_predicted_positive": n_pred_pos,
        "feature_importances_top10": importances[:10],
    }


def determine_model_status(results: dict) -> str:
    if results["train_single_class"]:
        return "DEGENERATE_SINGLE_CLASS_TRAINING"
    return "SINGLE_EPISODE_UNVALIDATED"


def main() -> None:
    df = load_dataset()
    print(f"Loaded {len(df)} rows from {WINDOW_FORECAST_DATASET_PATH}")
    print(f"target: {TARGET_COLUMN!r}  window: {FORECAST_WINDOW_MINUTES} minutes")

    split_idx, frac_used, candidates = choose_split(df)
    print("\n--- Split fraction candidates tried (label structure only, no model peeking) ---")
    for c in candidates:
        marker = " <== used" if c["split_idx"] == split_idx and c["train_fraction"] == frac_used else ""
        print(f"  train_fraction={c['train_fraction']:.2f}  train_classes={c['train_classes']}  "
              f"test_classes={c['test_classes']}{marker}")

    train_df = df.iloc[:split_idx]
    test_df = df.iloc[split_idx:]
    print(f"\nUsing train_fraction={frac_used:.2f} (split at {df['timestamp'].iloc[split_idx-1]} | "
          f"{df['timestamp'].iloc[split_idx]})")
    print(f"train: {len(train_df)} rows, {int(train_df[TARGET_COLUMN].sum())} positive")
    print(f"test:  {len(test_df)} rows, {int(test_df[TARGET_COLUMN].sum())} positive")

    results = train_and_evaluate(df, split_idx)
    model_status = determine_model_status(results)

    print(f"\nmodel_status: {model_status}")
    print("\n--- Test-set evaluation (reported exactly as computed) ---")
    print(f"accuracy:  {results['accuracy']:.4f}")
    print(f"precision: {results['precision']:.4f}")
    print(f"recall:    {results['recall']:.4f}")
    print(f"f1:        {results['f1']:.4f}")
    print(f"confusion matrix (rows=actual [0,1], cols=predicted [0,1]): {results['confusion_matrix']}")
    if results["roc_auc"] is not None:
        print(f"roc_auc: {results['roc_auc']:.4f}")
    else:
        print(f"roc_auc: not reported -- {results['roc_auc_note']}")
    if results["false_positive_rate_on_test"] is not None:
        print(f"false_positive_rate_on_test: {results['false_positive_rate_on_test']:.4f}")
    print(f"model predicted positive on {results['n_predicted_positive']}/{results['test_size']} test rows")

    print("\ntop feature importances (real, computed from the fitted model -- NOT a validated causal explanation):")
    for name, importance in results["feature_importances_top10"][:5]:
        print(f"  {name}: {importance:.4f}")

    WINDOW_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(results["model"], WINDOW_MODEL_PATH)

    metrics = {
        "formulation": {
            "forecast_window_minutes": FORECAST_WINDOW_MINUTES,
            "target": TARGET_COLUMN,
            "n_predictors": len(PREDICTOR_COLUMN_ORDER),
        },
        "split": {
            "total_rows": len(df),
            "train_fraction_used": frac_used,
            "candidates_tried": candidates,
            "train_rows": results["train_size"],
            "test_rows": results["test_size"],
            "train_positive": results["train_positive"],
            "test_positive": results["test_positive"],
            "train_single_class": results["train_single_class"],
            "test_single_class": results["test_single_class"],
            "train_end_timestamp": str(train_df["timestamp"].iloc[-1]),
            "test_start_timestamp": str(test_df["timestamp"].iloc[0]),
        },
        "model_status": model_status,
        "metrics": {
            "accuracy": results["accuracy"],
            "precision": results["precision"],
            "recall": results["recall"],
            "f1": results["f1"],
            "confusion_matrix": results["confusion_matrix"],
            "roc_auc": results["roc_auc"],
            "roc_auc_note": results["roc_auc_note"],
            "false_positive_rate_on_test": results["false_positive_rate_on_test"],
        },
        "feature_importances_top10": results["feature_importances_top10"],
        "predictor_columns": PREDICTOR_COLUMN_ORDER,
        "disclaimer": DISCLAIMER,
    }
    with open(WINDOW_METRICS_PATH, "w") as fh:
        json.dump(metrics, fh, indent=2, default=str)

    print(f"\nSaved model to:   {WINDOW_MODEL_PATH}")
    print(f"Saved metrics to: {WINDOW_METRICS_PATH}")
    print("\n" + "=" * 70)
    print(DISCLAIMER)
    print("=" * 70)


if __name__ == "__main__":
    main()
