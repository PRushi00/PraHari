"""Tests for backend/pattern_store.py."""
import pandas as pd

from backend.pattern_store import (
    KNOWN_PATTERNS,
    PatternStore,
    build_historical_incidents,
)


def test_no_features_reports_not_available():
    store = PatternStore()
    result = store.match(minute_features=None)
    assert result.status == "NOT_AVAILABLE"


def test_ddos_volumetric_pattern_matches_real_attack_signature():
    store = PatternStore()
    result = store.match(minute_features={
        "total_flows": 9164, "unique_destination_ports": 5, "unique_source_ips": 56,
        "destination_port": 80, "top_source_ip_flow_share": 0.71,
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 8.97}])
    assert result.status == "MATCHED"
    assert result.matched_pattern_id == "ddos_volumetric"
    assert result.matched_attack_type == "DDoS"
    assert result.similarity_score == 1.0
    assert result.mitre_tactic == "Impact (TA0040)"
    assert result.mitre_technique == "Network Denial of Service (T1498)"


def test_every_known_pattern_has_a_real_mitre_attck_label():
    for pattern in KNOWN_PATTERNS:
        assert pattern.mitre_tactic, f"{pattern.pattern_id} missing a MITRE tactic label"
        assert pattern.mitre_technique, f"{pattern.pattern_id} missing a MITRE technique label"


def test_no_match_result_does_not_fabricate_a_mitre_label():
    store = PatternStore()
    result = store.match(minute_features={
        "total_flows": 100, "unique_destination_ports": 4, "unique_source_ips": 10,
        "destination_port": 443, "top_source_ip_flow_share": 0.15,
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 0.1}])
    assert result.mitre_tactic is None
    assert result.mitre_technique is None


def test_quiet_traffic_does_not_match_any_pattern():
    store = PatternStore()
    result = store.match(minute_features={
        "total_flows": 100, "unique_destination_ports": 4, "unique_source_ips": 10,
        "destination_port": 443, "top_source_ip_flow_share": 0.15,
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 0.1}])
    assert result.status == "NO_MATCH"


def test_port_scan_pattern_matches_single_source_many_ports_no_volume_spike():
    store = PatternStore()
    result = store.match(minute_features={
        "total_flows": 120, "unique_destination_ports": 200, "unique_source_ips": 3,
        "destination_port": 22, "top_source_ip_flow_share": 0.9,
        "unique_destination_ports_status": "FAR_ABOVE_NORMAL",
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 0.4}])
    assert result.status == "MATCHED"
    assert result.matched_pattern_id == "port_scan"


def test_matched_pattern_carries_no_fabricated_organizational_claim():
    store = PatternStore()
    result = store.match(minute_features={
        "total_flows": 9164, "unique_destination_ports": 5, "unique_source_ips": 56,
        "destination_port": 80, "top_source_ip_flow_share": 0.71,
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 8.97}])
    assert "not real organizational incident data" in result.note


def test_every_known_pattern_has_at_least_one_condition():
    for pattern in KNOWN_PATTERNS:
        assert len(pattern.conditions) > 0


def _synthetic_history(attack_minutes_index=(2, 3, 4)):
    rows = []
    for i in range(6):
        rows.append({
            "timestamp": pd.Timestamp("2017-07-07 03:50:00") + pd.Timedelta(minutes=i),
            "total_flows": 9000 if i in attack_minutes_index else 100,
            "attack_flows": 500 if i in attack_minutes_index else 0,
            "top_source_ip": "172.16.0.1" if i in attack_minutes_index else "10.0.0.1",
        })
    return pd.DataFrame(rows)


def test_build_historical_incidents_groups_contiguous_attack_minutes():
    df = _synthetic_history()
    incidents = build_historical_incidents(df)
    assert len(incidents) == 1
    inc = incidents[0]
    assert inc.duration_minutes == 3
    assert inc.attack_type == "DDoS"
    assert inc.dominant_source_ip == "172.16.0.1"
    assert inc.peak_total_flows == 9000


def test_build_historical_incidents_handles_no_attack_data():
    df = _synthetic_history(attack_minutes_index=())
    assert build_historical_incidents(df) == []


def test_build_historical_incidents_handles_missing_dataframe():
    assert build_historical_incidents(None) == []


def test_pattern_store_surfaces_matching_historical_incident():
    store = PatternStore()
    store.load_history(_synthetic_history())
    result = store.match(minute_features={
        "total_flows": 9164, "unique_destination_ports": 5, "unique_source_ips": 56,
        "destination_port": 80, "top_source_ip_flow_share": 0.71,
    }, evidence=[{"signal": "traffic_volume_zscore", "value": 8.97}])
    assert result.status == "MATCHED"
    assert len(result.matched_historical_incidents) == 1
