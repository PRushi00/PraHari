"""Exploratory temporal analysis of the cleaned CICIDS2017 dataset.

Run after ai/preprocess.py has produced data/processed/cleaned.csv:

    python ai/analyze_temporal.py

This does NOT choose a final observation window / forecast horizon. It
reports the facts needed to choose them defensibly: timestamp resolution,
capture duration, attack segment structure, and event density at a few
candidate window sizes.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ai.config import CANDIDATE_WINDOW_SECONDS, CLEANED_DATA_PATH, PLOTS_DIR
from ai.preprocess import detect_label_column, detect_timestamp_column
from streaming.windows import assign_windows


def load_cleaned_dataset() -> pd.DataFrame:
    if not CLEANED_DATA_PATH.exists():
        raise FileNotFoundError(
            f"{CLEANED_DATA_PATH} not found. Run `python ai/preprocess.py` first."
        )
    df = pd.read_csv(CLEANED_DATA_PATH, low_memory=False)
    return df


def report_timestamp_resolution(ts: pd.Series) -> None:
    ts = ts.sort_values().drop_duplicates()
    if len(ts) < 2:
        print("Not enough distinct timestamps to determine resolution.")
        return
    diffs = ts.diff().dropna().dt.total_seconds()
    print("\n--- Timestamp resolution ---")
    print(f"distinct timestamps: {len(ts)}")
    print(f"min gap: {diffs.min():.3f}s  median gap: {diffs.median():.3f}s  max gap: {diffs.max():.3f}s")


def report_capture_duration(ts: pd.Series) -> None:
    print("\n--- Capture duration ---")
    print(f"start: {ts.min()}  end: {ts.max()}  span: {ts.max() - ts.min()}")


def find_contiguous_segments(is_attack: pd.Series, timestamps: pd.Series) -> pd.DataFrame:
    """Find contiguous runs of attack==1 in row order (already time-sorted)."""
    is_attack = is_attack.reset_index(drop=True)
    timestamps = timestamps.reset_index(drop=True)
    change_points = is_attack.ne(is_attack.shift()).cumsum()
    segments = []
    for _, group_idx in is_attack.groupby(change_points).groups.items():
        idx = list(group_idx)
        if is_attack.iloc[idx[0]] != 1:
            continue
        start_ts = timestamps.iloc[idx[0]]
        end_ts = timestamps.iloc[idx[-1]]
        segments.append({
            "start": start_ts,
            "end": end_ts,
            "duration_seconds": (end_ts - start_ts).total_seconds(),
            "record_count": len(idx),
        })
    return pd.DataFrame(segments)


def report_attack_segments(df: pd.DataFrame, timestamp_col: str) -> None:
    if "is_attack" not in df.columns:
        print("\nNo is_attack column available; skipping attack segment analysis.")
        return

    df_sorted = df.sort_values(timestamp_col)
    segments = find_contiguous_segments(df_sorted["is_attack"], df_sorted[timestamp_col])

    print("\n--- Attack segments ---")
    print(f"contiguous attack segments: {len(segments)}")
    if not segments.empty:
        print(f"segment duration (s): min={segments.duration_seconds.min():.2f} "
              f"median={segments.duration_seconds.median():.2f} max={segments.duration_seconds.max():.2f}")

        transitions = (df_sorted["is_attack"].diff() == 1).sum()
        print(f"benign -> attack transitions: {int(transitions)}")
    else:
        print("no attack segments found (dataset may be all-benign or label detection failed)")


def report_attack_types(df: pd.DataFrame, label_col: str, timestamp_col: str) -> None:
    print("\n--- Attack types ---")
    counts = df[label_col].value_counts()
    print(counts.to_string())

    if timestamp_col in df.columns:
        df = df.copy()
        df["_minute_bucket"] = pd.to_datetime(df[timestamp_col]).dt.floor("min")
        pivot = df.groupby(["_minute_bucket", label_col]).size().unstack(fill_value=0)
        print(f"\nattack types span {pivot.shape[0]} one-minute buckets (see plots for distribution)")


def report_event_density(df: pd.DataFrame, timestamp_col: str) -> None:
    print("\n--- Event density at candidate window sizes ---")
    for window_seconds in CANDIDATE_WINDOW_SECONDS:
        windowed = assign_windows(df, timestamp_col, window_seconds, window_id_col="_tmp_window")
        counts = windowed.groupby("_tmp_window").size()
        print(
            f"window={window_seconds:>3}s  windows={len(counts):>6}  "
            f"events/window: mean={counts.mean():.1f} median={counts.median():.1f} max={counts.max()}"
        )


def generate_plots(df: pd.DataFrame, timestamp_col: str, label_col: str | None) -> None:
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    df = df.copy()
    df[timestamp_col] = pd.to_datetime(df[timestamp_col])
    df = df.sort_values(timestamp_col)

    # 1. Traffic/record distribution over time (per-minute record counts).
    fig, ax = plt.subplots(figsize=(10, 4))
    per_minute = df.set_index(timestamp_col).resample("1min").size()
    per_minute.plot(ax=ax)
    ax.set_title("Traffic record count over time (1-minute buckets)")
    ax.set_xlabel("time")
    ax.set_ylabel("record count")
    fig.tight_layout()
    fig.savefig(PLOTS_DIR / "traffic_over_time.png")
    plt.close(fig)

    if label_col and "is_attack" in df.columns:
        # 2. Attack labels over time.
        fig, ax = plt.subplots(figsize=(10, 4))
        per_minute_attacks = (
            df.set_index(timestamp_col)["is_attack"].resample("1min").sum()
        )
        per_minute_attacks.plot(ax=ax, color="crimson")
        ax.set_title("Attack record count over time (1-minute buckets)")
        ax.set_xlabel("time")
        ax.set_ylabel("attack record count")
        fig.tight_layout()
        fig.savefig(PLOTS_DIR / "attacks_over_time.png")
        plt.close(fig)

        # 3. Attack counts by type.
        fig, ax = plt.subplots(figsize=(10, 5))
        counts = df[label_col].value_counts()
        counts.plot(kind="bar", ax=ax)
        ax.set_title("Record count by label")
        ax.set_ylabel("count")
        fig.tight_layout()
        fig.savefig(PLOTS_DIR / "attack_counts_by_type.png")
        plt.close(fig)

    print(f"\nPlots saved to {PLOTS_DIR}")


def main() -> None:
    df = load_cleaned_dataset()
    print(f"Loaded cleaned dataset: {len(df)} rows, {df.shape[1]} columns")

    timestamp_col = detect_timestamp_column(df)
    label_col = detect_label_column(df)
    if not timestamp_col:
        print("ERROR: no timestamp column detected in cleaned dataset; cannot run temporal analysis.")
        sys.exit(1)

    df[timestamp_col] = pd.to_datetime(df[timestamp_col])
    df = df.sort_values(timestamp_col).reset_index(drop=True)

    report_timestamp_resolution(df[timestamp_col])
    report_capture_duration(df[timestamp_col])
    report_attack_segments(df, timestamp_col)
    if label_col:
        report_attack_types(df, label_col, timestamp_col)
    report_event_density(df, timestamp_col)
    generate_plots(df, timestamp_col, label_col)


if __name__ == "__main__":
    main()
