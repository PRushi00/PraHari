"""Build the operational-window forecasting dataset (Phase 1 evolution).

The original research baseline asks "will the very next minute contain an
attack?" (attack_next_minute, ai/build_lagged_forecasting_dataset.py). That
formulation is preserved untouched. This module builds a second, parallel
dataset asking a more operationally realistic question:

    Given traffic through minute t, is a DDoS attack likely to occur
    SOMEWHERE within the next FORECAST_WINDOW_MINUTES minutes?

This matches how a real network administrator would want a forecast --
"elevated risk over the next ~30 minutes", not a claim of exact-minute
timing, which this dataset (60-second-resolution flow captures) cannot
support and this project has never claimed to support.

Predictors are UNCHANGED from the original formulation: the same 3-minute
lookback (lag2/lag1/lag0) of the same 11 raw traffic-volume features, plus
the same 2 calendar features, imported from
ai.build_lagged_forecasting_dataset (not redefined) so both formulations
share one leakage-safe feature construction. Only the TARGET differs.

Leakage rule, unchanged in spirit from the 1-minute formulation: a row's
target may only depend on minutes STRICTLY AFTER its own timestamp t, and
a row is only constructed when the full future window is actually present
in the dataset (no row is ever kept with a partially-known future).

Run:
    python ai/build_window_forecast_dataset.py
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from ai.build_forecasting_dataset import aggregate_per_minute, load_cleaned_dataset
from ai.build_lagged_forecasting_dataset import CALENDAR_FEATURES, LAG_OFFSETS, PRIMARY_FEATURES
from ai.config import FORECAST_WINDOW_MINUTES, WINDOW_FORECAST_DATASET_PATH
from ai.preprocess import detect_timestamp_column

TARGET_COLUMN = "attack_within_next_window"
WINDOW_ATTACK_MINUTES_COLUMN = "attack_minutes_within_window"

PREDICTOR_COLUMN_ORDER = [f"lag{o}_{f}" for o in LAG_OFFSETS for f in PRIMARY_FEATURES] + CALENDAR_FEATURES


def build_window_dataset(full_agg: pd.DataFrame, window_minutes: int = FORECAST_WINDOW_MINUTES) -> tuple[pd.DataFrame, dict]:
    """Build the lag-feature + window-target dataset from a full per-minute
    aggregation (as returned by ai.build_forecasting_dataset.aggregate_per_minute,
    BEFORE that module's own 1-minute shift/drop -- this function does its
    own, independent window construction).

    Returns (dataset, stats) where stats records how many candidate rows
    were dropped and why, for honest reporting.
    """
    indexed = full_agg.set_index("timestamp")
    one_min = pd.Timedelta(minutes=1)
    last_available_ts = full_agg["timestamp"].max()

    rows = []
    dropped_incomplete_history = 0
    dropped_incomplete_future = 0

    for t in full_agg["timestamp"]:
        required_lags = [t - offset * one_min for offset in LAG_OFFSETS]
        if not all(ts in indexed.index for ts in required_lags):
            dropped_incomplete_history += 1
            continue

        future_end = t + window_minutes * one_min
        if future_end > last_available_ts:
            dropped_incomplete_future += 1
            continue
        window_ts = [t + i * one_min for i in range(1, window_minutes + 1)]
        if not all(ts in indexed.index for ts in window_ts):
            dropped_incomplete_future += 1
            continue

        row: dict[str, float] = {"timestamp": t}
        for offset, ts in zip(LAG_OFFSETS, required_lags):
            source_row = indexed.loc[ts]
            for feature in PRIMARY_FEATURES:
                row[f"lag{offset}_{feature}"] = source_row[feature]
        for feature in CALENDAR_FEATURES:
            row[feature] = indexed.loc[t, feature]

        attack_minutes_in_window = sum(int(indexed.loc[ts, "attack_flows"] > 0) for ts in window_ts)
        row[WINDOW_ATTACK_MINUTES_COLUMN] = attack_minutes_in_window
        row[TARGET_COLUMN] = int(attack_minutes_in_window > 0)
        rows.append(row)

    dataset = pd.DataFrame(rows)
    column_order = ["timestamp"] + PREDICTOR_COLUMN_ORDER + [WINDOW_ATTACK_MINUTES_COLUMN, TARGET_COLUMN]
    dataset = dataset[column_order].sort_values("timestamp").reset_index(drop=True)

    stats = {
        "window_minutes": window_minutes,
        "total_minute_buckets": len(full_agg),
        "dropped_incomplete_history": dropped_incomplete_history,
        "dropped_incomplete_future": dropped_incomplete_future,
        "output_rows": len(dataset),
    }
    return dataset, stats


def run_sanity_checks(dataset: pd.DataFrame, full_agg: pd.DataFrame, window_minutes: int) -> None:
    assert dataset["timestamp"].is_monotonic_increasing, "timestamps are not sorted ascending"
    assert dataset["timestamp"].duplicated().sum() == 0, "duplicate timestamps found"
    assert len(dataset) == dataset["timestamp"].nunique(), "not exactly one row per timestamp"

    n_nan = int(dataset.isna().sum().sum())
    assert n_nan == 0, f"{n_nan} NaN values remain in the window dataset"

    # Independently re-derive the target for a sample of rows directly from
    # full_agg's own attack_flows column -- proves no leakage and no
    # off-by-one error in the window boundaries.
    indexed = full_agg.set_index("timestamp")["attack_flows"]
    one_min = pd.Timedelta(minutes=1)
    sample = dataset if len(dataset) <= 60 else dataset.sample(60, random_state=0)
    for _, row in sample.iterrows():
        t = row["timestamp"]
        window_ts = [t + i * one_min for i in range(1, window_minutes + 1)]
        expected_minutes = sum(int(indexed.loc[ts] > 0) for ts in window_ts)
        assert row[WINDOW_ATTACK_MINUTES_COLUMN] == expected_minutes, f"window attack-minute count mismatch at {t}"
        assert row[TARGET_COLUMN] == int(expected_minutes > 0), f"target mismatch at {t}"
        # Never allow information from t or earlier to have leaked into the count.
        assert t not in window_ts, "window must start strictly after t"


def print_report(dataset: pd.DataFrame, stats: dict) -> None:
    n_pos = int(dataset[TARGET_COLUMN].sum())
    n_neg = len(dataset) - n_pos
    pct_pos = 100 * n_pos / len(dataset) if len(dataset) else 0.0

    print(f"\nwindow size: {stats['window_minutes']} minutes")
    print(f"total minute buckets available: {stats['total_minute_buckets']}")
    print(f"dropped (incomplete 3-minute history): {stats['dropped_incomplete_history']}")
    print(f"dropped (incomplete future window): {stats['dropped_incomplete_future']}")
    print(f"output rows: {stats['output_rows']}")
    print(f"\ntarget column: {TARGET_COLUMN!r}")
    print(f"positive (attack somewhere in next {stats['window_minutes']} min): {n_pos} ({pct_pos:.1f}%)")
    print(f"negative: {n_neg}")
    print(f"earliest row: {dataset['timestamp'].min()}  latest row: {dataset['timestamp'].max()}")


def main() -> None:
    df = load_cleaned_dataset()
    timestamp_col = detect_timestamp_column(df) or "timestamp"
    print(f"Loaded {len(df)} flow-level rows; timestamp column: {timestamp_col!r}")

    full_agg = aggregate_per_minute(df, timestamp_col)
    dataset, stats = build_window_dataset(full_agg)

    run_sanity_checks(dataset, full_agg, stats["window_minutes"])
    print("All sanity checks passed.")
    print_report(dataset, stats)

    WINDOW_FORECAST_DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    dataset.to_csv(WINDOW_FORECAST_DATASET_PATH, index=False)
    print(f"\nSaved window forecast dataset to {WINDOW_FORECAST_DATASET_PATH} "
          f"({dataset.shape[0]} rows, {dataset.shape[1]} cols)")


if __name__ == "__main__":
    main()
