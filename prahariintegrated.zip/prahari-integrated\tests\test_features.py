"""Tests for streaming/features.py: feature aggregation over windows."""
import pandas as pd
import pytest

from streaming.features import extract_features_for_windows, extract_window_features


def test_extract_window_features_basic_counts():
    df = pd.DataFrame({
        "total_fwd_packets": [10, 20],
        "total_backward_packets": [5, 5],
        "total_length_of_fwd_packets": [100, 200],
        "total_length_of_bwd_packets": [50, 50],
        "flow_duration": [1_000_000, 1_000_000],  # microseconds -> 1s each
    })
    features = extract_window_features(df)
    assert features["flow_count"] == 2
    assert features["packet_count"] == 40  # 10+20+5+5
    assert features["byte_count"] == 400  # 100+200+50+50
    assert features["duration_mean"] == 1_000_000
    # total duration = 2 seconds -> rate = count / seconds
    assert features["packet_rate"] == 20  # 40 packets / 2s


def test_extract_window_features_ignores_missing_columns():
    df = pd.DataFrame({"total_fwd_packets": [1, 2, 3]})
    features = extract_window_features(df)
    assert features["flow_count"] == 3
    assert "byte_count" not in features
    assert "unique_src_count" not in features


def test_extract_window_features_ports_and_protocol():
    df = pd.DataFrame({
        "destination_port": [80, 443, 80],
        "protocol": ["tcp", "tcp", "udp"],
    })
    features = extract_window_features(df)
    assert features["unique_dst_port_count"] == 2
    assert features["protocol_tcp_ratio"] == pytest.approx(2 / 3)


def test_extract_features_for_windows_preserves_order_and_names():
    df = pd.DataFrame({
        "window_id": [2, 0, 1, 0, 2, 1],
        "total_fwd_packets": [1, 2, 3, 4, 5, 6],
    })
    feature_df = extract_features_for_windows(df)
    assert list(feature_df["window_id"]) == [0, 1, 2]
    # window 0 has rows with total_fwd_packets 2 and 4 -> packet_count 6
    row0 = feature_df[feature_df["window_id"] == 0].iloc[0]
    assert row0["flow_count"] == 2
    assert row0["packet_count"] == 6
