"""Forecasting service: the AI Forecasting Engine stage of the pipeline.

Wraps the trained models behind a small stateful API that a traffic
replay engine (or, later, a live capture pipeline) can feed one
aggregated minute at a time. Predictors are UNCHANGED from the original
research baseline -- PRIMARY_FEATURES, CALENDAR_FEATURES, LAG_OFFSETS are
imported from ai/build_lagged_forecasting_dataset.py, not redefined here
-- so a live feature vector is byte-for-byte the same shape both models
were trained on. Only the TARGET/HORIZON differs between the two.

Two modes are always both honestly available, never blended:

VALIDATED_MODEL_MODE
    Runs the real trained classifier for the operational forecast window
    (data/processed/window_random_forest.joblib /
    ai/train_window_forecaster.py): "is an attack likely somewhere in the
    next FORECAST_WINDOW_MINUTES minutes?" instead of an exact-minute
    claim. This is the current authoritative forecasting formulation
    (Phase 1 of the expanded architecture) -- the original 1-minute
    baseline (ai/train_baseline_forecaster.py) is preserved and still
    fully working, just no longer the one this live service defaults to.
    Whichever model is loaded, its status is read from its own saved
    metrics file and reported exactly: this dataset has only one
    continuous attack episode, so neither model has ever been evaluated
    against a genuinely independent attack occurrence. Model status is
    one of DEGENERATE_SINGLE_CLASS_TRAINING (zero positive training
    examples) or SINGLE_EPISODE_UNVALIDATED (both classes were seen in
    training, but the test portion is the tail of the same episode, not
    an independent one) -- never "VALIDATED".

DEMONSTRATION_MODE
    A transparent, explicitly-labeled RULE-BASED heuristic -- not a
    trained or learned model -- so a live dashboard has a responsive
    signal to show. It flags elevated risk when the current minute's
    traffic volume is a statistical outlier relative to a trailing
    baseline computed from the same replayed traffic. Never presented as
    a validated classifier or given a fabricated accuracy.

Both modes only ever consume SAFE_PREDICTOR / calendar features (never
attack_flows, attack_ratio, benign_flows, or any *_next_minute/window
column -- see ai/build_lagged_forecasting_dataset.py's EXCLUDED_COLUMNS,
reused here for the same guard). Suspicious-source/asset context (Phase
2) comes from real per-minute "top talker" volume tallies computed by
backend/replay.py -- a plain, deterministic, non-learned computation --
and is exposed as supporting context, never as model input.
"""
from __future__ import annotations

import json
import statistics
import sys
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import joblib
import numpy as np

from ai.build_lagged_forecasting_dataset import (
    CALENDAR_FEATURES,
    EXCLUDED_COLUMNS,
    LAG_OFFSETS,
    PRIMARY_FEATURES,
)
from ai.config import FORECAST_WINDOW_MINUTES, WINDOW_METRICS_PATH, WINDOW_MODEL_PATH

MODEL_PATH = WINDOW_MODEL_PATH
METRICS_PATH = WINDOW_METRICS_PATH

HISTORY_MINUTES = len(LAG_OFFSETS)  # 3 -- unchanged from the original formulation
FORECAST_HORIZON_MINUTES = FORECAST_WINDOW_MINUTES  # 30

DEMO_BASELINE_WINDOW = 15  # trailing minutes used for the heuristic's rolling baseline
DEMO_MIN_BASELINE_SAMPLES = 5
DEMO_Z_SCORE_ELEVATED_THRESHOLD = 1.0
DEMO_Z_SCORE_HIGH_RISK_THRESHOLD = 2.0
DEMO_Z_SCORE_CRITICAL_THRESHOLD = 3.0

ONLY_KNOWN_ATTACK_TYPE = "DDoS"  # the only attack label present anywhere in the training data

VALIDATED_MODEL_MODE = "VALIDATED_MODEL_MODE"
DEMONSTRATION_MODE = "DEMONSTRATION_MODE"

# model_status values that mean "this number is not a validated read", used
# by both risk-state and severity computation, wherever they're computed.
UNVALIDATED_MODEL_STATUSES = {"DEGENERATE_SINGLE_CLASS_TRAINING", "SINGLE_EPISODE_UNVALIDATED"}

RISK_NORMAL = "NORMAL"
RISK_ELEVATED = "ELEVATED"
RISK_HIGH_RISK = "HIGH_RISK"
RISK_CRITICAL = "CRITICAL"
RISK_UNVALIDATED = "UNVALIDATED"

# Predictor column order MUST match ai/build_window_forecast_dataset.py's
# (and the original ai/build_lagged_forecasting_dataset.py's) column order
# exactly, since a fitted RandomForestClassifier has no stored feature
# names -- it was fit on a plain numpy array.
PREDICTOR_COLUMN_ORDER = [f"lag{o}_{f}" for o in LAG_OFFSETS for f in PRIMARY_FEATURES] + CALENDAR_FEATURES


@dataclass
class ForecastResult:
    mode: str
    probability: Optional[float]
    attack_type: str
    model_status: str
    confidence: Optional[float]
    explanation: str
    risk_state: str = RISK_UNVALIDATED
    forecast_window: dict = field(default_factory=dict)
    evidence: list = field(default_factory=list)
    suspicious_source: Optional[dict] = None
    suspicious_sources: list = field(default_factory=list)
    forecast_horizon_minutes: int = FORECAST_HORIZON_MINUTES
    history_minutes_used: int = 0
    ready: bool = True
    extra: dict = field(default_factory=dict)


def _assert_no_leakage() -> None:
    """Defensive guard: the predictor column order built above must never
    contain an excluded ground-truth/target column."""
    for col in EXCLUDED_COLUMNS:
        assert col not in PREDICTOR_COLUMN_ORDER, f"excluded column {col!r} leaked into predictor column order"


_assert_no_leakage()


def build_feature_vector(history: list[dict]) -> np.ndarray:
    """Build the exact 35-feature row the model expects.

    history must be exactly HISTORY_MINUTES dicts, chronological
    oldest-first (history[0] is t-2, history[-1] is the current minute t),
    each containing at least the PRIMARY_FEATURES and CALENDAR_FEATURES
    keys (as produced by ai.build_forecasting_dataset.aggregate_per_minute).
    """
    if len(history) != HISTORY_MINUTES:
        raise ValueError(f"expected exactly {HISTORY_MINUTES} minutes of history, got {len(history)}")

    row: dict[str, float] = {}
    for offset, minute_row in zip(LAG_OFFSETS, history):
        for feature in PRIMARY_FEATURES:
            row[f"lag{offset}_{feature}"] = minute_row[feature]
    current = history[-1]
    for feature in CALENDAR_FEATURES:
        row[feature] = current[feature]

    return np.array([[row[c] for c in PREDICTOR_COLUMN_ORDER]], dtype=float)


def _forecast_window_descriptor() -> dict:
    return {
        "horizon_minutes": FORECAST_WINDOW_MINUTES,
        "window_start_offset_minutes": 1,
        "window_end_offset_minutes": FORECAST_WINDOW_MINUTES,
        "label": f"next {FORECAST_WINDOW_MINUTES} minutes",
    }


def _extract_suspicious_source(minute_row: dict) -> Optional[dict]:
    """Pull the real, deterministically-computed top-talker fields
    (backend/replay.py) out of a minute row, if present. Never fabricated
    -- returns None (with a reason) if the dataset didn't carry them."""
    if not minute_row or minute_row.get("top_source_ip") is None:
        return None
    return {
        "source_ip": minute_row.get("top_source_ip"),
        "flow_count": minute_row.get("top_source_ip_flow_count"),
        "flow_share": minute_row.get("top_source_ip_flow_share"),
        "destination_ip": minute_row.get("top_destination_ip"),
        "destination_port": minute_row.get("top_destination_port"),
        "basis": "highest flow count observed in the current minute (volume tally, not model-attributed)",
    }


def _extract_suspicious_sources(minute_row: dict) -> list:
    """The top-N suspicious source IPs this minute (backend/replay.py),
    not only the single strongest one -- so multiple suspicious entities
    can be represented even though the dashboard highlights the top one."""
    if not minute_row:
        return []
    return list(minute_row.get("top_sources") or [])


class ForecastingService:
    """Stateful wrapper around the trained window forecaster plus a
    transparent demonstration heuristic. Feed it one aggregated minute at
    a time via observe_minute(); call forecast() to get the current
    prediction in either mode."""

    def __init__(self, model_path: Path = MODEL_PATH, metrics_path: Path = METRICS_PATH):
        self.model_path = model_path
        self.metrics_path = metrics_path
        self.model = None
        self.metrics: dict = {}
        self.model_load_error: Optional[str] = None

        if model_path.exists():
            try:
                self.model = joblib.load(model_path)
            except Exception as exc:  # pragma: no cover - defensive
                self.model_load_error = f"failed to load model: {exc}"
        else:
            self.model_load_error = f"model file not found at {model_path}"

        if metrics_path.exists():
            with open(metrics_path) as fh:
                self.metrics = json.load(fh)

        self._history: deque[dict] = deque(maxlen=HISTORY_MINUTES)
        self._baseline_window: deque[float] = deque(maxlen=DEMO_BASELINE_WINDOW)
        self.minutes_observed = 0

    @property
    def saved_model_status(self) -> Optional[str]:
        """The honest status recorded at training time, read as-is."""
        if "model_status" in self.metrics:  # new window-forecaster format
            return self.metrics["model_status"]
        if self.metrics.get("split", {}).get("train_single_class"):  # old baseline format
            return "DEGENERATE_SINGLE_CLASS_TRAINING"
        return None

    @property
    def train_single_class(self) -> Optional[bool]:
        """Kept for backward compatibility with callers/tests written
        against the original 1-minute baseline's metrics shape."""
        return self.metrics.get("split", {}).get("train_single_class")

    def reset(self) -> None:
        self._history.clear()
        self._baseline_window.clear()
        self.minutes_observed = 0

    def observe_minute(self, minute_row: dict) -> None:
        """Feed one new aggregated minute (dict with at least
        PRIMARY_FEATURES + CALENDAR_FEATURES keys, and optionally the
        top-talker fields from backend/replay.py) into the rolling
        history used for both forecasting modes."""
        self._history.append(minute_row)
        self.minutes_observed += 1
        if "total_flows" in minute_row:
            self._baseline_window.append(float(minute_row["total_flows"]))

    def _not_ready_result(self, mode: str) -> ForecastResult:
        return ForecastResult(
            mode=mode,
            probability=None,
            attack_type="none",
            model_status="INSUFFICIENT_HISTORY",
            confidence=None,
            explanation=(
                f"Need {HISTORY_MINUTES} consecutive observed minutes before a forecast can be "
                f"made (have {len(self._history)}). No prediction is fabricated in the meantime."
            ),
            risk_state=RISK_UNVALIDATED,
            forecast_window=_forecast_window_descriptor(),
            history_minutes_used=len(self._history),
            ready=False,
        )

    def forecast_validated(self) -> ForecastResult:
        """VALIDATED_MODEL_MODE: run the real trained window forecaster."""
        if len(self._history) < HISTORY_MINUTES:
            return self._not_ready_result(VALIDATED_MODEL_MODE)

        if self.model is None:
            return ForecastResult(
                mode=VALIDATED_MODEL_MODE,
                probability=None,
                attack_type="none",
                model_status="MODEL_UNAVAILABLE",
                confidence=None,
                explanation=self.model_load_error or "model not loaded",
                risk_state=RISK_UNVALIDATED,
                forecast_window=_forecast_window_descriptor(),
                history_minutes_used=len(self._history),
                ready=False,
            )

        X = build_feature_vector(list(self._history))
        classes = list(self.model.classes_)
        proba_row = self.model.predict_proba(X)[0]
        probability = float(proba_row[classes.index(1)]) if 1 in classes else 0.0

        model_status = self.saved_model_status or "UNKNOWN"
        split = self.metrics.get("split", {})
        metrics_block = self.metrics.get("metrics", {})

        if model_status == "DEGENERATE_SINGLE_CLASS_TRAINING":
            explanation = (
                "Trained on a chronological split whose training portion contains zero "
                "positive examples (only one attack episode exists in the source dataset), "
                "so this model deterministically predicts probability=0.0 for any input. "
                "This is the model's genuine, documented behavior -- not a placeholder or a bug."
            )
        elif model_status == "SINGLE_EPISODE_UNVALIDATED":
            test_acc = metrics_block.get("accuracy")
            fpr = metrics_block.get("false_positive_rate_on_test")
            explanation = (
                f"Trained on {split.get('train_rows', '?')} rows ({split.get('train_positive', '?')} positive, "
                f"real examples of both classes). The only available test rows "
                f"({split.get('test_rows', '?')}) are the tail of the SAME single attack episode used "
                f"for training, not an independent occurrence, so this is not a validated generalization "
                f"test. Reported exactly as measured: test accuracy={test_acc}, "
                f"false positive rate on test={fpr}."
            )
        else:
            explanation = "Prediction from the trained RandomForestClassifier for the operational forecast window."

        is_unvalidated = model_status in UNVALIDATED_MODEL_STATUSES
        attack_type = ONLY_KNOWN_ATTACK_TYPE if probability >= 0.5 else "none"
        confidence = None if is_unvalidated else float(max(proba_row))
        risk_state = RISK_UNVALIDATED if is_unvalidated else _bucket_probability(probability)

        evidence = []
        for name, importance in self.metrics.get("feature_importances_top10", [])[:3]:
            evidence.append({
                "signal": f"feature_importance:{name}",
                "description": f"'{name}' was among the most influential inputs to the trained model "
                                f"(importance={importance:.3f}) -- a real computed value, not a validated causal claim.",
                "value": importance,
            })
        suspicious_source = _extract_suspicious_source(self._history[-1])
        suspicious_sources = _extract_suspicious_sources(self._history[-1])

        return ForecastResult(
            mode=VALIDATED_MODEL_MODE,
            probability=probability,
            attack_type=attack_type,
            model_status=model_status,
            confidence=confidence,
            explanation=explanation,
            risk_state=risk_state,
            forecast_window=_forecast_window_descriptor(),
            evidence=evidence,
            suspicious_source=suspicious_source,
            suspicious_sources=suspicious_sources,
            history_minutes_used=len(self._history),
            ready=True,
            extra={"disclaimer": self.metrics.get("disclaimer")},
        )

    def forecast_demo(self) -> ForecastResult:
        """DEMONSTRATION_MODE: transparent rule-based heuristic, not a
        trained model. Flags elevated risk when the current minute's
        total_flows is a statistical outlier vs. a trailing baseline
        computed from the same replayed traffic."""
        if len(self._history) < HISTORY_MINUTES:
            return self._not_ready_result(DEMONSTRATION_MODE)

        current_row = self._history[-1]
        current_flows = float(current_row["total_flows"])
        baseline = list(self._baseline_window)[:-1]  # exclude the current minute itself

        if len(baseline) < DEMO_MIN_BASELINE_SAMPLES:
            return ForecastResult(
                mode=DEMONSTRATION_MODE,
                probability=None,
                attack_type="none",
                model_status="INSUFFICIENT_BASELINE",
                confidence=None,
                explanation=(
                    f"Heuristic needs at least {DEMO_MIN_BASELINE_SAMPLES} prior minutes of "
                    f"traffic to establish a trailing baseline (have {len(baseline)})."
                ),
                risk_state=RISK_UNVALIDATED,
                forecast_window=_forecast_window_descriptor(),
                history_minutes_used=len(self._history),
                ready=False,
            )

        mean = statistics.fmean(baseline)
        stdev = statistics.pstdev(baseline) or 1e-9
        z_score = (current_flows - mean) / stdev
        risk_score = max(0.0, min(1.0, z_score / (2 * DEMO_Z_SCORE_HIGH_RISK_THRESHOLD)))

        if z_score >= DEMO_Z_SCORE_CRITICAL_THRESHOLD:
            risk_state = RISK_CRITICAL
        elif z_score >= DEMO_Z_SCORE_HIGH_RISK_THRESHOLD:
            risk_state = RISK_HIGH_RISK
        elif z_score >= DEMO_Z_SCORE_ELEVATED_THRESHOLD:
            risk_state = RISK_ELEVATED
        else:
            risk_state = RISK_NORMAL
        is_elevated = risk_state in (RISK_ELEVATED, RISK_HIGH_RISK, RISK_CRITICAL)

        evidence = [{
            "signal": "traffic_volume_zscore",
            "description": f"current minute's total_flows={current_flows:.0f} is {z_score:.2f} standard "
                            f"deviations from the trailing {len(baseline)}-minute baseline (mean={mean:.0f}).",
            "value": round(z_score, 4),
        }]
        suspicious_source = _extract_suspicious_source(current_row)
        suspicious_sources = _extract_suspicious_sources(current_row)
        if suspicious_source and suspicious_source.get("flow_share") is not None:
            evidence.append({
                "signal": "top_source_ip_share",
                "description": f"source IP {suspicious_source['source_ip']} accounted for "
                                f"{suspicious_source['flow_share']:.0%} of this minute's flows.",
                "value": suspicious_source["flow_share"],
            })

        return ForecastResult(
            mode=DEMONSTRATION_MODE,
            probability=round(risk_score, 4),
            attack_type=(f"{ONLY_KNOWN_ATTACK_TYPE} (heuristic guess -- only attack type "
                          "present in training data)" if is_elevated else "none"),
            model_status="HEURISTIC_NOT_A_TRAINED_MODEL",
            confidence=round(min(1.0, abs(z_score) / (4 * DEMO_Z_SCORE_HIGH_RISK_THRESHOLD)), 4),
            explanation=(
                f"Rule-based anomaly heuristic (NOT a trained/validated classifier): current "
                f"minute's total_flows={current_flows:.0f} is {z_score:.2f} standard deviations "
                f"from the trailing {len(baseline)}-minute baseline (mean={mean:.0f}). "
                f"Alert thresholds: elevated >= {DEMO_Z_SCORE_ELEVATED_THRESHOLD}, "
                f"high-risk >= {DEMO_Z_SCORE_HIGH_RISK_THRESHOLD} std dev."
            ),
            risk_state=risk_state,
            forecast_window=_forecast_window_descriptor(),
            evidence=evidence,
            suspicious_source=suspicious_source,
            suspicious_sources=suspicious_sources,
            history_minutes_used=len(self._history),
            ready=True,
            extra={"z_score": round(z_score, 4), "baseline_mean": mean, "baseline_stdev": stdev},
        )

    def forecast(self, mode: str = VALIDATED_MODEL_MODE) -> ForecastResult:
        if mode == VALIDATED_MODEL_MODE:
            return self.forecast_validated()
        if mode == DEMONSTRATION_MODE:
            return self.forecast_demo()
        raise ValueError(f"unknown mode {mode!r}; expected {VALIDATED_MODEL_MODE!r} or {DEMONSTRATION_MODE!r}")


def _bucket_probability(probability: float) -> str:
    """Only meaningful for a model whose status is NOT in
    UNVALIDATED_MODEL_STATUSES -- kept simple/symmetric with
    threat_service.py's severity thresholds."""
    if probability >= 0.9:
        return RISK_CRITICAL
    if probability >= 0.75:
        return RISK_HIGH_RISK
    if probability >= 0.25:
        return RISK_ELEVATED
    return RISK_NORMAL
