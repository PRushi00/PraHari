"""Threat-event generation: the "Threat Event" stage of the MVP pipeline.

Converts a single ForecastResult (backend/forecasting_service.py) into a
structured, deterministic security threat event -- the record that will
be hashed and stored on the blockchain ledger.

Per the expanded architecture, a threat event carries at minimum: event
ID, timestamp, forecast window, predicted attack type, risk/severity,
probability/confidence where legitimately available, suspicious
source/asset where available, evidence/reasons, recommended actions, and
model/mode status. This module never invents a probability, never
relabels DEMONSTRATION_MODE as trained AI output, and never hides an
unvalidated model's limitation: it maps that limitation to its own
explicit severity tier ("UNVALIDATED") rather than letting a literal
probability read as an ordinary, reliable score.

Event IDs are deterministic: hashing the same (timestamp, mode,
model_status, attack_type, probability, model_version) always produces
the same event_id, so replaying the same dataset twice reproduces
identical events -- useful for a reproducible demo, and it means
re-generating a threat event for a minute already seen is a no-op rather
than a duplicate.
"""
from __future__ import annotations

import hashlib
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from backend.forecasting_service import (
    DEMONSTRATION_MODE,
    VALIDATED_MODEL_MODE,
    ForecastResult,
)
from backend.pattern_store import DEFAULT_PATTERN_STORE
from storage.persistence import SqlitePersistence

# --- Severity thresholds (documented, not invented ad hoc) -----------------
# Applied to the forecast's own probability/risk score, highest first.
# A model_status that means "this model is structurally incapable of a
# validated read" (see UNVALIDATED_MODEL_STATUSES below) always overrides
# these thresholds with "UNVALIDATED", regardless of the numeric value --
# a bare 0.0 from a model that has never seen a positive example, or one
# whose test set is the tail of the same single episode it trained on, is
# not the same claim as a 0.0 from a genuinely validated model.
SEVERITY_THRESHOLDS: list[tuple[float, str]] = [
    (0.75, "CRITICAL"),
    (0.50, "HIGH"),
    (0.25, "MEDIUM"),
    (0.00, "LOW"),
]

# model_status values (from ForecastResult) that mean the numeric
# probability cannot be treated as a validated read, no matter its value.
UNVALIDATED_MODEL_STATUSES = {
    "DEGENERATE_SINGLE_CLASS_TRAINING",
    "SINGLE_EPISODE_UNVALIDATED",
}

RECOMMENDATIONS: dict[str, list[str]] = {
    "CRITICAL": [
        "Activate incident response and apply mitigation immediately.",
        "Isolate or rate-limit the suspicious source, if one was identified, for the forecast window.",
        "Notify the network security team now.",
    ],
    "HIGH": [
        "Investigate the suspicious source and traffic pattern immediately.",
        "Prepare mitigation (rate-limiting, firewall rule) ahead of the forecast window.",
        "Increase monitoring frequency for the affected asset.",
    ],
    "MEDIUM": [
        "Increase monitoring frequency and review recent traffic.",
        "Watch the suspicious source, if identified, for further escalation.",
    ],
    "LOW": [
        "Continue routine monitoring.",
        "No immediate action required.",
    ],
    "UNVALIDATED": [
        "Do not use this score for decisions -- the model cannot yet provide a validated attack "
        "forecast (single-episode training data, no independent held-out episode).",
        "Treat this event as informational only until a model trained/validated on multiple "
        "independent episodes is available.",
        "Rely on DEMONSTRATION_MODE's transparent heuristic, or manual review, for situational "
        "awareness in the meantime.",
    ],
}

MODEL_VERSIONS: dict[str, str] = {
    VALIDATED_MODEL_MODE: "window-random-forest-v1",
    DEMONSTRATION_MODE: "heuristic-volume-zscore-v1",
}

DEFAULT_SOURCE = "cicids2017-friday-ddos-replay"


@dataclass
class ThreatEvent:
    event_id: str
    timestamp: str
    source: str
    forecast_mode: str
    model_status: str
    predicted_attack_type: str
    attack_probability: Optional[float]
    confidence: Optional[float]
    forecast_window: dict
    severity: str
    risk_state: str
    recommended_actions: list
    model_version: str
    suspicious_source: Optional[dict] = None
    suspicious_sources: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    pattern_match: dict = field(default_factory=dict)
    baseline_comparison: dict = field(default_factory=dict)
    explanation: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def compute_severity(probability: float, model_status: str) -> str:
    """Map a probability to one of LOW/MEDIUM/HIGH/CRITICAL using the
    documented thresholds above -- unless model_status says the model
    cannot produce a validated read at all, in which case severity is
    always "UNVALIDATED" regardless of the numeric probability."""
    if model_status in UNVALIDATED_MODEL_STATUSES:
        return "UNVALIDATED"
    for threshold, severity in SEVERITY_THRESHOLDS:
        if probability >= threshold:
            return severity
    return "LOW"  # pragma: no cover - unreachable, thresholds bottom out at 0.0


def _make_event_id(
    timestamp: str, mode: str, model_status: str, attack_type: str,
    probability: float, model_version: str,
) -> str:
    """Deterministic event ID: identical inputs always hash to the same
    ID, so re-generating an event for a minute already processed is
    idempotent rather than a duplicate."""
    payload = f"{timestamp}|{mode}|{model_status}|{attack_type}|{probability:.6f}|{model_version}"
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
    return f"evt_{digest}"


def create_threat_event(
    forecast: ForecastResult,
    as_of: pd.Timestamp,
    source: str = DEFAULT_SOURCE,
    minute_features: Optional[dict] = None,
    baseline_comparison: Optional[dict] = None,
) -> Optional[ThreatEvent]:
    """Build a ThreatEvent from a forecast, or None if the forecast isn't
    ready yet (insufficient history / model unavailable) -- no event is
    fabricated when there is genuinely nothing meaningful to report.

    minute_features (raw per-minute traffic signals -- total_flows,
    unique_destination_ports, destination_port, etc., plus the
    baseline-derived *_status flags) and baseline_comparison (backend/
    baseline.py's current-vs-organizational-normal comparison) are
    optional: when the caller has real replay data to supply them from
    (backend/app.py does), pattern matching and the baseline record
    become genuinely informative; when omitted (e.g. unit tests
    constructing a bare ForecastResult), pattern_match honestly reports
    NOT_AVAILABLE instead of guessing."""
    if not forecast.ready or forecast.probability is None:
        return None

    model_version = MODEL_VERSIONS.get(forecast.mode, "unknown")
    severity = compute_severity(forecast.probability, forecast.model_status)
    timestamp_str = pd.Timestamp(as_of).isoformat()

    event_id = _make_event_id(
        timestamp_str, forecast.mode, forecast.model_status,
        forecast.attack_type, forecast.probability, model_version,
    )

    pattern_result = DEFAULT_PATTERN_STORE.match(
        minute_features=minute_features,
        suspicious_source=forecast.suspicious_source,
        evidence=forecast.evidence,
    )
    pattern_match = pattern_result.to_dict()

    actions = list(RECOMMENDATIONS[severity])
    if pattern_result.status == "MATCHED":
        actions.append(
            f"Pattern match: {pattern_result.matched_pattern_name} "
            f"(similarity {pattern_result.similarity_score:.0%}) -- review traffic against this "
            f"known signature specifically."
        )

    return ThreatEvent(
        event_id=event_id,
        timestamp=timestamp_str,
        source=source,
        forecast_mode=forecast.mode,
        model_status=forecast.model_status,
        predicted_attack_type=forecast.attack_type,
        attack_probability=forecast.probability,
        confidence=forecast.confidence,
        forecast_window=dict(forecast.forecast_window),
        severity=severity,
        risk_state=forecast.risk_state,
        recommended_actions=actions,
        model_version=model_version,
        suspicious_source=forecast.suspicious_source,
        suspicious_sources=list(forecast.suspicious_sources),
        evidence=list(forecast.evidence),
        pattern_match=pattern_match,
        baseline_comparison=dict(baseline_comparison) if baseline_comparison else {},
        explanation=forecast.explanation,
    )


class ThreatEventStore:
    """In-process store for recent threat events -- the simplest reliable
    option for a local one-day MVP (matches the existing in-process
    AppState pattern in backend/app.py).

    Persistence across restarts is OPTIONAL, via storage/persistence.py:
    without a `persistence` argument this behaves exactly as it always
    has (nothing written to disk, state lost on restart -- every existing
    test keeps passing unmodified); pass a SqlitePersistence to also
    durably write every event and reload them at startup, so a restart no
    longer loses the events this run of the demo generated.

    Insertion is idempotent by event_id: since IDs are deterministic,
    re-generating an event for a minute already recorded updates nothing
    and is not treated as a new/duplicate event.
    """

    def __init__(self, max_events: int = 1000, persistence: Optional[SqlitePersistence] = None):
        self.max_events = max_events
        self.persistence = persistence
        self._events: list[ThreatEvent] = []
        self._ids: set[str] = set()
        self._next_seq = 0

        if persistence is not None:
            for data in persistence.load_threat_events():
                event = ThreatEvent(**data)
                self._events.append(event)
                self._ids.add(event.event_id)
                self._next_seq += 1
            self._evict_overflow()

    def _evict_overflow(self) -> None:
        while len(self._events) > self.max_events:
            oldest = self._events.pop(0)
            self._ids.discard(oldest.event_id)

    def add(self, event: ThreatEvent) -> bool:
        """Return True if a new event was stored, False if it was a
        duplicate (same deterministic event_id already recorded)."""
        if event.event_id in self._ids:
            return False
        self._events.append(event)
        self._ids.add(event.event_id)
        if self.persistence is not None:
            self.persistence.save_threat_event(event.event_id, self._next_seq, event.to_dict())
            self._next_seq += 1
        self._evict_overflow()
        return True

    def latest(self) -> Optional[ThreatEvent]:
        return self._events[-1] if self._events else None

    def list(self, limit: Optional[int] = None) -> list[ThreatEvent]:
        """Most-recent-first."""
        ordered = list(reversed(self._events))
        return ordered[:limit] if limit is not None else ordered

    def clear(self) -> None:
        self._events.clear()
        self._ids.clear()
        self._next_seq = 0
        if self.persistence is not None:
            self.persistence.clear_threat_events()

    def __len__(self) -> int:
        return len(self._events)
