"""Tests for ai/analyze_forecast_lead_time.py and its backend/app.py wiring."""
from pathlib import Path

import pandas as pd
import pytest

from ai.analyze_forecast_lead_time import (
    ALERT_MIN_RANK,
    PROBABILITY_ALERT_THRESHOLD,
    _attack_onset_timestamp,
    _first_minute_at_or_above,
    _first_probability_crossing,
    _lead_time_minutes,
    analyze,
    build_full_per_minute_dataset,
    replay_and_score,
)
from backend.forecasting_service import (
    DEMONSTRATION_MODE,
    RISK_CRITICAL,
    RISK_ELEVATED,
    RISK_NORMAL,
    VALIDATED_MODEL_MODE,
    ForecastingService,
)

NONEXISTENT = Path("/nonexistent/model.joblib")


def _synthetic_traffic_df(n=25, spike_start=20, spike_value=100_000, base_value=100):
    timestamps = pd.date_range("2017-07-07 03:00:00", periods=n, freq="1min")
    total_flows = [spike_value if i >= spike_start else base_value for i in range(n)]
    attack_flows = [500 if i >= spike_start else 0 for i in range(n)]
    return pd.DataFrame({
        "timestamp": timestamps,
        "total_flows": total_flows,
        "attack_flows": attack_flows,
        "unique_source_ips": [5] * n,
        "unique_destination_ports": [3] * n,
    })


def test_attack_onset_timestamp_finds_first_labeled_attack_minute():
    df = _synthetic_traffic_df()
    onset = _attack_onset_timestamp(df)
    assert onset == df.iloc[20]["timestamp"]


def test_attack_onset_timestamp_none_when_no_attack_labeled():
    df = _synthetic_traffic_df(spike_start=999)
    assert _attack_onset_timestamp(df) is None


def test_first_minute_at_or_above_returns_first_qualifying_record():
    records = [
        {"timestamp": pd.Timestamp("2017-01-01 00:00"), "risk_state": RISK_NORMAL},
        {"timestamp": pd.Timestamp("2017-01-01 00:01"), "risk_state": RISK_ELEVATED},
        {"timestamp": pd.Timestamp("2017-01-01 00:02"), "risk_state": RISK_CRITICAL},
    ]
    hit = _first_minute_at_or_above(records, ALERT_MIN_RANK)
    assert hit["timestamp"] == pd.Timestamp("2017-01-01 00:01")


def test_first_minute_at_or_above_none_when_nothing_qualifies():
    records = [{"timestamp": pd.Timestamp("2017-01-01 00:00"), "risk_state": RISK_NORMAL}]
    assert _first_minute_at_or_above(records, ALERT_MIN_RANK) is None


def test_first_probability_crossing_finds_first_row_at_or_above_threshold():
    records = [
        {"timestamp": pd.Timestamp("2017-01-01 00:00"), "probability": 0.1},
        {"timestamp": pd.Timestamp("2017-01-01 00:01"), "probability": 0.6},
    ]
    hit = _first_probability_crossing(records, threshold=PROBABILITY_ALERT_THRESHOLD)
    assert hit["timestamp"] == pd.Timestamp("2017-01-01 00:01")


def test_first_probability_crossing_ignores_none_probabilities():
    records = [{"timestamp": pd.Timestamp("2017-01-01 00:00"), "probability": None}]
    assert _first_probability_crossing(records) is None


def test_lead_time_minutes_computes_real_difference():
    onset = pd.Timestamp("2017-01-01 00:10:00")
    alert = pd.Timestamp("2017-01-01 00:05:00")
    assert _lead_time_minutes(onset, alert) == 5.0


def test_lead_time_minutes_reports_negative_when_alert_is_after_onset_not_clamped():
    onset = pd.Timestamp("2017-01-01 00:05:00")
    alert = pd.Timestamp("2017-01-01 00:10:00")
    assert _lead_time_minutes(onset, alert) == -5.0


def test_lead_time_minutes_none_when_either_side_missing():
    assert _lead_time_minutes(None, pd.Timestamp("2017-01-01")) is None
    assert _lead_time_minutes(pd.Timestamp("2017-01-01"), None) is None


def test_replay_and_score_demo_mode_flags_the_synthetic_spike():
    df = _synthetic_traffic_df(n=30, spike_start=25)
    service = ForecastingService(model_path=NONEXISTENT, metrics_path=NONEXISTENT)
    demo_records, validated_records = replay_and_score(df, service)

    assert len(demo_records) > 0
    assert any(r["risk_state"] in (RISK_ELEVATED, RISK_CRITICAL) for r in demo_records[-5:])
    # model_path doesn't exist -> VALIDATED_MODEL_MODE is never ready.
    assert validated_records == []


def test_replay_and_score_reports_no_alert_when_heuristic_stays_quiet():
    df = _synthetic_traffic_df(n=15, spike_start=999)  # flat traffic, no spike
    service = ForecastingService(model_path=NONEXISTENT, metrics_path=NONEXISTENT)
    demo_records, _ = replay_and_score(df, service)
    assert _first_minute_at_or_above(demo_records, ALERT_MIN_RANK) is None


def test_analyze_against_real_replayed_dataset_if_present():
    """Integration check against the real committed dataset/model, matching
    tests/test_forecasting_service.py's skip-if-artifacts-missing convention
    for real-data-dependent tests."""
    from ai.config import CLEANED_DATA_PATH, WINDOW_MODEL_PATH

    if not CLEANED_DATA_PATH.exists() or not WINDOW_MODEL_PATH.exists():
        pytest.skip("real dataset/model artifacts not present")

    result = analyze()
    assert result["attack_onset_timestamp"] is not None
    assert result["total_minutes_replayed"] > 0
    assert result["demonstration_mode"]["mode"] == DEMONSTRATION_MODE
    assert result["validated_model_mode"]["mode"] == VALIDATED_MODEL_MODE
    assert "lead_time_minutes" in result["demonstration_mode"]
    assert "lead_time_minutes" in result["validated_model_mode"]


def test_build_full_per_minute_dataset_matches_live_replay_engine_shape():
    df = build_full_per_minute_dataset()
    assert "timestamp" in df.columns
    assert "attack_flows" in df.columns
    assert df["timestamp"].is_monotonic_increasing


def test_lead_time_endpoint_reports_precomputed_kpi_or_honest_unavailable():
    from fastapi.testclient import TestClient

    from backend.app import app

    with TestClient(app) as client:
        res = client.get("/metrics/lead_time")
        assert res.status_code == 200
        body = res.json()
        assert "available" in body
        if body["available"]:
            assert "demonstration_mode" in body
            assert "validated_model_mode" in body
        else:
            assert "note" in body
