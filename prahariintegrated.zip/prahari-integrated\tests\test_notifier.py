"""Tests for backend/notifier.py."""
from backend.notifier import AdminNotifier, LogAlertChannel


def _event(severity, source_ip="172.16.0.1"):
    return {
        "event_id": "evt_test",
        "timestamp": "2017-07-07T03:56:00",
        "severity": severity,
        "risk_state": "CRITICAL" if severity == "CRITICAL" else "HIGH_RISK",
        "predicted_attack_type": "DDoS",
        "suspicious_source": {"source_ip": source_ip} if source_ip else None,
        "forecast_window": {"label": "next 30 minutes"},
    }


def test_critical_severity_generates_an_alert():
    notifier = AdminNotifier()
    alert = notifier.notify_if_warranted(_event("CRITICAL"))
    assert alert is not None
    assert alert.severity == "CRITICAL"
    assert alert.suspicious_source_ip == "172.16.0.1"
    assert alert.delivered is True
    assert alert.channel == "log"
    assert len(notifier) == 1


def test_high_severity_generates_an_alert():
    notifier = AdminNotifier()
    alert = notifier.notify_if_warranted(_event("HIGH"))
    assert alert is not None
    assert alert.severity == "HIGH"


def test_low_medium_unvalidated_do_not_generate_an_alert():
    notifier = AdminNotifier()
    for severity in ("LOW", "MEDIUM", "UNVALIDATED"):
        assert notifier.notify_if_warranted(_event(severity)) is None
    assert len(notifier) == 0


def test_alert_is_honest_about_no_real_delivery_channel():
    notifier = AdminNotifier()
    alert = notifier.notify_if_warranted(_event("CRITICAL"))
    assert "no email/sms/push" in alert.note.lower()


def test_list_is_most_recent_first():
    notifier = AdminNotifier()
    e1 = dict(_event("CRITICAL")); e1["event_id"] = "evt_1"
    e2 = dict(_event("CRITICAL")); e2["event_id"] = "evt_2"
    notifier.notify_if_warranted(e1)
    notifier.notify_if_warranted(e2)
    alerts = notifier.list()
    assert alerts[0].event_id == "evt_2"
    assert alerts[1].event_id == "evt_1"


def test_clear_empties_the_alert_log():
    notifier = AdminNotifier()
    notifier.notify_if_warranted(_event("CRITICAL"))
    notifier.clear()
    assert len(notifier) == 0


def test_log_alert_channel_always_reports_delivered():
    channel = LogAlertChannel()
    assert channel.send({"event_id": "evt_x"}) is True
