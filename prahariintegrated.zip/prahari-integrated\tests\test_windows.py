"""Tests for streaming/windows.py: window creation and supervised sample
construction."""
import numpy as np
import pandas as pd
import pytest

from streaming.windows import (
    aggregate_window_labels,
    assign_windows,
    build_supervised_windows,
    window_time_bounds,
)


def _sample_df():
    timestamps = pd.date_range("2017-01-01 00:00:00", periods=10, freq="1s")
    return pd.DataFrame({
        "timestamp": timestamps,
        "is_attack": [0, 0, 0, 1, 1, 0, 0, 1, 1, 1],
    })


def test_assign_windows_groups_by_fixed_interval():
    df = _sample_df()
    windowed = assign_windows(df, "timestamp", window_seconds=2)
    # 10 one-second-spaced records in 2s windows -> window ids 0..4
    assert windowed["window_id"].tolist() == [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]


def test_assign_windows_preserves_temporal_order():
    df = _sample_df().sample(frac=1, random_state=0)  # shuffle input
    windowed = assign_windows(df, "timestamp", window_seconds=2)
    assert windowed["timestamp"].is_monotonic_increasing


def test_window_time_bounds():
    df = _sample_df()
    windowed = assign_windows(df, "timestamp", window_seconds=5)
    bounds = window_time_bounds(windowed, "timestamp")
    assert bounds["record_count"].sum() == len(df)
    assert list(bounds["window_id"]) == sorted(bounds["window_id"])


def test_aggregate_window_labels():
    df = _sample_df()
    windowed = assign_windows(df, "timestamp", window_seconds=5)
    summary = aggregate_window_labels(windowed)
    assert summary["record_count"].sum() == len(df)
    assert set(summary["is_attack_window"].unique()) <= {0, 1}


def test_build_supervised_windows_shapes_and_order():
    feature_df = pd.DataFrame({
        "window_id": range(10),
        "flow_count": range(10, 20),
    })
    label_df = pd.DataFrame({
        "window_id": range(10),
        "is_attack_window": [0, 0, 1, 1, 0, 0, 1, 0, 1, 1],
    })
    X, y, last_ids = build_supervised_windows(
        feature_df, label_df, observation_windows=3, forecast_horizon=1
    )
    # windows 0..9, W=3, H=1 -> valid samples end at index 3..8 (need target at end+1)
    assert X.shape[0] == len(y) == len(last_ids)
    assert X.shape[1] == 3  # 3 observation windows * 1 feature
    # samples must be in ascending window order (no shuffling)
    assert last_ids == sorted(last_ids)


def test_build_supervised_windows_skips_gaps():
    # window_id 5 missing -> any observation slice spanning the gap must be skipped
    feature_df = pd.DataFrame({
        "window_id": [0, 1, 2, 3, 4, 6, 7, 8],
        "flow_count": range(8),
    })
    label_df = pd.DataFrame({
        "window_id": [0, 1, 2, 3, 4, 6, 7, 8],
        "is_attack_window": [0, 0, 0, 1, 0, 1, 0, 1],
    })
    X, y, last_ids = build_supervised_windows(
        feature_df, label_df, observation_windows=2, forecast_horizon=1
    )
    # window_id 4's only valid observation pair is (3, 4), whose target
    # window_id 5 does not exist (gap), so it must never appear as a sample.
    assert 4 not in last_ids
    assert last_ids == [1, 2, 3, 7]
