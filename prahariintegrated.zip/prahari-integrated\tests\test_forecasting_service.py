"""Tests for backend/forecasting_service.py."""
from pathlib import Path

import numpy as np
import pytest

from backend.forecasting_service import (
    CALENDAR_FEATURES,
    DEMO_MIN_BASELINE_SAMPLES,
    DEMO_Z_SCORE_CRITICAL_THRESHOLD,
    DEMO_Z_SCORE_ELEVATED_THRESHOLD,
    DEMO_Z_SCORE_HIGH_RISK_THRESHOLD,
    DEMONSTRATION_MODE,
    HISTORY_MINUTES,
    LAG_OFFSETS,
    PREDICTOR_COLUMN_ORDER,
    PRIMARY_FEATURES,
    RISK_CRITICAL,
    RISK_ELEVATED,
    RISK_HIGH_RISK,
    RISK_NORMAL,
    RISK_UNVALIDATED,
    VALIDATED_MODEL_MODE,
    ForecastingService,
    build_feature_vector,
)

NONEXISTENT = Path("/nonexistent/model.joblib")


def _synthetic_minute(total_flows, minute_of_hour=0, hour=0, top_source_ip=None, top_source_ip_flow_share=None):
    row = {f: float(i + 1) for i, f in enumerate(PRIMARY_FEATURES)}
    row["total_flows"] = float(total_flows)
    row["minute_of_hour"] = minute_of_hour
    row["hour"] = hour
    row["top_source_ip"] = top_source_ip
    row["top_source_ip_flow_share"] = top_source_ip_flow_share
    row["top_destination_ip"] = None
    row["top_destination_port"] = None
    row["top_source_ip_flow_count"] = None
    return row


def test_history_minutes_matches_lag_offsets():
    assert HISTORY_MINUTES == len(LAG_OFFSETS) == 3


def test_predictor_column_order_excludes_leakage_columns():
    for leaky in ("benign_flows", "attack_flows", "attack_ratio", "attack_next_minute",
                  "attack_count_next_minute", "attack_ratio_next_minute", "day_of_week"):
        assert leaky not in PREDICTOR_COLUMN_ORDER


def test_build_feature_vector_orders_lags_oldest_to_current():
    history = [_synthetic_minute(100), _synthetic_minute(200), _synthetic_minute(300)]
    X = build_feature_vector(history)
    assert X.shape == (1, len(PREDICTOR_COLUMN_ORDER))

    idx_lag2 = PREDICTOR_COLUMN_ORDER.index("lag2_total_flows")
    idx_lag1 = PREDICTOR_COLUMN_ORDER.index("lag1_total_flows")
    idx_lag0 = PREDICTOR_COLUMN_ORDER.index("lag0_total_flows")
    assert X[0, idx_lag2] == 100
    assert X[0, idx_lag1] == 200
    assert X[0, idx_lag0] == 300


def test_build_feature_vector_rejects_wrong_history_length():
    with pytest.raises(ValueError):
        build_feature_vector([_synthetic_minute(1), _synthetic_minute(2)])


def test_service_reports_insufficient_history_before_three_minutes():
    service = ForecastingService(model_path=NONEXISTENT)
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.ready is False
    assert result.model_status == "INSUFFICIENT_HISTORY"
    assert result.risk_state == RISK_UNVALIDATED

    service.observe_minute(_synthetic_minute(100))
    service.observe_minute(_synthetic_minute(100))
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.ready is False  # still only 2 minutes


def test_forecast_window_descriptor_present_even_when_not_ready():
    service = ForecastingService(model_path=NONEXISTENT)
    result = service.forecast(VALIDATED_MODEL_MODE)
    assert result.forecast_window["horizon_minutes"] == 30
    assert "30" in result.forecast_window["label"]


def test_validated_mode_reports_model_unavailable_without_a_model_file():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(VALIDATED_MODEL_MODE)
    assert result.ready is False
    assert result.model_status == "MODEL_UNAVAILABLE"
    assert result.risk_state == RISK_UNVALIDATED


def test_demo_mode_needs_a_baseline_before_flagging_anything():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.model_status == "INSUFFICIENT_BASELINE"


def test_demo_mode_flags_an_extreme_volume_spike_as_critical():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(DEMO_MIN_BASELINE_SAMPLES + HISTORY_MINUTES - 1):
        service.observe_minute(_synthetic_minute(100))
    service.observe_minute(_synthetic_minute(100_000))

    result = service.forecast(DEMONSTRATION_MODE)
    assert result.ready is True
    assert result.model_status == "HEURISTIC_NOT_A_TRAINED_MODEL"
    assert "DDoS" in result.attack_type
    assert result.risk_state == RISK_CRITICAL
    assert result.extra["z_score"] >= DEMO_Z_SCORE_CRITICAL_THRESHOLD
    assert any(e["signal"] == "traffic_volume_zscore" for e in result.evidence)


def test_demo_mode_flags_a_moderate_volume_spike_as_high_risk_not_critical():
    service = ForecastingService(model_path=NONEXISTENT)
    baseline_rows = [90, 95, 100, 105, 110]
    for v in baseline_rows:
        service.observe_minute(_synthetic_minute(v))
    for _ in range(HISTORY_MINUTES - 1):
        service.observe_minute(_synthetic_minute(100))
    service.observe_minute(_synthetic_minute(115))

    result = service.forecast(DEMONSTRATION_MODE)
    assert result.ready is True
    assert DEMO_Z_SCORE_HIGH_RISK_THRESHOLD <= result.extra["z_score"] < DEMO_Z_SCORE_CRITICAL_THRESHOLD
    assert result.risk_state == RISK_HIGH_RISK


def test_demo_mode_stays_quiet_for_normal_traffic():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(DEMO_MIN_BASELINE_SAMPLES + HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.attack_type == "none"
    assert result.risk_state == RISK_NORMAL


def test_demo_mode_includes_suspicious_source_evidence_when_available():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(DEMO_MIN_BASELINE_SAMPLES + HISTORY_MINUTES - 1):
        service.observe_minute(_synthetic_minute(100))
    service.observe_minute(_synthetic_minute(
        100_000, top_source_ip="172.16.0.1", top_source_ip_flow_share=0.66,
    ))
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.suspicious_source is not None
    assert result.suspicious_source["source_ip"] == "172.16.0.1"
    assert any(e["signal"] == "top_source_ip_share" for e in result.evidence)


def test_suspicious_source_is_none_when_not_available():
    service = ForecastingService(model_path=NONEXISTENT)
    for _ in range(DEMO_MIN_BASELINE_SAMPLES + HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(DEMONSTRATION_MODE)
    assert result.suspicious_source is None


def test_unknown_mode_raises():
    service = ForecastingService(model_path=NONEXISTENT)
    with pytest.raises(ValueError):
        service.forecast("NOT_A_REAL_MODE")


def test_validated_mode_against_real_window_model_if_present():
    """The window forecaster (ai/train_window_forecaster.py) is the
    default model this service loads. Verify it reports its own honest,
    documented status rather than a fabricated validated result."""
    from ai.config import WINDOW_METRICS_PATH, WINDOW_MODEL_PATH
    if not WINDOW_MODEL_PATH.exists() or not WINDOW_METRICS_PATH.exists():
        pytest.skip("window model artifacts not present; run ai/train_window_forecaster.py first")

    service = ForecastingService()  # default paths
    for _ in range(HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(VALIDATED_MODEL_MODE)
    assert result.ready is True
    assert result.model_status in ("DEGENERATE_SINGLE_CLASS_TRAINING", "SINGLE_EPISODE_UNVALIDATED")
    assert result.risk_state == RISK_UNVALIDATED  # never a false "safe" read
    assert result.forecast_window["horizon_minutes"] == 30
    if result.model_status == "SINGLE_EPISODE_UNVALIDATED":
        assert result.confidence is None  # never a fabricated confidence
        assert len(result.evidence) > 0  # real feature-importance evidence


def test_validated_mode_against_real_1minute_baseline_still_works():
    """The original 1-minute baseline (ai/train_baseline_forecaster.py) is
    preserved and must still work when explicitly pointed at."""
    from ai.config import PROCESSED_DATA_DIR
    model_path = PROCESSED_DATA_DIR / "baseline_random_forest.joblib"
    metrics_path = PROCESSED_DATA_DIR / "baseline_metrics.json"
    if not model_path.exists() or not metrics_path.exists():
        pytest.skip("original baseline artifacts not present; run ai/train_baseline_forecaster.py first")

    service = ForecastingService(model_path=model_path, metrics_path=metrics_path)
    for _ in range(HISTORY_MINUTES):
        service.observe_minute(_synthetic_minute(100))
    result = service.forecast(VALIDATED_MODEL_MODE)
    assert result.ready is True
    if service.train_single_class:
        assert result.probability == 0.0
        assert result.model_status == "DEGENERATE_SINGLE_CLASS_TRAINING"
        assert result.attack_type == "none"
        assert result.risk_state == RISK_UNVALIDATED
