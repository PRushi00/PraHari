"""Temporal windowing of timestamped traffic records.

These functions divide a time-ordered traffic log into fixed-size windows
and aggregate per-window statistics, preserving temporal order throughout.
The observation-window length (W) and forecast horizon (H) are NOT fixed
here -- they are parameters, to be chosen later from analyze_temporal.py's
findings. This module only provides the reusable mechanics:

    X = features of the W windows preceding window i
    y = attack condition of the window at i + horizon

Nothing here shuffles or randomly splits data; splits over time must be
done by cutting a point on the timeline (e.g. train on early windows, test
on later ones), never by random sampling of rows.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def assign_windows(
    df: pd.DataFrame,
    timestamp_col: str,
    window_seconds: float,
    window_id_col: str = "window_id",
) -> pd.DataFrame:
    """Assign each row to a fixed-size time window, sorted by timestamp.

    window_id 0 covers [t0, t0 + window_seconds), window_id 1 the next
    interval, and so on, where t0 is the earliest timestamp in df.
    """
    if timestamp_col not in df.columns:
        raise ValueError(f"timestamp column '{timestamp_col}' not found in dataframe")
    if window_seconds <= 0:
        raise ValueError("window_seconds must be positive")

    df = df.sort_values(timestamp_col).reset_index(drop=True)
    ts = pd.to_datetime(df[timestamp_col])
    t0 = ts.min()
    elapsed_seconds = (ts - t0).dt.total_seconds()
    df[window_id_col] = np.floor(elapsed_seconds / window_seconds).astype(int)
    return df


def window_time_bounds(
    df: pd.DataFrame,
    timestamp_col: str,
    window_id_col: str = "window_id",
) -> pd.DataFrame:
    """Return the start/end timestamp and row count for each window id."""
    grouped = df.groupby(window_id_col)[timestamp_col]
    bounds = grouped.agg(window_start="min", window_end="max", record_count="count")
    return bounds.reset_index().sort_values(window_id_col).reset_index(drop=True)


def aggregate_window_labels(
    df: pd.DataFrame,
    window_id_col: str = "window_id",
    attack_col: str = "is_attack",
) -> pd.DataFrame:
    """Summarize attack activity per window.

    Returns one row per window_id with:
      - record_count: number of traffic records in the window
      - attack_count: number of attack-labeled records
      - attack_ratio: attack_count / record_count
      - is_attack_window: 1 if any record in the window is an attack
    """
    if attack_col not in df.columns:
        raise ValueError(f"attack column '{attack_col}' not found in dataframe")

    grouped = df.groupby(window_id_col)[attack_col]
    summary = grouped.agg(record_count="count", attack_count="sum")
    summary["attack_ratio"] = summary["attack_count"] / summary["record_count"]
    summary["is_attack_window"] = (summary["attack_count"] > 0).astype(int)
    return summary.reset_index().sort_values(window_id_col).reset_index(drop=True)


def build_supervised_windows(
    window_feature_df: pd.DataFrame,
    window_label_df: pd.DataFrame,
    observation_windows: int,
    forecast_horizon: int,
    window_id_col: str = "window_id",
    label_col: str = "is_attack_window",
) -> tuple[np.ndarray, np.ndarray, list[int]]:
    """Build (X, y) supervised samples from per-window features and labels.

    For each candidate index i (in ascending window_id order):
      X[i] = flattened features from windows [i - observation_windows, i)
      y[i] = label of the window at i - 1 + forecast_horizon

    observation_windows (W) and forecast_horizon (H) are caller-supplied --
    this function does not assume any particular value, since the right W/H
    should be chosen from the temporal analysis, not guessed.

    Only contiguous, gap-free window ranges are used for a given sample, and
    windows are never reordered, so no future information leaks backwards
    and no random shuffling occurs.

    Returns (X, y, window_ids) where window_ids[i] is the window_id of the
    *last* observation window used to build sample i.
    """
    if observation_windows < 1:
        raise ValueError("observation_windows must be >= 1")
    if forecast_horizon < 1:
        raise ValueError("forecast_horizon must be >= 1")

    features = window_feature_df.sort_values(window_id_col).reset_index(drop=True)
    labels = window_label_df.sort_values(window_id_col).reset_index(drop=True)

    merged = features.merge(labels[[window_id_col, label_col]], on=window_id_col, how="inner")
    merged = merged.sort_values(window_id_col).reset_index(drop=True)

    feature_cols = [c for c in features.columns if c != window_id_col]
    window_ids = merged[window_id_col].to_numpy()

    X_list, y_list, last_obs_window_ids = [], [], []
    n = len(merged)
    for end_idx in range(observation_windows, n):
        obs_slice = merged.iloc[end_idx - observation_windows:end_idx]
        obs_ids = obs_slice[window_id_col].to_numpy()
        # Require the observation window ids to be contiguous (no gaps from
        # missing/unaggregated windows), so features truly represent a
        # continuous look-back period.
        if not np.all(np.diff(obs_ids) == 1):
            continue

        target_window_id = obs_ids[-1] + forecast_horizon
        target_rows = merged.index[merged[window_id_col] == target_window_id]
        if len(target_rows) == 0:
            continue

        X_list.append(obs_slice[feature_cols].to_numpy().flatten())
        y_list.append(merged.loc[target_rows[0], label_col])
        last_obs_window_ids.append(int(obs_ids[-1]))

    X = np.array(X_list) if X_list else np.empty((0, observation_windows * len(feature_cols)))
    y = np.array(y_list) if y_list else np.empty((0,))
    return X, y, last_obs_window_ids
