"""Local SQLite persistence for threat events and blockchain records.

Real, working durable storage -- an actual sqlite3 file on disk, not a
simulated or planned one. Kept as a thin, OPTIONAL layer that
backend/threat_service.py's ThreatEventStore and blockchain/ledger.py's
LocalBlockchainLedger can be handed at construction time:

- Without a SqlitePersistence instance, both stores behave exactly as
  before this module existed -- in-memory only, state lost on restart.
  Every test written against that in-memory-only behavior keeps passing
  unmodified.
- With one, every stored threat event / blockchain record is also
  durably written, and each store's __init__ loads back whatever rows
  already exist -- so a threat event generated and recorded on the
  blockchain before a restart is still there after one, closing the gap
  in the previous "durable storage is what the blockchain ledger stage
  provides" claim: that local chain is itself an in-process simulation
  (see blockchain/ledger.py's own docstring) and does not, on its own,
  survive a process restart.

No ORM, no migrations, no connection pool -- one file, two tables, plain
SQL. Appropriate for a single-process local prototype; a production
deployment would use a real database service instead, not this file.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS threat_events (
    event_id TEXT PRIMARY KEY,
    seq INTEGER NOT NULL,
    data TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS blockchain_records (
    event_id TEXT PRIMARY KEY,
    data TEXT NOT NULL
);
"""


class SqlitePersistence:
    """One sqlite3 connection over one file, shared by both stores it
    backs. check_same_thread=False because FastAPI's sync route handlers
    can run on a different thread than __init__ -- this prototype is
    single-process, never concurrent writers, so that relaxation is safe
    here."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def save_threat_event(self, event_id: str, seq: int, data: dict) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO threat_events (event_id, seq, data) VALUES (?, ?, ?)",
            (event_id, seq, json.dumps(data)),
        )
        self._conn.commit()

    def load_threat_events(self) -> list[dict]:
        """Oldest-first, matching ThreatEventStore's own insertion order."""
        rows = self._conn.execute("SELECT data FROM threat_events ORDER BY seq ASC").fetchall()
        return [json.loads(row[0]) for row in rows]

    def clear_threat_events(self) -> None:
        self._conn.execute("DELETE FROM threat_events")
        self._conn.commit()

    def save_blockchain_record(self, event_id: str, data: dict) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO blockchain_records (event_id, data) VALUES (?, ?)",
            (event_id, json.dumps(data)),
        )
        self._conn.commit()

    def load_blockchain_records(self) -> dict[str, dict]:
        rows = self._conn.execute("SELECT event_id, data FROM blockchain_records").fetchall()
        return {event_id: json.loads(data) for event_id, data in rows}

    def clear_blockchain_records(self) -> None:
        self._conn.execute("DELETE FROM blockchain_records")
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()
