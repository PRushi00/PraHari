"""Tests for ai/train_window_logreg_baseline.py."""
import numpy as np
import pandas as pd

from ai.build_window_forecast_dataset import PREDICTOR_COLUMN_ORDER, TARGET_COLUMN
from ai.train_window_forecaster import choose_split
from ai.train_window_logreg_baseline import determine_model_status, train_and_evaluate


def _synthetic_dataset(labels: list[int]) -> pd.DataFrame:
    n = len(labels)
    timestamps = pd.date_range("2017-01-01", periods=n, freq="1min")
    data = {col: np.arange(n, dtype=float) + i for i, col in enumerate(PREDICTOR_COLUMN_ORDER)}
    df = pd.DataFrame(data)
    df["timestamp"] = timestamps
    df[TARGET_COLUMN] = labels
    return df


def test_train_and_evaluate_reports_real_metrics_not_fabricated():
    labels = [1] * 46 + [0] * 15  # mirrors the real 61-row dataset's shape
    df = _synthetic_dataset(labels)
    split_idx, frac, _ = choose_split(df)
    results = train_and_evaluate(df, split_idx)

    assert results["train_size"] + results["test_size"] == len(df)
    assert 0.0 <= results["accuracy"] <= 1.0
    assert isinstance(results["confusion_matrix"], list)
    assert len(results["top_coefficients_by_magnitude"]) <= 10
    # test slice here is all-negative (matches the real dataset's shape),
    # so ROC-AUC must be explicitly withheld, never fabricated.
    if results["test_single_class"]:
        assert results["roc_auc"] is None
        assert results["roc_auc_note"] is not None


def test_train_and_evaluate_uses_scaled_features_pipeline():
    labels = [1] * 46 + [0] * 15
    df = _synthetic_dataset(labels)
    split_idx, _, _ = choose_split(df)
    results = train_and_evaluate(df, split_idx)
    assert "scaler" in results["model"].named_steps
    assert "logreg" in results["model"].named_steps


def test_determine_model_status_flags_degenerate_training():
    assert determine_model_status({"train_single_class": True}) == "DEGENERATE_SINGLE_CLASS_TRAINING"


def test_determine_model_status_flags_single_episode_unvalidated_otherwise():
    assert determine_model_status({"train_single_class": False}) == "SINGLE_EPISODE_UNVALIDATED"


def test_logreg_model_is_never_loaded_by_the_live_forecasting_service():
    """The live API must only ever serve the RandomForest window model --
    this comparison baseline is research-only and must not be wired in."""
    import inspect

    import backend.forecasting_service as fs
    source = inspect.getsource(fs)
    assert "train_window_logreg_baseline" not in source
    assert "WINDOW_LOGREG" not in source


def test_real_logreg_artifacts_if_present_carry_the_not_used_by_live_api_flag():
    import json

    from ai.config import WINDOW_LOGREG_METRICS_PATH

    if not WINDOW_LOGREG_METRICS_PATH.exists():
        import pytest
        pytest.skip("logreg baseline not trained yet; run ai/train_window_logreg_baseline.py first")

    with open(WINDOW_LOGREG_METRICS_PATH) as fh:
        metrics = json.load(fh)
    assert metrics["not_used_by_live_api"] is True
    assert metrics["model_status"] in ("DEGENERATE_SINGLE_CLASS_TRAINING", "SINGLE_EPISODE_UNVALIDATED")
