"""Shared configuration and constants for the data pipeline.

Centralizing these values means every module agrees on where data lives and
which column names to look for, without hard-coding paths or magic strings
in multiple places.
"""
from __future__ import annotations

from pathlib import Path

# --- Filesystem layout -------------------------------------------------
# Resolved relative to this file so the pipeline works regardless of the
# current working directory it is invoked from.
PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
PLOTS_DIR = PROCESSED_DATA_DIR / "plots"

CLEANED_DATA_PATH = PROCESSED_DATA_DIR / "cleaned.csv"
LABEL_MAPPING_PATH = PROCESSED_DATA_DIR / "label_mapping.json"
FORECASTING_DATASET_PATH = PROCESSED_DATA_DIR / "forecasting_dataset.csv"
LAGGED_FORECASTING_DATASET_PATH = PROCESSED_DATA_DIR / "lagged_forecasting_dataset.csv"

# --- Operational forecast-window formulation (Phase 1 evolution) ---------
# The original per-minute research baseline (attack_next_minute, 1-minute
# horizon) is kept fully intact -- see LAGGED_FORECASTING_DATASET_PATH and
# ai/train_baseline_forecaster.py. This second, parallel formulation asks a
# more operationally realistic question ("is an attack likely somewhere in
# the next half hour", not "an exact minute"), without replacing the first.
FORECAST_WINDOW_MINUTES = 30
WINDOW_FORECAST_DATASET_PATH = PROCESSED_DATA_DIR / "window_forecast_dataset.csv"
WINDOW_MODEL_PATH = PROCESSED_DATA_DIR / "window_random_forest.joblib"
WINDOW_METRICS_PATH = PROCESSED_DATA_DIR / "window_metrics.json"

# --- Early-warning lead-time analysis (ai/analyze_forecast_lead_time.py) --
# Precomputed once (same load-once-at-startup convention as WINDOW_METRICS_PATH
# above) so the live backend can serve it without re-replaying the dataset.
LEAD_TIME_PATH = PROCESSED_DATA_DIR / "lead_time_analysis.json"

# --- Logistic Regression baseline (ai/train_window_logreg_baseline.py) -----
# A second, simpler model trained on the exact same window-forecast dataset
# and split as the RandomForest above -- kept as a research-only comparison
# artifact, never wired into the live API.
WINDOW_LOGREG_MODEL_PATH = PROCESSED_DATA_DIR / "window_logreg_baseline.joblib"
WINDOW_LOGREG_METRICS_PATH = PROCESSED_DATA_DIR / "window_logreg_baseline_metrics.json"

# --- Runtime persistence (storage/persistence.py) --------------------------
# Live process state (threat events, blockchain records) -- NOT a pipeline
# artifact, so it lives outside data/processed/ and is gitignored (a fresh
# clone starts with an empty database, same as it always started with an
# empty in-memory store before this existed).
RUNTIME_DIR = DATA_DIR / "runtime"
RUNTIME_DB_PATH = RUNTIME_DIR / "prahari_state.sqlite3"

# --- Dataset column detection -------------------------------------------
# CICIDS2017 CSV releases are inconsistent about exact column names
# (leading spaces, different capitalization, sometimes no timestamp at
# all). These candidate lists are checked case-insensitively after column
# names have been normalized (stripped + lowercased + spaces->underscores).
TIMESTAMP_COLUMN_CANDIDATES = [
    "timestamp",
    "flow_start_time",
    "start_time",
    "starttime",
    "flow_timestamp",
]

LABEL_COLUMN_CANDIDATES = [
    "label",
    "class",
    "attack",
    "attack_type",
    "attack_cat",
]

# Values (after lowercasing/stripping) treated as "no attack".
BENIGN_LABEL_VALUES = {"benign", "normal", "none", "no attack"}

# Candidate identifier / grouping columns used opportunistically by feature
# extraction when they exist in a given CICIDS2017 release. Not all releases
# retain source/destination IPs (some strip them for privacy).
SOURCE_IP_CANDIDATES = ["source_ip", "src_ip", "srcip"]
DEST_IP_CANDIDATES = ["destination_ip", "dst_ip", "dstip"]
SOURCE_PORT_CANDIDATES = ["source_port", "src_port", "srcport"]
DEST_PORT_CANDIDATES = ["destination_port", "dst_port", "dstport"]
PROTOCOL_CANDIDATES = ["protocol", "protocol_type"]
FLOW_DURATION_CANDIDATES = ["flow_duration", "duration"]

# TCP flag count columns as named in CICFlowMeter output (post-normalization).
TCP_FLAG_COLUMNS = [
    "fin_flag_count",
    "syn_flag_count",
    "rst_flag_count",
    "psh_flag_count",
    "ack_flag_count",
    "urg_flag_count",
    "cwe_flag_count",
    "ece_flag_count",
]

# --- Exploratory window sizes (analysis only, NOT the final model config) -
# Used by analyze_temporal.py to help choose a defensible observation
# window / forecast horizon later. These are exploration candidates only.
CANDIDATE_WINDOW_SECONDS = [1, 5, 10, 30, 60]
