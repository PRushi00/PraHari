"""CICIDS2017 loading and cleaning.

This module deliberately does NOT assume a fixed CICIDS2017 file layout.
It scans data/raw for CSV files, normalizes whatever columns it finds, and
robustly detects the timestamp and label columns rather than hard-coding
their names. Run directly to build data/processed/cleaned.csv:

    python ai/preprocess.py
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Optional

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from ai.config import (
    BENIGN_LABEL_VALUES,
    CLEANED_DATA_PATH,
    LABEL_COLUMN_CANDIDATES,
    LABEL_MAPPING_PATH,
    PROCESSED_DATA_DIR,
    RAW_DATA_DIR,
    TIMESTAMP_COLUMN_CANDIDATES,
)


class DatasetNotFoundError(RuntimeError):
    """Raised when no usable CICIDS2017 CSV files are found."""


def find_csv_files(raw_dir: Path = RAW_DATA_DIR) -> list[Path]:
    """Return every .csv file under raw_dir, searched recursively.

    CICIDS2017 is commonly distributed either as one CSV per capture day,
    or nested inside a "MachineLearningCVE" subfolder, so we search
    recursively instead of assuming a flat layout.
    """
    if not raw_dir.exists():
        return []
    return sorted(p for p in raw_dir.rglob("*.csv") if p.is_file())


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Strip whitespace and normalize column names to snake_case.

    CICIDS2017 CSVs are notorious for inconsistent column names such as
    " Destination Port" (leading space) or "Fwd Packet Length Max".
    """
    new_columns = []
    for col in df.columns:
        name = str(col).strip()
        name = re.sub(r"[^0-9a-zA-Z]+", "_", name)
        name = re.sub(r"_+", "_", name).strip("_").lower()
        new_columns.append(name)
    df = df.copy()
    df.columns = new_columns
    return df


def load_raw_data(files: list[Path]) -> pd.DataFrame:
    """Load and concatenate raw CSV files, tagging each row's source file."""
    if not files:
        raise DatasetNotFoundError(
            f"No CSV files found under {RAW_DATA_DIR}. "
            "Place CICIDS2017 CSV files (e.g. the MachineLearningCVE release) "
            "there before running preprocessing."
        )

    frames = []
    for path in files:
        try:
            df = pd.read_csv(path, low_memory=False, encoding="utf-8", encoding_errors="replace")
        except Exception as exc:  # pragma: no cover - defensive
            print(f"  ! Skipping unreadable file {path.name}: {exc}", file=sys.stderr)
            continue
        df = normalize_column_names(df)
        df["source_file"] = path.name
        frames.append(df)
        print(f"  loaded {path.name}: {len(df)} rows, {df.shape[1]} columns")

    if not frames:
        raise DatasetNotFoundError("CSV files were found but none could be read.")

    combined = pd.concat(frames, axis=0, ignore_index=True, sort=False)
    return combined


def _find_column(columns: list[str], candidates: list[str]) -> Optional[str]:
    for candidate in candidates:
        if candidate in columns:
            return candidate
    return None


def detect_timestamp_column(df: pd.DataFrame) -> Optional[str]:
    """Find the timestamp column by name, falling back to content sniffing."""
    columns = list(df.columns)
    found = _find_column(columns, TIMESTAMP_COLUMN_CANDIDATES)
    if found:
        return found

    # Fallback: try parsing object columns as datetimes and pick the one
    # with the highest successful-parse rate (must clear 50%).
    best_col, best_rate = None, 0.0
    for col in df.columns:
        if not pd.api.types.is_string_dtype(df[col]):
            continue
        sample = df[col].dropna().head(500)
        if sample.empty:
            continue
        parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
        rate = parsed.notna().mean()
        if rate > best_rate:
            best_col, best_rate = col, rate
    return best_col if best_rate >= 0.5 else None


def detect_label_column(df: pd.DataFrame) -> Optional[str]:
    """Find the attack-label column by name, falling back to a heuristic."""
    columns = list(df.columns)
    found = _find_column(columns, LABEL_COLUMN_CANDIDATES)
    if found:
        return found

    # Fallback: an object column with a small number of unique values,
    # at least one of which looks like "benign".
    best_col = None
    for col in df.columns:
        if not pd.api.types.is_string_dtype(df[col]):
            continue
        uniques = df[col].dropna().unique()
        if not (1 < len(uniques) <= 50):
            continue
        lowered = {str(u).strip().lower() for u in uniques}
        if lowered & BENIGN_LABEL_VALUES:
            best_col = col
            break
    return best_col


def parse_timestamps(df: pd.DataFrame, timestamp_col: str) -> pd.DataFrame:
    """Parse the timestamp column in place, reporting unparseable rows."""
    df = df.copy()
    parsed = pd.to_datetime(df[timestamp_col], errors="coerce", format="mixed")
    n_bad = parsed.isna().sum() - df[timestamp_col].isna().sum()
    if n_bad > 0:
        print(f"  ! {n_bad} rows had unparseable timestamps and will be dropped")
    df[timestamp_col] = parsed
    return df


def clean_dataset(df: pd.DataFrame, timestamp_col: Optional[str], label_col: Optional[str]) -> pd.DataFrame:
    """Remove unusable rows/columns and handle NaN/inf values.

    Steps:
      1. Replace +/-inf with NaN (common in rate columns like Flow Bytes/s
         when duration is 0).
      2. Drop columns that are entirely NaN or constant (no signal).
      3. Drop rows missing a timestamp or label (can't use them downstream).
      4. Fill remaining NaN in numeric columns with the column median.
    """
    df = df.copy()
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df[numeric_cols] = df[numeric_cols].replace([np.inf, -np.inf], np.nan)

    before_cols = df.shape[1]
    all_nan_cols = [c for c in df.columns if df[c].isna().all()]
    constant_cols = [
        c for c in df.columns
        if c not in all_nan_cols
        and df[c].notna().sum() >= 2
        and df[c].nunique(dropna=True) <= 1
    ]
    drop_cols = set(all_nan_cols + constant_cols)
    # Never drop the columns we depend on downstream.
    drop_cols -= {timestamp_col, label_col}
    if drop_cols:
        print(f"  dropping {len(drop_cols)} unusable columns (all-NaN or constant)")
        df = df.drop(columns=list(drop_cols))
    print(f"  columns: {before_cols} -> {df.shape[1]}")

    before_rows = len(df)
    required = [c for c in (timestamp_col, label_col) if c is not None]
    if required:
        df = df.dropna(subset=required)
    print(f"  rows: {before_rows} -> {len(df)} (dropped missing timestamp/label)")

    numeric_cols = df.select_dtypes(include=[np.number]).columns
    na_counts = df[numeric_cols].isna().sum()
    cols_with_na = na_counts[na_counts > 0]
    if not cols_with_na.empty:
        medians = df[numeric_cols].median(numeric_only=True)
        df[numeric_cols] = df[numeric_cols].fillna(medians)
        print(f"  filled NaN in {len(cols_with_na)} numeric columns with column medians")

    return df


def encode_labels(df: pd.DataFrame, label_col: str) -> pd.DataFrame:
    """Add is_attack (binary) and label_encoded (multi-class) columns."""
    df = df.copy()
    normalized = df[label_col].astype(str).str.strip().str.lower()
    df["is_attack"] = (~normalized.isin(BENIGN_LABEL_VALUES)).astype(int)

    encoder = LabelEncoder()
    df["label_encoded"] = encoder.fit_transform(df[label_col].astype(str))

    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    mapping = {str(cls): int(code) for code, cls in enumerate(encoder.classes_)}
    with open(LABEL_MAPPING_PATH, "w") as fh:
        json.dump(mapping, fh, indent=2)

    return df


def print_statistics(df: pd.DataFrame, timestamp_col: Optional[str], label_col: Optional[str]) -> None:
    print("\n--- Dataset statistics ---")
    print(f"rows: {len(df)}")
    print(f"columns: {df.shape[1]}")

    if timestamp_col and timestamp_col in df.columns:
        ts = df[timestamp_col].dropna()
        if not ts.empty:
            print(f"time range: {ts.min()} -> {ts.max()} (span: {ts.max() - ts.min()})")
    else:
        print("time range: unknown (no timestamp column detected)")

    if label_col and label_col in df.columns:
        counts = df[label_col].value_counts()
        print(f"available labels ({len(counts)}):")
        for label, count in counts.items():
            print(f"  {label}: {count} ({count / len(df):.2%})")
        if "is_attack" in df.columns:
            attack_counts = df["is_attack"].value_counts()
            n_attack = int(attack_counts.get(1, 0))
            n_benign = int(attack_counts.get(0, 0))
            print(f"benign vs attack: {n_benign} benign / {n_attack} attack")
    else:
        print("labels: unknown (no label column detected)")
    print("--------------------------\n")


def run_pipeline(raw_dir: Path = RAW_DATA_DIR, save_path: Path = CLEANED_DATA_PATH) -> pd.DataFrame:
    print(f"Scanning for CSV files under {raw_dir} ...")
    files = find_csv_files(raw_dir)
    if not files:
        raise DatasetNotFoundError(
            f"No CSV files found under {raw_dir}. "
            "Download CICIDS2017 (e.g. the MachineLearningCVE CSVs) and place "
            "the files there, then re-run this script."
        )
    print(f"Found {len(files)} CSV file(s):")
    for f in files:
        print(f"  - {f.relative_to(raw_dir.parent.parent) if raw_dir.parent.parent in f.parents else f}")

    df = load_raw_data(files)

    timestamp_col = detect_timestamp_column(df)
    label_col = detect_label_column(df)
    print(f"\nDetected timestamp column: {timestamp_col!r}")
    print(f"Detected label column: {label_col!r}")

    if timestamp_col:
        df = parse_timestamps(df, timestamp_col)
    else:
        print("  ! No timestamp column detected; temporal features will be unavailable.")

    df = clean_dataset(df, timestamp_col, label_col)

    if label_col:
        df = encode_labels(df, label_col)
        if timestamp_col:
            df = df.sort_values(timestamp_col).reset_index(drop=True)
    else:
        print("  ! No label column detected; attack encoding skipped.")

    print_statistics(df, timestamp_col, label_col)

    save_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(save_path, index=False)
    print(f"Saved cleaned dataset to {save_path} ({len(df)} rows, {df.shape[1]} cols)")
    return df


if __name__ == "__main__":
    try:
        run_pipeline()
    except DatasetNotFoundError as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        sys.exit(1)
