"""Tests for ai/train_window_forecaster.py."""
import numpy as np
import pandas as pd
import pytest

from ai.train_window_forecaster import (
    CANDIDATE_TRAIN_FRACTIONS,
    choose_split,
    determine_model_status,
    train_and_evaluate,
)
from ai.build_window_forecast_dataset import PREDICTOR_COLUMN_ORDER, TARGET_COLUMN


def _synthetic_dataset(labels: list[int]) -> pd.DataFrame:
    n = len(labels)
    timestamps = pd.date_range("2017-01-01", periods=n, freq="1min")
    data = {col: np.arange(n, dtype=float) + i for i, col in enumerate(PREDICTOR_COLUMN_ORDER)}
    df = pd.DataFrame(data)
    df["timestamp"] = timestamps
    df[TARGET_COLUMN] = labels
    return df


def test_choose_split_picks_smallest_fraction_giving_train_both_classes():
    # 100 rows: first 70 positive, last 30 negative -- mirrors the real
    # dataset's single-transition shape. 0.70 alone gives single-class train.
    labels = [1] * 70 + [0] * 30
    df = _synthetic_dataset(labels)
    split_idx, frac, candidates = choose_split(df)

    assert frac == 0.75  # first fraction where train includes some of the negative tail
    assert len(candidates) == len(CANDIDATE_TRAIN_FRACTIONS)
    used = [c for c in candidates if c["train_fraction"] == frac][0]
    assert used["train_both_classes"] is True


def test_choose_split_falls_back_honestly_when_no_fraction_works():
    # Positive block so long that even 0.90 doesn't reach the negative tail.
    labels = [1] * 95 + [0] * 5
    df = _synthetic_dataset(labels)
    split_idx, frac, candidates = choose_split(df)
    assert frac == CANDIDATE_TRAIN_FRACTIONS[0]  # falls back to first candidate, not silently searching further
    assert all(not c["train_both_classes"] for c in candidates)


def test_choose_split_handles_all_single_class_data():
    labels = [0] * 50
    df = _synthetic_dataset(labels)
    split_idx, frac, candidates = choose_split(df)
    assert frac == CANDIDATE_TRAIN_FRACTIONS[0]
    assert all(c["train_classes"] == [0] for c in candidates)


def test_train_and_evaluate_reports_real_metrics_not_fabricated():
    labels = [1] * 46 + [0] * 15  # mirrors the real 61-row dataset's shape
    df = _synthetic_dataset(labels)
    split_idx, frac, _ = choose_split(df)
    results = train_and_evaluate(df, split_idx)

    assert results["train_size"] + results["test_size"] == len(df)
    assert 0.0 <= results["accuracy"] <= 1.0
    assert isinstance(results["confusion_matrix"], list)
    assert len(results["feature_importances_top10"]) <= 10
    # test slice here is all-negative (matches the real dataset's shape),
    # so ROC-AUC must be explicitly withheld, never fabricated.
    if results["test_single_class"]:
        assert results["roc_auc"] is None
        assert results["roc_auc_note"] is not None


def test_determine_model_status_flags_degenerate_training():
    results = {"train_single_class": True}
    assert determine_model_status(results) == "DEGENERATE_SINGLE_CLASS_TRAINING"


def test_determine_model_status_flags_single_episode_unvalidated_otherwise():
    results = {"train_single_class": False}
    assert determine_model_status(results) == "SINGLE_EPISODE_UNVALIDATED"
