"""Logistic Regression baseline -- a research-only comparison model.

The original PraHari pitch deck named Logistic Regression as a baseline to
compare the "real" model against. This script trains one, on the EXACT
same operational-window dataset and the EXACT same chronological split
selection logic as the RandomForest window forecaster
(ai/train_window_forecaster.py -- load_dataset and choose_split are
imported from there, not reimplemented, so both models are compared on
identical data) -- but reports it as what it is: one more experiment on a
single-episode dataset, not a validated second model, and NOT wired into
the live forecasting API (backend/forecasting_service.py still only ever
loads the RandomForest window model). This file exists purely so the
RandomForest's reported metrics have an honest point of comparison.

Predictor features go through a StandardScaler first (a plain, deterministic
preprocessing step -- Logistic Regression's coefficients are only
meaningful on similarly-scaled inputs; skipping this would produce a
needlessly weak/misleading baseline, not a more "honest" one).

Same single-episode caveat as everywhere else in this repo: the test rows
are the tail of the same episode the model trained on, so nothing here is
a validated generalization claim. Metrics are reported exactly as
measured, however poor.

Run:
    python ai/train_window_logreg_baseline.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from ai.build_window_forecast_dataset import PREDICTOR_COLUMN_ORDER, TARGET_COLUMN
from ai.config import FORECAST_WINDOW_MINUTES, WINDOW_LOGREG_METRICS_PATH, WINDOW_LOGREG_MODEL_PATH
from ai.train_window_forecaster import choose_split, load_dataset

DISCLAIMER = (
    "Research-only comparison baseline, NOT loaded by the live forecasting API (which "
    "only ever serves the RandomForest window model). Trained/evaluated on the exact "
    "same single-episode dataset and split as that model -- the test portion below is "
    "the tail of the SAME attack episode used for training, not an independent "
    "occurrence, so neither model's metrics are a validated generalization claim. "
    "Reported exactly as computed, including if poor."
)


def train_and_evaluate(df, split_idx: int) -> dict:
    X = df[PREDICTOR_COLUMN_ORDER].to_numpy()
    y = df[TARGET_COLUMN].to_numpy()

    X_train, y_train = X[:split_idx], y[:split_idx]
    X_test, y_test = X[split_idx:], y[split_idx:]

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("logreg", LogisticRegression(max_iter=1000, class_weight="balanced")),
    ])
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    classes = list(model.named_steps["logreg"].classes_)
    proba = model.predict_proba(X_test)
    y_proba = proba[:, classes.index(1)] if 1 in classes else np.zeros(len(X_test))

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

    roc_auc = None
    roc_auc_note = None
    if len(np.unique(y_test)) == 2:
        roc_auc = float(roc_auc_score(y_test, y_proba))
    else:
        roc_auc_note = "ROC-AUC not computed: test set does not contain both classes."

    n_pred_pos = int((y_pred == 1).sum())
    false_positive_rate = None
    if (y_test == 0).sum() > 0:
        false_positive_rate = float(((y_pred == 1) & (y_test == 0)).sum() / (y_test == 0).sum())

    coefficients = sorted(
        zip(PREDICTOR_COLUMN_ORDER, model.named_steps["logreg"].coef_[0].tolist()),
        key=lambda kv: -abs(kv[1]),
    )

    return {
        "model": model,
        "train_size": len(y_train),
        "test_size": len(y_test),
        "train_positive": int(y_train.sum()),
        "test_positive": int(y_test.sum()),
        "train_single_class": len(set(y_train.tolist())) < 2,
        "test_single_class": len(set(y_test.tolist())) < 2,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "confusion_matrix": cm.tolist(),
        "roc_auc": roc_auc,
        "roc_auc_note": roc_auc_note,
        "false_positive_rate_on_test": false_positive_rate,
        "n_predicted_positive": n_pred_pos,
        "top_coefficients_by_magnitude": coefficients[:10],
    }


def determine_model_status(results: dict) -> str:
    if results["train_single_class"]:
        return "DEGENERATE_SINGLE_CLASS_TRAINING"
    return "SINGLE_EPISODE_UNVALIDATED"


def main() -> None:
    df = load_dataset()
    print(f"Loaded {len(df)} rows  target={TARGET_COLUMN!r}  window={FORECAST_WINDOW_MINUTES} minutes")

    split_idx, frac_used, candidates = choose_split(df)
    print(f"Using train_fraction={frac_used:.2f} (same split selection as ai/train_window_forecaster.py)")

    train_df = df.iloc[:split_idx]
    test_df = df.iloc[split_idx:]
    print(f"train: {len(train_df)} rows, {int(train_df[TARGET_COLUMN].sum())} positive")
    print(f"test:  {len(test_df)} rows, {int(test_df[TARGET_COLUMN].sum())} positive")

    results = train_and_evaluate(df, split_idx)
    model_status = determine_model_status(results)

    print(f"\nmodel_status: {model_status}")
    print("\n--- Test-set evaluation (reported exactly as computed) ---")
    print(f"accuracy:  {results['accuracy']:.4f}")
    print(f"precision: {results['precision']:.4f}")
    print(f"recall:    {results['recall']:.4f}")
    print(f"f1:        {results['f1']:.4f}")
    print(f"confusion matrix (rows=actual [0,1], cols=predicted [0,1]): {results['confusion_matrix']}")
    if results["roc_auc"] is not None:
        print(f"roc_auc: {results['roc_auc']:.4f}")
    else:
        print(f"roc_auc: not reported -- {results['roc_auc_note']}")
    if results["false_positive_rate_on_test"] is not None:
        print(f"false_positive_rate_on_test: {results['false_positive_rate_on_test']:.4f}")

    print("\ntop coefficients by magnitude (scaled features -- direction only, not a validated causal claim):")
    for name, coef in results["top_coefficients_by_magnitude"][:5]:
        print(f"  {name}: {coef:.4f}")

    WINDOW_LOGREG_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(results["model"], WINDOW_LOGREG_MODEL_PATH)

    metrics = {
        "formulation": {
            "forecast_window_minutes": FORECAST_WINDOW_MINUTES,
            "target": TARGET_COLUMN,
            "n_predictors": len(PREDICTOR_COLUMN_ORDER),
            "algorithm": "LogisticRegression (StandardScaler + class_weight=balanced)",
            "compared_against": "ai/train_window_forecaster.py (RandomForestClassifier), same dataset/split",
        },
        "split": {
            "total_rows": len(df),
            "train_fraction_used": frac_used,
            "train_rows": results["train_size"],
            "test_rows": results["test_size"],
            "train_positive": results["train_positive"],
            "test_positive": results["test_positive"],
            "train_single_class": results["train_single_class"],
            "test_single_class": results["test_single_class"],
            "train_end_timestamp": str(train_df["timestamp"].iloc[-1]),
            "test_start_timestamp": str(test_df["timestamp"].iloc[0]),
        },
        "model_status": model_status,
        "metrics": {
            "accuracy": results["accuracy"],
            "precision": results["precision"],
            "recall": results["recall"],
            "f1": results["f1"],
            "confusion_matrix": results["confusion_matrix"],
            "roc_auc": results["roc_auc"],
            "roc_auc_note": results["roc_auc_note"],
            "false_positive_rate_on_test": results["false_positive_rate_on_test"],
        },
        "top_coefficients_by_magnitude": results["top_coefficients_by_magnitude"],
        "predictor_columns": PREDICTOR_COLUMN_ORDER,
        "disclaimer": DISCLAIMER,
        "not_used_by_live_api": True,
    }
    with open(WINDOW_LOGREG_METRICS_PATH, "w") as fh:
        json.dump(metrics, fh, indent=2, default=str)

    print(f"\nSaved model to:   {WINDOW_LOGREG_MODEL_PATH}")
    print(f"Saved metrics to: {WINDOW_LOGREG_METRICS_PATH}")
    print("\n" + "=" * 70)
    print(DISCLAIMER)
    print("=" * 70)


if __name__ == "__main__":
    main()
