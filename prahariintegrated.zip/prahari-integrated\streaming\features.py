"""Feature extraction over a window of traffic records.

Only builds features from columns that are actually present in the loaded
dataset -- nothing here is fabricated. Call `extract_window_features` on a
DataFrame slice representing a single time window (see streaming/windows.py)
to get a flat, numeric feature dict.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ai.config import (
    DEST_IP_CANDIDATES,
    DEST_PORT_CANDIDATES,
    FLOW_DURATION_CANDIDATES,
    PROTOCOL_CANDIDATES,
    SOURCE_IP_CANDIDATES,
    SOURCE_PORT_CANDIDATES,
    TCP_FLAG_COLUMNS,
)

# Column names (post streaming/preprocess normalization) that, if present,
# contribute packet/byte counts.
_FWD_PACKET_COLS = ["total_fwd_packets", "totlen_fwd_packets"]
_BWD_PACKET_COLS = ["total_backward_packets", "totlen_bwd_packets"]
_FWD_BYTE_COLS = ["total_length_of_fwd_packets", "totlen_fwd_pkts"]
_BWD_BYTE_COLS = ["total_length_of_bwd_packets", "totlen_bwd_pkts"]


def _first_present(columns: list[str], candidates: list[str]) -> str | None:
    for c in candidates:
        if c in columns:
            return c
    return None


def _sum_if_present(df: pd.DataFrame, col: str | None) -> float:
    if col is None or col not in df.columns:
        return np.nan
    return float(pd.to_numeric(df[col], errors="coerce").sum())


def extract_window_features(window_df: pd.DataFrame) -> dict:
    """Compute a compact, defensible feature vector for one traffic window.

    Features are only included when the underlying column exists in the
    dataset, so the returned dict's keys can vary slightly across CICIDS2017
    releases. `get_feature_names` (fit on real data) should be used to build
    a consistent matrix across windows.
    """
    columns = list(window_df.columns)
    features: dict[str, float] = {}

    features["flow_count"] = float(len(window_df))

    fwd_pkt_col = _first_present(columns, _FWD_PACKET_COLS)
    bwd_pkt_col = _first_present(columns, _BWD_PACKET_COLS)
    if fwd_pkt_col or bwd_pkt_col:
        packet_count = _sum_if_present(window_df, fwd_pkt_col) + _sum_if_present(window_df, bwd_pkt_col)
        # np.nan + value == nan; guard for the case only one side exists.
        features["packet_count"] = float(np.nansum([
            _sum_if_present(window_df, fwd_pkt_col),
            _sum_if_present(window_df, bwd_pkt_col),
        ]))

    fwd_byte_col = _first_present(columns, _FWD_BYTE_COLS)
    bwd_byte_col = _first_present(columns, _BWD_BYTE_COLS)
    if fwd_byte_col or bwd_byte_col:
        features["byte_count"] = float(np.nansum([
            _sum_if_present(window_df, fwd_byte_col),
            _sum_if_present(window_df, bwd_byte_col),
        ]))

    duration_col = _first_present(columns, FLOW_DURATION_CANDIDATES)
    if duration_col:
        durations = pd.to_numeric(window_df[duration_col], errors="coerce")
        features["duration_mean"] = float(durations.mean()) if len(durations) else 0.0
        features["duration_max"] = float(durations.max()) if len(durations) else 0.0

        total_duration_seconds = float(durations.sum()) / 1e6 if durations.sum() else 0.0
        # CICIDS2017 flow_duration is in microseconds; guard divide-by-zero.
        if total_duration_seconds > 0:
            if "packet_count" in features:
                features["packet_rate"] = features["packet_count"] / total_duration_seconds
            if "byte_count" in features:
                features["byte_rate"] = features["byte_count"] / total_duration_seconds

    src_ip_col = _first_present(columns, SOURCE_IP_CANDIDATES)
    if src_ip_col:
        features["unique_src_count"] = float(window_df[src_ip_col].nunique())
    dst_ip_col = _first_present(columns, DEST_IP_CANDIDATES)
    if dst_ip_col:
        features["unique_dst_count"] = float(window_df[dst_ip_col].nunique())

    src_port_col = _first_present(columns, SOURCE_PORT_CANDIDATES)
    if src_port_col:
        features["unique_src_port_count"] = float(window_df[src_port_col].nunique())
    dst_port_col = _first_present(columns, DEST_PORT_CANDIDATES)
    if dst_port_col:
        features["unique_dst_port_count"] = float(window_df[dst_port_col].nunique())

    for flag_col in TCP_FLAG_COLUMNS:
        if flag_col in columns:
            features[flag_col] = _sum_if_present(window_df, flag_col)

    protocol_col = _first_present(columns, PROTOCOL_CANDIDATES)
    if protocol_col:
        proto_counts = window_df[protocol_col].value_counts(normalize=True)
        for proto_value, ratio in proto_counts.items():
            features[f"protocol_{proto_value}_ratio"] = float(ratio)

    return features


def extract_features_for_windows(df: pd.DataFrame, window_id_col: str = "window_id") -> pd.DataFrame:
    """Apply extract_window_features to every window, returning one row per window.

    Windows are processed in ascending window_id order to preserve temporal
    ordering; the result is safe to use as a time-ordered feature matrix.
    """
    if window_id_col not in df.columns:
        raise ValueError(f"'{window_id_col}' column not found; call streaming.windows.assign_windows first")

    rows = []
    for window_id, group in df.groupby(window_id_col, sort=True):
        feats = extract_window_features(group)
        feats[window_id_col] = window_id
        rows.append(feats)

    feature_df = pd.DataFrame(rows).fillna(0.0)
    feature_df = feature_df.sort_values(window_id_col).reset_index(drop=True)
    return feature_df


def get_feature_names(feature_df: pd.DataFrame, window_id_col: str = "window_id") -> list[str]:
    return [c for c in feature_df.columns if c != window_id_col]
