"""Build the per-minute temporal forecasting dataset.

Reads the flow-level cleaned dataset (data/processed/cleaned.csv, one row
per network flow) and writes a per-MINUTE forecasting dataset
(data/processed/forecasting_dataset.csv, one row per chronological minute).

This is deliberately NOT a flow-level DDoS classification dataset. Every
flow occurring in a given minute is aggregated into a single row describing
that minute's traffic, and the primary target -- attack_next_minute -- asks
whether the *following* minute contains any DDoS activity. No lag/history
features are added yet; that structure will be decided after inspecting
this aggregated dataset.

Run:
    python ai/build_forecasting_dataset.py
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd

from ai.config import CLEANED_DATA_PATH, FORECASTING_DATASET_PATH
from ai.preprocess import detect_label_column, detect_timestamp_column

# Flow-level columns this script depends on existing in cleaned.csv (as
# produced by ai/preprocess.py). Not configurable here -- if a different
# CICIDS2017 release is used and these are absent, fail loudly rather than
# silently produce an incomplete forecasting dataset.
REQUIRED_FLOW_COLUMNS = [
    "total_fwd_packets",
    "total_backward_packets",
    "total_length_of_fwd_packets",
    "total_length_of_bwd_packets",
    "flow_duration",
    "flow_packets_s",
    "flow_bytes_s",
    "source_ip",
    "destination_ip",
    "destination_port",
    "is_attack",
]

OUTPUT_FEATURE_COLUMNS = [
    "timestamp",
    "total_flows",
    "benign_flows",
    "attack_flows",
    "attack_ratio",
    "total_fwd_packets",
    "total_backward_packets",
    "total_bytes",
    "total_packets",
    "mean_flow_duration",
    "mean_flow_packets_s",
    "mean_flow_bytes_s",
    "unique_source_ips",
    "unique_destination_ips",
    "unique_destination_ports",
    "minute_of_hour",
    "hour",
    "day_of_week",
]


def load_cleaned_dataset(path: Path = CLEANED_DATA_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python ai/preprocess.py` first to produce it."
        )
    return pd.read_csv(path, low_memory=False)


def aggregate_per_minute(df: pd.DataFrame, timestamp_col: str) -> pd.DataFrame:
    """Collapse flow-level rows into exactly one row per chronological minute.

    Only aggregates each minute's own flows -- nothing here looks at any
    other minute, so no future information can leak into these features.
    """
    missing = [c for c in REQUIRED_FLOW_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"cleaned dataset is missing expected column(s): {missing}. "
            "This script expects the output of ai/preprocess.py."
        )

    df = df.copy()
    df[timestamp_col] = pd.to_datetime(df[timestamp_col])

    grouped = df.groupby(timestamp_col, sort=True)

    agg = pd.DataFrame({
        "total_flows": grouped.size(),
        "attack_flows": grouped["is_attack"].sum(),
        "total_fwd_packets": grouped["total_fwd_packets"].sum(),
        "total_backward_packets": grouped["total_backward_packets"].sum(),
        "total_bytes": (
            grouped["total_length_of_fwd_packets"].sum()
            + grouped["total_length_of_bwd_packets"].sum()
        ),
        "mean_flow_duration": grouped["flow_duration"].mean(),
        "mean_flow_packets_s": grouped["flow_packets_s"].mean(),
        "mean_flow_bytes_s": grouped["flow_bytes_s"].mean(),
        "unique_source_ips": grouped["source_ip"].nunique(),
        "unique_destination_ips": grouped["destination_ip"].nunique(),
        "unique_destination_ports": grouped["destination_port"].nunique(),
    })
    agg.index.name = "timestamp"
    agg = agg.reset_index()

    agg["benign_flows"] = agg["total_flows"] - agg["attack_flows"]
    agg["attack_ratio"] = agg["attack_flows"] / agg["total_flows"]
    agg["total_packets"] = agg["total_fwd_packets"] + agg["total_backward_packets"]

    # Calendar features derived only from the current row's own timestamp.
    agg["minute_of_hour"] = agg["timestamp"].dt.minute
    agg["hour"] = agg["timestamp"].dt.hour
    agg["day_of_week"] = agg["timestamp"].dt.dayofweek

    agg = agg.sort_values("timestamp").reset_index(drop=True)
    return agg[OUTPUT_FEATURE_COLUMNS]


def check_minute_continuity(timestamps: pd.Series) -> tuple[bool, int]:
    """Return (is_continuous, gap_count) for 1-minute-spaced timestamps."""
    diffs = timestamps.sort_values().diff().dropna()
    gaps = diffs[diffs != pd.Timedelta(minutes=1)]
    return len(gaps) == 0, len(gaps)


def add_next_minute_targets(agg: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Attach next-minute forecast targets via an explicit timestamp lookup.

    Row t's target is looked up by matching timestamp t+1 exactly, not by
    positionally shifting rows -- this guarantees the target truly belongs
    to the next calendar minute (and would correctly come up missing if a
    minute were ever absent from the data, rather than silently pairing t
    with whatever row happens to sit next in the table). Targets are added
    as a final step, after every feature column above is already fixed, so
    no feature column ever sees t+1 information.
    """
    future = agg[["timestamp", "attack_flows", "attack_ratio"]].copy()
    future["timestamp"] = future["timestamp"] - pd.Timedelta(minutes=1)
    future = future.rename(columns={
        "attack_flows": "attack_count_next_minute",
        "attack_ratio": "attack_ratio_next_minute",
    })

    merged = agg.merge(future, on="timestamp", how="left")

    n_before = len(merged)
    merged = merged.dropna(
        subset=["attack_count_next_minute", "attack_ratio_next_minute"]
    ).copy()
    n_dropped = n_before - len(merged)

    merged["attack_count_next_minute"] = merged["attack_count_next_minute"].astype(int)
    merged["attack_next_minute"] = (merged["attack_count_next_minute"] > 0).astype(int)

    ordered = OUTPUT_FEATURE_COLUMNS + [
        "attack_next_minute",
        "attack_count_next_minute",
        "attack_ratio_next_minute",
    ]
    return merged[ordered].sort_values("timestamp").reset_index(drop=True), n_dropped


def run_sanity_checks(final_df: pd.DataFrame, full_agg: pd.DataFrame) -> None:
    assert final_df["timestamp"].is_monotonic_increasing, "timestamps are not sorted ascending"
    assert final_df["timestamp"].duplicated().sum() == 0, "duplicate timestamps found"
    assert len(final_df) == final_df["timestamp"].nunique(), "not exactly one row per timestamp"

    # Verify the target truly matches the next minute's own attack_flows,
    # using an independent lookup rather than trusting the merge blindly.
    lookup = full_agg.set_index("timestamp")["attack_flows"]
    for _, row in final_df.iterrows():
        next_ts = row["timestamp"] + pd.Timedelta(minutes=1)
        assert next_ts in lookup.index, f"target row references a minute not present in source: {next_ts}"
        expected = int(lookup.loc[next_ts])
        assert int(row["attack_count_next_minute"]) == expected, (
            f"target mismatch at {row['timestamp']}: "
            f"got {row['attack_count_next_minute']}, expected {expected}"
        )
        assert int(row["attack_next_minute"]) == int(expected > 0)

    n_nan = int(final_df.isna().sum().sum())
    assert n_nan == 0, f"{n_nan} NaN values remain in the final dataset"


def print_summary(
    input_rows: int,
    full_agg: pd.DataFrame,
    final_df: pd.DataFrame,
    n_dropped_for_target: int,
) -> None:
    is_continuous, gap_count = check_minute_continuity(full_agg["timestamp"])
    n_nan = int(final_df.isna().sum().sum())

    attack_minutes = int((full_agg["attack_flows"] > 0).sum())
    benign_minutes = int(len(full_agg) - attack_minutes)

    n_positive = int(final_df["attack_next_minute"].sum())
    pct_positive = 100 * n_positive / len(final_df) if len(final_df) else 0.0

    print("\n--- Forecasting dataset summary ---")
    print(f"input rows (flows):        {input_rows}")
    print(f"minute buckets (pre-shift): {len(full_agg)}")
    print(f"output rows (post-shift):   {len(final_df)}")
    print(f"rows dropped (no next minute available): {n_dropped_for_target}")
    print(f"time range: {full_agg['timestamp'].min()} -> {full_agg['timestamp'].max()}")
    print(f"\noutput columns ({len(final_df.columns)}): {list(final_df.columns)}")
    print(f"\nminute-level attack/benign counts (current minute, pre-shift):")
    print(f"  attack minutes: {attack_minutes}  benign minutes: {benign_minutes}")
    print(f"\nattack_next_minute positive class: {n_positive} / {len(final_df)} ({pct_positive:.2f}%)")
    print(f"\ntimestamps continuous at 1-minute intervals: {is_continuous}"
          + ("" if is_continuous else f"  ({gap_count} gap(s) found)"))
    print(f"missing values remaining: {n_nan > 0} ({n_nan} NaN cells)")
    print("------------------------------------\n")


def main() -> None:
    df = load_cleaned_dataset()
    input_rows = len(df)
    print(f"Loaded {input_rows} flow-level rows from {CLEANED_DATA_PATH}")

    timestamp_col = detect_timestamp_column(df) or "timestamp"
    label_col = detect_label_column(df) or "label"
    if timestamp_col not in df.columns:
        raise ValueError("could not detect a timestamp column in the cleaned dataset")
    print(f"timestamp column: {timestamp_col!r}  label column: {label_col!r}")

    full_agg = aggregate_per_minute(df, timestamp_col)
    final_df, n_dropped = add_next_minute_targets(full_agg)

    run_sanity_checks(final_df, full_agg)
    print("All sanity checks passed.")

    print_summary(input_rows, full_agg, final_df, n_dropped)

    FORECASTING_DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    final_df.to_csv(FORECASTING_DATASET_PATH, index=False)
    print(f"Saved forecasting dataset to {FORECASTING_DATASET_PATH} "
          f"({final_df.shape[0]} rows, {final_df.shape[1]} cols)")


if __name__ == "__main__":
    main()
