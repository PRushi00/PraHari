"""Tests for blockchain/ledger.py."""
from unittest.mock import patch

import pytest

from blockchain.ledger import (
    CHAIN_STATUS_CONFIRMED,
    CHAIN_STATUS_UNAVAILABLE,
    LocalBlockchainLedger,
    canonicalize,
    compute_threat_hash,
)


def _sample_event(event_id="evt_test1", severity="LOW", attack_probability=0.0):
    return {
        "event_id": event_id,
        "timestamp": "2017-07-07T03:57:00",
        "source": "cicids2017-friday-ddos-replay",
        "forecast_mode": "VALIDATED_MODEL_MODE",
        "model_status": "DEGENERATE_SINGLE_CLASS_TRAINING",
        "predicted_attack_type": "none",
        "attack_probability": attack_probability,
        "confidence": None,
        "forecast_horizon_seconds": 60,
        "severity": severity,
        "recommendation": "Model cannot yet provide a validated attack forecast.",
        "model_version": "baseline-random-forest-v1",
        "explanation": "test",
    }


# --- canonicalization / hashing -----------------------------------------

def test_canonicalize_is_stable_regardless_of_key_order():
    a = {"b": 1, "a": 2, "c": {"y": 1, "x": 2}}
    b = {"a": 2, "c": {"x": 2, "y": 1}, "b": 1}
    assert canonicalize(a) == canonicalize(b)


def test_compute_threat_hash_matches_manual_sha256():
    import hashlib
    import json
    event = _sample_event()
    expected = "0x" + hashlib.sha256(
        json.dumps(event, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()
    assert compute_threat_hash(event) == expected


def test_hash_changes_when_any_field_changes():
    h1 = compute_threat_hash(_sample_event(severity="LOW"))
    h2 = compute_threat_hash(_sample_event(severity="CRITICAL"))
    assert h1 != h2


# --- ledger availability --------------------------------------------------

def test_ledger_initializes_available_in_this_environment():
    ledger = LocalBlockchainLedger()
    assert ledger.available is True
    assert ledger.unavailable_reason is None
    assert ledger.chain_id is not None


def test_ledger_degrades_gracefully_when_backend_unavailable():
    with patch("web3.EthereumTesterProvider", side_effect=RuntimeError("no backend here")):
        ledger = LocalBlockchainLedger()
    assert ledger.available is False
    assert ledger.unavailable_reason is not None

    event = _sample_event()
    record = ledger.record_threat(event)
    assert record["chain_status"] == CHAIN_STATUS_UNAVAILABLE
    assert record["blockchain_transaction_id"] is None
    assert record["block_number"] is None
    assert record["threat_hash"] == compute_threat_hash(event)  # hash is still computed honestly


# --- record_threat --------------------------------------------------------

def test_record_threat_writes_a_real_confirmed_record():
    ledger = LocalBlockchainLedger()
    event = _sample_event()
    record = ledger.record_threat(event)

    assert record["event_id"] == event["event_id"]
    assert record["chain_status"] == CHAIN_STATUS_CONFIRMED
    assert record["threat_hash"] == compute_threat_hash(event)
    assert isinstance(record["block_number"], int) and record["block_number"] >= 0
    assert record["blockchain_transaction_id"].startswith("0x")
    assert len(record["blockchain_transaction_id"]) == 66  # 0x + 64 hex chars


def test_record_threat_is_idempotent_for_same_event_id():
    ledger = LocalBlockchainLedger()
    event = _sample_event()
    record1 = ledger.record_threat(event)
    record2 = ledger.record_threat(event)
    assert record1["blockchain_transaction_id"] == record2["blockchain_transaction_id"]
    assert record1["block_number"] == record2["block_number"]
    assert len(ledger.list_records()) == 1


def test_get_record_returns_none_for_unknown_event():
    ledger = LocalBlockchainLedger()
    assert ledger.get_record("evt_never_recorded") is None


def test_list_records_is_most_recent_first():
    ledger = LocalBlockchainLedger()
    e1 = ledger.record_threat(_sample_event(event_id="evt_a"))
    e2 = ledger.record_threat(_sample_event(event_id="evt_b"))
    records = ledger.list_records()
    assert records[0]["event_id"] == "evt_b"
    assert records[1]["event_id"] == "evt_a"


# --- verify_threat / tamper detection --------------------------------------

def test_verify_original_event_succeeds():
    ledger = LocalBlockchainLedger()
    event = _sample_event()
    ledger.record_threat(event)

    result = ledger.verify_threat(event)
    assert result["verified"] is True
    assert result["recomputed_hash"] == result["stored_hash"]


def test_verify_tampered_severity_fails():
    ledger = LocalBlockchainLedger()
    original = _sample_event(severity="LOW")
    ledger.record_threat(original)

    tampered = dict(original)
    tampered["severity"] = "CRITICAL"  # attacker/bug changes severity after the fact
    result = ledger.verify_threat(tampered)

    assert result["verified"] is False
    assert result["recomputed_hash"] != result["stored_hash"]


def test_verify_tampered_probability_fails():
    ledger = LocalBlockchainLedger()
    original = _sample_event(attack_probability=0.0)
    ledger.record_threat(original)

    tampered = dict(original)
    tampered["attack_probability"] = 0.95  # fabricated probability injected after recording
    result = ledger.verify_threat(tampered)

    assert result["verified"] is False


def test_verify_unrecorded_event_reports_not_verified():
    ledger = LocalBlockchainLedger()
    event = _sample_event(event_id="evt_never_recorded_2")
    result = ledger.verify_threat(event)
    assert result["verified"] is False
    assert result["stored_hash"] is None
    assert "no blockchain record" in result["reason"]


def test_verify_never_fabricates_a_match_when_backend_unavailable():
    with patch("web3.EthereumTesterProvider", side_effect=RuntimeError("no backend here")):
        ledger = LocalBlockchainLedger()
    event = _sample_event()
    ledger.record_threat(event)  # stores an UNAVAILABLE record with a real hash, no tx

    result = ledger.verify_threat(event)
    assert result["verified"] is True  # hash still matches what was honestly stored
    tampered = dict(event)
    tampered["severity"] = "CRITICAL"
    assert ledger.verify_threat(tampered)["verified"] is False


def test_clear_removes_all_records():
    ledger = LocalBlockchainLedger()
    ledger.record_threat(_sample_event())
    ledger.clear()
    assert ledger.list_records() == []
