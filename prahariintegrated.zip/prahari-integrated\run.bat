@echo off
REM PRAHARI -- one-command run for Windows (double-click this file).
REM It just hands off to run.ps1, which does the real work.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
echo.
echo PRAHARI has stopped. Press any key to close this window.
pause >nul
