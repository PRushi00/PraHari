#!/usr/bin/env bash
# PRAHARI -- one-command run for macOS / Linux.
#
#   ./run.sh
#
# Creates a local virtualenv (first run only), installs dependencies,
# then starts the FastAPI backend on port 8000. The dashboard is served
# by the same process at http://127.0.0.1:8000/ -- nothing else to start.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null 2>&1 || { echo "python3 not found -- install Python 3.11+"; exit 1; }

if [ ! -x ".venv/bin/python" ]; then
  echo "[1/3] Creating virtual environment (.venv) ..."
  "$PYTHON" -m venv .venv
else
  echo "[1/3] Virtual environment already present."
fi
VENV_PY=".venv/bin/python"

if ! "$VENV_PY" -c "import fastapi, sklearn, web3" >/dev/null 2>&1; then
  echo "[2/3] Installing dependencies (first run can take a few minutes) ..."
  "$VENV_PY" -m pip install --upgrade pip
  "$VENV_PY" -m pip install -r requirements.txt
else
  echo "[2/3] Dependencies already installed."
fi

echo "[3/3] Starting PRAHARI on http://127.0.0.1:8000 ..."
( command -v xdg-open >/dev/null 2>&1 && sleep 2 && xdg-open "http://127.0.0.1:8000/" ) >/dev/null 2>&1 &
( command -v open >/dev/null 2>&1 && sleep 2 && open "http://127.0.0.1:8000/" ) >/dev/null 2>&1 &
exec "$VENV_PY" -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
