"""Frontend/backend integration checks -- no browser-testing stack.

These tests don't render the dashboard (no headless browser dependency,
per the "no unnecessary libraries" instruction). Instead they verify:
(1) the frontend files this dashboard needs actually exist and reference
    the real API contracts (not invented endpoints), and
(2) every backend endpoint the dashboard's JS calls is actually wired up
    and behaves as app.js expects, using FastAPI's own TestClient.
"""
from pathlib import Path

import pytest

from ai.config import PROJECT_ROOT

FRONTEND_DIR = PROJECT_ROOT / "frontend"


# --- frontend files exist and reference real endpoints ---------------------

def test_frontend_files_exist():
    assert (FRONTEND_DIR / "index.html").is_file()
    assert (FRONTEND_DIR / "style.css").is_file()
    assert (FRONTEND_DIR / "app.js").is_file()


def test_index_html_references_the_frontend_assets():
    html = (FRONTEND_DIR / "index.html").read_text()
    assert "style.css" in html
    assert "app.js" in html


def test_app_js_targets_the_real_backend_base_url():
    js = (FRONTEND_DIR / "app.js").read_text()
    assert "http://127.0.0.1:8000" in js


@pytest.mark.parametrize("endpoint", [
    "/status",
    "/traffic/current",
    "/forecast",
    "/replay/start",
    "/replay/stop",
    "/replay/reset",
    "/threats/generate",
    "/threats",
    "/blockchain/record",
    "/blockchain/records",
    "/blockchain/records/",
    "/blockchain/verify/",
])
def test_app_js_only_calls_endpoints_that_actually_exist(endpoint):
    js = (FRONTEND_DIR / "app.js").read_text()
    assert endpoint in js, f"app.js does not appear to reference {endpoint!r}"


def test_dashboard_honesty_labels_present_in_markup():
    """The honesty rule (never present the heuristic as trained AI output,
    never hide the degenerate model's real status) must be baked into the
    markup itself, not just left to be reasoned about at runtime."""
    html = (FRONTEND_DIR / "index.html").read_text()
    assert "DEMONSTRATION_MODE" in html or "DEMONSTRATION MODE" in html
    assert "HEURISTIC" in html
    assert "VALIDATED_MODEL_MODE" in html


def test_dashboard_uses_the_same_terminology_the_ppt_and_api_use():
    """GUI/PPT terminology must match: Risk, Predicted Attack, Forecast
    Window, Suspicious Source, Affected Asset, Why Flagged, Pattern Match,
    Recommended Actions, Threat Event, Blockchain, Integrity."""
    html = (FRONTEND_DIR / "index.html").read_text()
    for term in [
        "SECURITY FORECAST", "Predicted attack", "Forecast window",
        "Suspicious source", "Affected asset", "Why flagged", "Pattern match",
        "Recommended actions", "Threat event", "Blockchain", "Integrity",
        "Suspicious entities",
    ]:
        assert term in html, f"{term!r} missing from index.html"


def test_headline_forecast_banner_present_and_honestly_tagged():
    """The first-5-seconds headline must say FORECAST (not just detect),
    and must never present the heuristic-sourced reading as trained AI
    output -- it has to carry the same honesty tag as the detailed panels."""
    html = (FRONTEND_DIR / "index.html").read_text()
    assert "SECURITY FORECAST" in html
    assert "Forecast window" in html
    assert "NOT a trained AI model" in html


# --- backend contracts the dashboard depends on -----------------------------
# Uses FastAPI's own TestClient (starlette dependency, already installed
# with fastapi -- no new library added) rather than a browser.

@pytest.fixture()
def client():
    from fastapi.testclient import TestClient
    from backend.app import app, state
    from backend.security import API_KEY, API_KEY_HEADER

    with TestClient(app, headers={API_KEY_HEADER: API_KEY}) as c:
        yield c
        # leave shared state clean for other tests in the session
        if state.replay_task is not None and not state.replay_task.done():
            state.stop_event.set()
        state.threats.clear()
        state.ledger.clear()


def test_status_endpoint_shape_matches_what_app_js_reads(client):
    res = client.get("/status")
    assert res.status_code == 200
    data = res.json()
    assert "system_status" in data
    assert set(("loaded", "running", "current_minute_index", "total_minutes", "finished")) <= set(data["replay"].keys())
    assert set(("available", "unavailable_reason", "chain_id")) <= set(data["blockchain"].keys())


def test_traffic_current_is_404_before_any_replay(client):
    res = client.get("/traffic/current")
    assert res.status_code == 404


def test_forecast_endpoint_accepts_both_modes(client):
    for mode in ("VALIDATED_MODEL_MODE", "DEMONSTRATION_MODE"):
        res = client.get(f"/forecast?mode={mode}")
        assert res.status_code == 200
        data = res.json()
        assert data["mode"] == mode
        assert "ready" in data and "probability" in data and "model_status" in data


def test_threats_latest_is_404_when_nothing_generated_yet(client):
    res = client.get("/threats/latest")
    assert res.status_code == 404


def test_threats_list_is_empty_list_shape_when_nothing_generated_yet(client):
    res = client.get("/threats")
    assert res.status_code == 200
    assert res.json() == {"count": 0, "events": []}


def test_blockchain_records_list_shape(client):
    res = client.get("/blockchain/records")
    assert res.status_code == 200
    data = res.json()
    assert "count" in data and "records" in data


def test_baseline_endpoint_reports_current_vs_organizational_normal(client):
    res = client.get("/baseline")
    assert res.status_code == 200
    data = res.json()
    assert "available" in data and "overall_status" in data


def test_pattern_history_endpoint_reports_real_derived_incidents(client):
    res = client.get("/patterns/history")
    assert res.status_code == 200
    data = res.json()
    assert "count" in data and "incidents" in data
    # The real replayed dataset has exactly one continuous DDoS episode.
    assert data["count"] >= 1
    assert data["incidents"][0]["attack_type"] == "DDoS"


def test_cors_is_enabled_for_the_frontend_to_reach_the_api(client):
    res = client.get("/status", headers={"Origin": "null"})
    assert res.headers.get("access-control-allow-origin") == "*"


def test_full_dashboard_pipeline_end_to_end_via_test_client(client):
    """Exercises the exact sequence app.js performs each poll tick,
    against the real backend (real dataset, real trained model, real
    local blockchain) -- everything except opening an actual browser."""
    start = client.post("/replay/start", json={"minutes_per_second": 1000})
    assert start.status_code == 200

    import time
    for _ in range(50):
        if client.get("/traffic/current").status_code == 200:
            break
        time.sleep(0.05)
    client.post("/replay/stop")

    traffic = client.get("/traffic/current")
    assert traffic.status_code == 200

    for mode in ("VALIDATED_MODEL_MODE", "DEMONSTRATION_MODE"):
        forecast = client.get(f"/forecast?mode={mode}").json()
        if not forecast["ready"]:
            continue
        gen = client.post(f"/threats/generate?mode={mode}")
        assert gen.status_code == 200
        gen_data = gen.json()
        if not gen_data.get("event"):
            continue
        event_id = gen_data["event"]["event_id"]

        record = client.post("/blockchain/record", json={"event_id": event_id})
        assert record.status_code == 200
        assert record.json()["event_id"] == event_id

        verify = client.post(f"/blockchain/verify/{event_id}")
        assert verify.status_code == 200
        assert verify.json()["verified"] is True


def test_replay_seek_jumps_to_a_minute_and_rebuilds_forecast_state(client):
    """The dashboard's pause / step / rewind transport relies on
    POST /replay/seek: it must move the replay to an arbitrary minute
    (clamped to the dataset), leave it stopped, and rebuild the
    forecasting service so a forecast is immediately available there --
    not stuck at INSUFFICIENT_HISTORY."""
    status = client.get("/status").json()
    total = status["replay"]["total_minutes"]
    assert total > 40  # the committed CICIDS2017 Friday DDoS episode

    seeked = client.post("/replay/seek", json={"minute": 35})
    assert seeked.status_code == 200
    body = seeked.json()
    assert body["status"] == "seeked"
    assert body["minute"] == 35

    after = client.get("/status").json()["replay"]
    assert after["current_minute_index"] == 35
    assert after["running"] is False

    # A forecast is ready at the sought minute (history was warmed up).
    demo = client.get("/forecast?mode=DEMONSTRATION_MODE").json()
    assert demo["ready"] is True

    # Out-of-range minutes are clamped, not errors.
    clamped_hi = client.post("/replay/seek", json={"minute": 10_000})
    assert clamped_hi.status_code == 200
    assert clamped_hi.json()["minute"] == total

    clamped_lo = client.post("/replay/seek", json={"minute": -5})
    assert clamped_lo.status_code == 200
    assert clamped_lo.json()["minute"] == 0

    client.post("/replay/reset")


def test_replay_seek_is_rejected_while_replay_is_running(client):
    """Seeking mid-replay would race the background task -- the API must
    refuse until the replay is stopped (same contract as /replay/reset)."""
    started = client.post("/replay/start", json={"minutes_per_second": 1000})
    assert started.status_code == 200
    try:
        resp = client.post("/replay/seek", json={"minute": 5})
        assert resp.status_code == 409
    finally:
        client.post("/replay/stop")
        import time
        for _ in range(50):
            if client.get("/status").json()["replay"]["running"] is False:
                break
            time.sleep(0.05)
        client.post("/replay/reset")
