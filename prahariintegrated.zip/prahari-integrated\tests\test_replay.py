"""Tests for backend/replay.py."""
import pandas as pd
import pytest

from backend.replay import TrafficReplayEngine, compute_top_talkers_per_minute


def _write_synthetic_cleaned_csv(path):
    timestamps = pd.date_range("2017-07-07 03:30:00", periods=5, freq="1min")
    rows = []
    for i, ts in enumerate(timestamps):
        is_attack = 1 if i == 3 else 0
        rows.append({
            "timestamp": ts,
            "source_ip": f"10.0.0.{i}",
            "destination_ip": "192.168.1.1",
            "destination_port": 80 + i,
            "protocol": 6,
            "flow_duration": 1000 + i,
            "total_fwd_packets": 10 + i,
            "total_backward_packets": 5 + i,
            "total_length_of_fwd_packets": 100 + i,
            "total_length_of_bwd_packets": 50 + i,
            "flow_packets_s": 10.0 + i,
            "flow_bytes_s": 1000.0 + i,
            "label": "DDoS" if is_attack else "BENIGN",
            "is_attack": is_attack,
        })
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False)
    return df


def test_replay_engine_loads_and_reports_totals(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    _write_synthetic_cleaned_csv(csv_path)

    engine = TrafficReplayEngine(cleaned_csv_path=csv_path)
    assert engine.loaded
    assert engine.load_error is None
    assert engine.total_minutes == 5
    assert engine.index == 0
    assert engine.finished is False


def test_replay_engine_steps_in_chronological_order(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    _write_synthetic_cleaned_csv(csv_path)
    engine = TrafficReplayEngine(cleaned_csv_path=csv_path)

    timestamps = []
    while not engine.finished:
        row = engine.step()
        assert row is not None
        timestamps.append(row["timestamp"])
    assert timestamps == sorted(timestamps)
    assert len(timestamps) == 5
    assert engine.step() is None  # exhausted


def test_replay_engine_reset(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    _write_synthetic_cleaned_csv(csv_path)
    engine = TrafficReplayEngine(cleaned_csv_path=csv_path)

    engine.step()
    engine.step()
    assert engine.index == 2
    engine.reset()
    assert engine.index == 0
    assert not engine.finished


def test_replay_engine_run_invokes_callback_for_every_minute(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    _write_synthetic_cleaned_csv(csv_path)
    engine = TrafficReplayEngine(cleaned_csv_path=csv_path)

    seen = []
    engine.run(lambda row, idx, total: seen.append((idx, total)), minutes_per_second=0)
    assert seen == [(1, 5), (2, 5), (3, 5), (4, 5), (5, 5)]


def test_replay_engine_missing_file_reports_load_error(tmp_path):
    engine = TrafficReplayEngine(cleaned_csv_path=tmp_path / "does_not_exist.csv")
    assert not engine.loaded
    assert engine.load_error is not None
    assert engine.step() is None
    assert engine.total_minutes == 0


def test_replay_engine_step_includes_top_talker_fields(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    _write_synthetic_cleaned_csv(csv_path)
    engine = TrafficReplayEngine(cleaned_csv_path=csv_path)

    row = engine.step()
    assert row["top_source_ip"] == "10.0.0.0"  # only source IP in that minute
    assert row["top_source_ip_flow_count"] == 1
    assert row["top_source_ip_flow_share"] == 1.0
    assert row["top_destination_ip"] == "192.168.1.1"
    assert row["top_destination_port"] == 80


def _write_multi_flow_minute_csv(path):
    """One minute containing several flows from different source IPs, so
    the top-talker computation has a genuine majority to find."""
    ts = pd.Timestamp("2017-07-07 03:30:00")
    rows = []
    # 10.0.0.9 sends 5 flows (the real top talker); two other IPs send 1 each.
    for _ in range(5):
        rows.append({"source_ip": "10.0.0.9", "destination_ip": "192.168.1.1", "destination_port": 443})
    rows.append({"source_ip": "10.0.0.1", "destination_ip": "192.168.1.1", "destination_port": 443})
    rows.append({"source_ip": "10.0.0.2", "destination_ip": "192.168.1.2", "destination_port": 22})

    full_rows = []
    for r in rows:
        full_rows.append({
            "timestamp": ts,
            "protocol": 6,
            "flow_duration": 1000,
            "total_fwd_packets": 10,
            "total_backward_packets": 5,
            "total_length_of_fwd_packets": 100,
            "total_length_of_bwd_packets": 50,
            "flow_packets_s": 10.0,
            "flow_bytes_s": 1000.0,
            "label": "BENIGN",
            "is_attack": 0,
            **r,
        })
    df = pd.DataFrame(full_rows)
    df.to_csv(path, index=False)
    return df


def test_compute_top_talkers_finds_the_real_volume_leader(tmp_path):
    csv_path = tmp_path / "cleaned.csv"
    df = _write_multi_flow_minute_csv(csv_path)
    df["timestamp"] = pd.to_datetime(df["timestamp"])

    result = compute_top_talkers_per_minute(df, "timestamp")
    assert len(result) == 1
    row = result.iloc[0]
    assert row["top_source_ip"] == "10.0.0.9"
    assert row["top_source_ip_flow_count"] == 5
    assert row["top_source_ip_flow_share"] == round(5 / 7, 4)
    assert row["top_destination_ip"] == "192.168.1.1"


def test_compute_top_talkers_exposes_multiple_suspicious_sources(tmp_path):
    """Priority 3: multiple suspicious entities should be representable,
    not only the single strongest source."""
    csv_path = tmp_path / "cleaned.csv"
    df = _write_multi_flow_minute_csv(csv_path)
    df["timestamp"] = pd.to_datetime(df["timestamp"])

    result = compute_top_talkers_per_minute(df, "timestamp")
    top_sources = result.iloc[0]["top_sources"]
    assert len(top_sources) == 3  # 3 distinct source IPs in the fixture
    assert top_sources[0]["source_ip"] == "10.0.0.9"
    assert top_sources[0]["flow_count"] == 5
    assert top_sources[0]["rank"] == 1
    assert {s["source_ip"] for s in top_sources} == {"10.0.0.9", "10.0.0.1", "10.0.0.2"}


def test_compute_top_talkers_handles_missing_source_ip_column():
    df = pd.DataFrame({"timestamp": pd.to_datetime(["2017-01-01"]), "some_other_col": [1]})
    result = compute_top_talkers_per_minute(df, "timestamp")
    assert result.empty
