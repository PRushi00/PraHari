"""Basic API security for the FastAPI backend -- the "Security" role from
the recommended-practices checklist (API authorization, secrets via
environment variables, rate limiting, secure HTTP headers), scoped to
what a local single-admin cybersecurity prototype genuinely needs.

Not claimed as production-grade: no user accounts, no OAuth, no HTTPS
termination (that's the reverse proxy's job in a real deployment). What
IS real: every state-changing endpoint requires a shared API key read
from an environment variable (never hard-coded as a "real" secret), a
simple in-memory rate limiter protects against a runaway/abusive client,
and every response carries standard defensive headers.
"""
from __future__ import annotations

import os
import time
from collections import defaultdict, deque

from fastapi import Header, HTTPException, Request
from starlette.middleware.base import BaseHTTPMiddleware

# The default is a well-known placeholder for local/demo use only -- set
# PRAHARI_API_KEY in the environment for anything beyond a local demo.
# Never commit a real secret here; this module only ever reads from the
# environment.
API_KEY = os.environ.get("PRAHARI_API_KEY", "demo-local-admin-key")

API_KEY_HEADER = "X-API-Key"


async def require_api_key(x_api_key: str = Header(default=None, alias=API_KEY_HEADER)) -> None:
    """FastAPI dependency guarding state-changing endpoints (starting/
    stopping replay, generating threat events, writing to the
    blockchain). Read-only endpoints stay open so the dashboard's
    polling loop -- and a judge curling /status -- don't need a key."""
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail=f"missing or invalid {API_KEY_HEADER} header")


RATE_LIMIT_MAX_REQUESTS = 300
RATE_LIMIT_WINDOW_SECONDS = 10.0


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Simple in-memory sliding-window rate limiter, per client IP. No
    new dependency -- this is a small, honest, self-contained
    implementation appropriate for a single-process local prototype, not
    a claim of distributed rate limiting.

    The limit is deliberately generous (300 requests / 10s per IP): the
    dashboard's own 1-second polling loop makes roughly ten requests per
    tick, so this exists to stop a runaway or abusive client, not to
    throttle normal use.
    """

    def __init__(self, app, max_requests: int = RATE_LIMIT_MAX_REQUESTS, window_seconds: float = RATE_LIMIT_WINDOW_SECONDS):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host if request.client else "unknown"
        now = time.monotonic()
        hits = self._hits[client_ip]
        while hits and now - hits[0] > self.window_seconds:
            hits.popleft()
        if len(hits) >= self.max_requests:
            from starlette.responses import JSONResponse
            return JSONResponse(
                status_code=429,
                content={"detail": "rate limit exceeded -- too many requests from this client"},
            )
        hits.append(now)
        return await call_next(request)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Standard defensive headers on every response -- cheap, real,
    always-on hardening (not a substitute for HTTPS termination /
    OAuth / a WAF, which are deployment-stage concerns out of scope
    for this local prototype)."""

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-XSS-Protection"] = "0"
        return response
