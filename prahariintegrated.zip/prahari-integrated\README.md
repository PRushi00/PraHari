# AI-Based Network Attack Forecasting with Blockchain-Enabled Secure Threat Intelligence

**Pitch deck:** `docs/PraHari_Pitch_Deck.pptx` -- rewritten to describe exactly
this repository (no LSTM/MITRE/CIC-IDS-2018 claims that aren't implemented);
every slide is marked CURRENTLY IMPLEMENTED or FUTURE WORK.

---

## ⚡ Quick start (integrated build -- backend + dashboard, one command)

This build wires the **PRAHARI dashboard** (the "Operational Clarity" UI --
`frontend/index.html`, `frontend/style.css`, `frontend/app.js`) directly into
the **FastAPI backend**, which now serves the dashboard itself. You start one
process and open one URL; the browser talks to the API same-origin, so there
is no separate static server and no CORS setup.

**Windows** -- double-click **`run.bat`**, or in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File run.ps1
```

**macOS / Linux:**

```bash
./run.sh
```

Either script creates a local `.venv` (first run only), installs
`requirements.txt`, starts the backend on port 8000, and opens
**http://127.0.0.1:8000/**. Stop the server with `Ctrl+C`.

### Playback / transport controls (for walking a judge through it)

The dashboard has a transport bar over the forecast so the replay can be
paced for a live audience -- it drives the backend replay engine, it is
not a client-side fake:

| Control | Does |
|---|---|
| **Play / Pause / Resume** | Start the minute-by-minute replay, freeze it on any minute to explain what's on screen, then continue from exactly where it stopped. |
| **‹ / ›** (enabled while paused) | Step the replay back / forward **one dataset-minute at a time**. The forecast, evidence, and blockchain proof are rebuilt for that minute (`POST /replay/seek`). |
| **⏮ (rewind)** | Jump back to minute 0 and start playing again. |
| **⏹ (stop)** | Clear all state (replay, threat events, blockchain records). |
| **Speed: Slow / Normal / Fast** | 1 / 2 / 5 dataset-minutes per real second. **Slow** is the judge-friendly pace; changing speed mid-replay is seamless. Default is **Normal**. |

Typical judge flow: **Slow → Play**, let it reach the DDoS onset (~minute
27), **Pause** on the first `CRITICAL` reading to talk through the
evidence / recommended actions / blockchain proof, then **Resume** or step
`›` minute by minute.

**Manual equivalent** (if you'd rather run it yourself):

```bash
python -m venv .venv
.venv/Scripts/activate            # Windows;  source .venv/bin/activate on macOS/Linux
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn backend.app:app --port 8000
# then open http://127.0.0.1:8000/
```

> **Windows "Smart App Control" note.** On some locked-down Windows machines,
> Smart App Control blocks freshly-downloaded compiled wheels (`numpy`,
> `scipy`, `scikit-learn`), so a brand-new venv can't import them.
> `run.ps1` detects this and automatically rebuilds the venv with
> `--system-site-packages`, reusing the (already-trusted) packages from
> your base Python and installing only the pure-Python extras on top. If
> you hit this doing the manual steps, either create the venv with
> `python -m venv --system-site-packages .venv` after `pip install`-ing the
> scientific stack into your base Python once, or turn Smart App Control
> off in *Settings &rsaquo; Privacy &amp; security &rsaquo; Windows Security
> &rsaquo; App &amp; browser control*.

### What changed vs. the standalone backend

| | |
|---|---|
| `frontend/index.html`, `style.css`, `app.js` | **New** dashboard, built to the Stitch "Operational Clarity" design system, driven entirely by live API data (nothing mocked). |
| `frontend/classic.html`, `classic.css`, `classic.js` | The **previous** dashboard, kept intact and reachable at `http://127.0.0.1:8000/classic.html`. |
| `backend/app.py` | Mounts `frontend/` as static files; `GET /` serves the dashboard, the JSON API index moved to `GET /api`. Adds **`POST /replay/seek`** (`{"minute": N}`) so the UI can pause / step / rewind the replay -- it moves the replay to minute N and deterministically rebuilds the forecasting state there. All previous endpoints are unchanged. |
| `run.ps1` / `run.bat` / `run.sh` | One-command launchers (venv + install + serve + open browser). |
| `requirements.txt` | `httpx2` typo corrected to `httpx` (needed by the test suite's `TestClient`). |

The original Linux demo (`./demo/run_demo.sh`) and `uvicorn` instructions
further down this file still work unchanged.

---

## Purpose

A prototype system that continuously observes network traffic, flags
suspicious sources/assets, forecasts attack risk within a near-term
future window, and records verified threat predictions on a
tamper-evident ledger -- so that security teams can trust and share
early-warning threat intelligence instead of only reacting after the
fact.

## Intended production architecture

This is the authoritative target this prototype is evolving towards:

```
24x7 organizational network monitoring
  -> continuous traffic telemetry
  -> anomaly detection
  -> identify/focus on suspicious source, device, or asset
  -> temporal behaviour analysis
  -> correlate with known attack patterns and organizational history
  -> classify likely attack type
  -> forecast attack risk within a future time window (not an exact timestamp)
  -> alert the network administrator
      (predicted attack type, risk, affected asset/source, reasons/evidence,
       forecast window, recommended preventive actions)
  -> create structured threat event
  -> cryptographic hash
  -> blockchain-backed tamper-evident proof
  -> dashboard / API
```

The sections below state, stage by stage, what is genuinely implemented
today, what is a transparent placeholder, and what would still need to be
built for the diagram above to be true in production. Nothing here claims
more than the current single-episode dataset and single-machine prototype
actually supports.

## Current implementation status

**This is a proof-of-concept prototype, not a production system, and not
a validated generalizing forecaster.** The dataset it currently runs on
(CICIDS2017 Friday DDoS) contains exactly one continuous attack episode.
Two forecasting artifacts exist, and the backend is honest about both
rather than hiding either:

- `data/processed/baseline_random_forest.joblib` /
  `baseline_metrics.json` -- the original 1-minute-horizon research
  baseline (`ai/train_baseline_forecaster.py`), preserved unchanged.
  Under a chronological split it never sees a positive training example
  (`model_status: DEGENERATE_SINGLE_CLASS_TRAINING`) -- it deterministically
  predicts `probability: 0.0` for every input.
- `data/processed/window_random_forest.joblib` / `window_metrics.json` --
  the current, default operational forecaster
  (`ai/train_window_forecaster.py`), formulated as "is an attack likely
  somewhere in the next 30 minutes?" instead of an exact-minute claim
  (`model_status: SINGLE_EPISODE_UNVALIDATED`). Its training split does
  contain both classes, but the only available test rows are the tail of
  the SAME episode used for training -- not an independent occurrence.
  Measured **exactly as computed, including the unflattering result**:
  test accuracy = 0.0, false positive rate on test = 1.0 (46 train rows,
  15 test rows, all 15 wrongly predicted positive). This is not a bug --
  it is the honest, real consequence of training on one short episode with
  extreme class imbalance in the held-out tail.

Whichever model is loaded, its `model_status` is surfaced through the API
and dashboard exactly as saved, and its `risk_state` is forced to
`UNVALIDATED` regardless of the raw probability number, so a bare `0.0`
(or a confident-looking `0.97`) from either model can never be misread as
a validated "safe" or "certain" result. `DEMONSTRATION_MODE` is a
transparent, rule-based volume-anomaly heuristic -- never presented as
trained AI -- that genuinely earns a NORMAL / ELEVATED / HIGH_RISK / CRITICAL
`risk_state` reading, since it makes no validation claim in the first
place.

| Stage                                        | Status |
|-----------------------------------------------|--------|
| Traffic/Data Stream (CICIDS2017 loading)       | Implemented (`ai/preprocess.py`) |
| Temporal Windowing / per-minute aggregation    | Implemented (`streaming/windows.py`, `ai/build_forecasting_dataset.py`) |
| Feature Extraction                             | Implemented (`streaming/features.py`, 3-min lag features in `ai/build_lagged_forecasting_dataset.py`) |
| Traffic ingestion abstraction                  | Implemented (`backend/ingestion.py: TrafficSource`) -- `backend/replay.py`'s replay engine implements this interface today; a future live-capture source could implement the same interface without any downstream code changing. |
| Suspicious source/asset identification (top-3) | Implemented, deterministic, non-learned -- per-minute "top talker" volume tally (`backend/replay.py: compute_top_talkers_per_minute`): the top 3 source IPs by flow share, destination IP/port. Real per-minute traffic, not model-attributed. |
| Organizational baseline (current vs. normal)   | Implemented (`backend/baseline.py`) -- mean/stdev per traffic feature computed once from the replayed dataset's own BENIGN-labeled minutes; exposed via `/baseline` and folded into each threat event's `baseline_comparison`. A real descriptive statistic, not a learned model. |
| Attack-window forecasting (~30 min)            | Implemented -- `ai/build_window_forecast_dataset.py` + `ai/train_window_forecaster.py` + live service (`backend/forecasting_service.py`). Honestly `SINGLE_EPISODE_UNVALIDATED` (see above), never claimed as validated. |
| Original 1-minute-horizon baseline model       | Preserved, still fully working (`ai/train_baseline_forecaster.py`), no longer the live service's default. |
| Known-attack-pattern / historical-incident correlation | **Implemented, small and honest** (`backend/pattern_store.py`). A local rule-based knowledge base (volumetric-DDoS / port-scan / brute-force signatures over real observable traffic features) scores the current minute and reports a similarity score; historical incidents are derived deterministically from the replayed dataset's own ground-truth labels (currently surfaces the one real DDoS episode). Each known pattern also carries a real, publicly-documented MITRE ATT&CK tactic/technique label (e.g. DDoS -> Impact/T1498) -- a correct category lookup for situational context, not a trained attack-stage classifier. This is demo/reference knowledge, not a licensed threat-intel feed or a real organizational incident database -- see Limitations. |
| Attack-type identification                     | Implemented -- the trained window forecaster and the heuristic both report a predicted `attack_type` (the only attack label present in the training data, "DDoS"); the pattern store independently reports a rule-matched `attack_type` from its own signatures. Never presented as multi-class-trained attack classification -- this dataset only ever contains one attack type. |
| Early-Warning Lead Time KPI                    | Implemented (`ai/analyze_forecast_lead_time.py`, `GET /metrics/lead_time`) -- replays the same real dataset chronologically through both forecasting modes and measures, honestly, how many minutes before the real recorded attack onset each mode's signal first raised an alert. Reported once, precomputed (`data/processed/lead_time_analysis.json`), not fabricated or clamped positive: a mode that never escalates, or escalates late, is reported as such. |
| Logistic Regression baseline                   | Implemented (`ai/train_window_logreg_baseline.py`) -- a research-only comparison model trained on the identical dataset/split as the RandomForest window forecaster. NOT loaded by the live API (which only ever serves the RandomForest model) -- exists purely so that model's metrics have an honest point of comparison. |
| Persistent storage (threat events, blockchain records) | Implemented (`storage/persistence.py`) -- a real sqlite3 database file (gitignored, process/runtime state, not a pipeline artifact). Optional and additive: `ThreatEventStore`/`LocalBlockchainLedger` behave exactly as before when constructed without it; the live backend always wires it in, so events and blockchain records now survive a process restart instead of being lost with the in-memory store. |
| Structured threat event (attack type, risk, probability/confidence, suspicious sources, evidence, pattern match, baseline comparison, recommended actions, forecast window, model/mode status) | Implemented (`backend/threat_service.py`) -- see schema below |
| Network/Traffic Replay                         | Implemented (`backend/replay.py`) -- replays the real recorded dataset minute-by-minute, no fabricated traffic |
| FastAPI Backend                                | Implemented (`backend/app.py`) -- `/status`, `/traffic/current`, `/forecast`, `/baseline`, `/patterns/history`, `/metrics/lead_time`, `/replay/*`, `/threats/*`, `/blockchain/*` |
| Blockchain Threat Ledger                       | Implemented (`blockchain/ledger.py`) -- local in-process Ethereum-compatible chain (web3.py `EthereumTesterProvider`), SHA-256 proof hashing |
| Dashboard (risk-first, SOC-style layout)       | Implemented (`frontend/index.html`, `style.css`, `app.js`) -- plain HTML/CSS/JS, no build step. One unified "SECURITY FORECAST" hero (risk NORMAL/ELEVATED/HIGH/CRITICAL, predicted attack, forecast window, suspicious source/asset, pattern match, baseline comparison, why flagged, recommended actions, blockchain/integrity proof) driven by whichever mode a toggle selects (Live Heuristic Signal / Trained AI Model) -- never two competing panels. Every raw number, model-status code, and validation caveat for both modes is still there, in a collapsed "Technical & Validation Details" section, one click away. |
| End-to-end demo runner                         | Implemented (`demo/run_demo.sh`) -- orchestrates the existing backend/dashboard/replay/threat/blockchain pipeline over its real API, no duplicated logic |
| API security (auth, rate limiting, headers)    | Implemented (`backend/security.py`) -- see "Security, API docs, alerts" below |
| Administrator alerting                         | Implemented, log-only (`backend/notifier.py`, `GET /alerts`) -- real alert records, no email/SMS/push delivery |
| Interactive API docs                           | Implemented -- FastAPI's built-in `/docs` and `/redoc` |
| Traffic trend visualization                    | Implemented -- inline SVG sparkline in the dashboard, no external charting library/CDN dependency |
| Containerization / CI                          | `Dockerfile` written (not build-tested here, see below); `.github/workflows/tests.yml` runs the test suite on push |

**The full local prototype is runnable end-to-end with a single command:
`./demo/run_demo.sh`** -- see RUNNING THE FINAL DEMO below.

### Threat event schema

Each generated `ThreatEvent` (`backend/threat_service.py`) carries, at
minimum: `event_id`, `timestamp`, `forecast_window` (a ~30-minute window
descriptor, not an exact-timestamp claim), `predicted_attack_type`,
`severity` and `risk_state`, `attack_probability`/`confidence` (confidence
is `null` whenever the underlying model is unvalidated -- never
fabricated), `suspicious_source` (source IP, flow share, destination
IP/port -- `null` when not available for that minute), `evidence` (a list
of concrete signals: real feature importances for the trained model,
z-score/top-talker-share for the heuristic), `recommended_actions` (a
list, graded by severity), `pattern_match` (the real known-pattern-store
result for that minute -- `MATCHED` with a similarity score, MITRE
tactic/technique, and matching historical incidents, or `NO_MATCH`/
`NOT_AVAILABLE` when nothing scores high enough or no features were
supplied; see `backend/pattern_store.py` above), `baseline_comparison`
(current-vs-organizational-normal, `backend/baseline.py`), and
`model_status`/`model_version` so validated-model output and
demonstration-heuristic output are never confused with each other.

The observation window (3 minutes of lag features) and forecast horizon
(30 minutes) used throughout are documented in `ai/config.py` and
`ai/analyze_temporal.py`'s inspection of the real dataset's temporal
structure.

## Repository structure

```
ai-network-forecast/
├── backend/             # FastAPI app, forecasting service, threat-event/pattern-store, traffic replay engine
├── ai/                  # Data loading, cleaning, temporal analysis, dataset building, model training
├── streaming/           # Generic windowing and feature extraction utilities
├── blockchain/          # Local Ethereum-compatible ledger (threat-event hash recording/verification)
├── storage/             # Real sqlite3 persistence for threat events/blockchain records (optional, additive)
├── frontend/            # Plain HTML/CSS/JS dashboard (no build step)
├── data/
│   ├── raw/              # Place CICIDS2017 CSV files here (gitignored -- see Dataset placement)
│   ├── processed/        # COMMITTED to this repo: cleaned.csv, forecasting_dataset.csv,
│   │                     # lagged_forecasting_dataset.csv, window_forecast_dataset.csv,
│   │                     # window_random_forest.joblib, window_metrics.json,
│   │                     # baseline_random_forest.joblib, baseline_metrics.json,
│   │                     # window_logreg_baseline.joblib, window_logreg_baseline_metrics.json,
│   │                     # lead_time_analysis.json
│   │                     # (only plots/ is gitignored -- regenerated, not required)
│   └── runtime/          # gitignored -- storage/persistence.py's sqlite3 database (process state, not a pipeline artifact)
├── demo/                # run_demo.sh -- single-command end-to-end demo
├── tests/               # Unit tests
├── requirements.txt
├── .env.example
├── start.sh
└── README.md
```

## Installing dependencies

Requires Python 3.11+.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Dataset placement

**You do not need to do this to run the demo.** `data/processed/` (the
cleaned dataset, both trained models, their metrics, and every
intermediate dataset) is already committed to this repository, so
`./demo/run_demo.sh` and the backend work immediately after cloning --
skip ahead to RUNNING THE FINAL DEMO below. The steps in this section and
the next are only needed if you want to rebuild those artifacts from
scratch (e.g. because you changed the preprocessing/feature code, or want
to try a different CICIDS2017 capture file).

**Use the "GeneratedLabelledFlows" / "TrafficLabelling" release of
CICIDS2017, not "MachineLearningCVE".** The MachineLearningCVE release
strips the `Timestamp` (and source/destination IP/port) columns this
temporal forecasting pipeline requires — that variant was tried and
rejected early in this project for exactly that reason.

This prototype was built and tested against the Friday afternoon DDoS
capture specifically:

```bash
mkdir -p data/raw
curl -L -o data/raw/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv \
  https://raw.githubusercontent.com/SHUBHAMRAWAT-25/DDOS-attack-detection-using-random-forest-algorithm/main/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv
```

That single file (~96 MB, 225,745 flows) is sufficient to run every
command below — you do not need the other days' captures. Any other
GeneratedLabelledFlows-release CSV can also be placed under `data/raw/`
(subfolders are fine — the pipeline searches recursively and does not
assume a fixed number or naming of files; column names, timestamp
format, and label column are auto-detected). Note the temporal-forecasting
formulation (3-minute lookback, 30-minute forecast window, chronological
split choices in `ai/train_window_forecaster.py`) was specifically derived
from this Friday DDoS file's own structure — using a different capture
means re-examining `ai/analyze_temporal.py`'s output before assuming the
same window/horizon still make sense.

## Commands

Validate the environment (does not start any services yet):

```bash
./start.sh
```

Inspect whatever dataset is currently available (raw or already-cleaned):

```bash
python ai/inspect_data.py
```

Load, clean, and save the dataset to `data/processed/cleaned.csv`:

```bash
python ai/preprocess.py
```

Run exploratory temporal analysis (requires `cleaned.csv` to exist) and
generate plots into `data/processed/plots/`:

```bash
python ai/analyze_temporal.py
```

Run the test suite:

```bash
pytest
```

Build the datasets and train both forecasters (needs `cleaned.csv` from
the preprocess step above):

```bash
python ai/build_forecasting_dataset.py
python ai/build_lagged_forecasting_dataset.py
python ai/train_baseline_forecaster.py          # original 1-minute baseline (preserved)
python ai/build_window_forecast_dataset.py      # 30-minute forecast-window dataset
python ai/train_window_forecaster.py            # current default operational forecaster
python ai/train_window_logreg_baseline.py       # research-only comparison model, same dataset/split
python ai/analyze_forecast_lead_time.py         # Early-Warning Lead Time KPI, replays the dataset once offline
```

## Running the backend locally

`data/processed/cleaned.csv`, `window_random_forest.joblib`, and
`window_metrics.json` are already committed to this repository, so this
works right after cloning -- the steps above only matter if you're
rebuilding these from scratch (the original
`baseline_random_forest.joblib`/`baseline_metrics.json` are also
committed, but optional -- only needed if you explicitly point
`ForecastingService` at them).

```bash
uvicorn backend.app:app --reload --port 8000
```

Then, in another terminal:

```bash
curl http://127.0.0.1:8000/status
curl -X POST http://127.0.0.1:8000/replay/start -H "X-API-Key: demo-local-admin-key" -H "Content-Type: application/json" -d '{"minutes_per_second": 5}'
curl http://127.0.0.1:8000/traffic/current
curl "http://127.0.0.1:8000/forecast?mode=VALIDATED_MODEL_MODE"
curl "http://127.0.0.1:8000/forecast?mode=DEMONSTRATION_MODE"
curl http://127.0.0.1:8000/metrics/lead_time
curl -X POST http://127.0.0.1:8000/replay/stop -H "X-API-Key: demo-local-admin-key"
curl -X POST http://127.0.0.1:8000/replay/reset -H "X-API-Key: demo-local-admin-key"
```

`VALIDATED_MODEL_MODE` runs the real trained window forecaster exactly
as-is, reporting its own honest `model_status`
(`SINGLE_EPISODE_UNVALIDATED` by default) and forcing `risk_state` to
`UNVALIDATED` no matter what the raw probability says.
`DEMONSTRATION_MODE` is a transparent rule-based volume-anomaly heuristic
(explicitly *not* a trained model) so the replay has a responsive,
genuinely-graded NORMAL/ELEVATED/HIGH_RISK/CRITICAL signal to show while the
dataset limitation stands.

### Security, API docs, alerts, and other supporting roles

A cybersecurity prototype should itself practice basic API security, so
this backend genuinely implements a small, honest set of the roles a
project like this typically needs (deliberately not every role in a
generic "recommended APIs & services" checklist -- only the ones that
actually fit an AI-forecasting + blockchain backend):

- **API authorization** (`backend/security.py`): every state-changing
  endpoint (`POST /replay/*`, `/threats/generate`, `/blockchain/record`)
  requires an `X-API-Key` header. Default is a documented local/demo key
  (`demo-local-admin-key`); set the `PRAHARI_API_KEY` environment
  variable to change it (`demo/run_demo.sh` and `frontend/app.js` both
  read/send the same default -- keep them consistent if you change it).
  Read-only `GET` endpoints stay open.
- **Rate limiting** (`backend/security.py: RateLimitMiddleware`): a
  simple in-memory per-IP sliding-window limiter (300 requests / 10s) --
  generous enough for the dashboard's own polling loop, there to stop a
  runaway or abusive client.
- **Secure HTTP headers** (`SecurityHeadersMiddleware`): `X-Content-Type-Options`,
  `X-Frame-Options`, `Referrer-Policy` on every response.
- **API testing & documentation**: FastAPI's built-in interactive docs
  are enabled at `GET /docs` (Swagger UI) and `GET /redoc` -- no extra
  setup needed.
- **Administrator alerting** (`backend/notifier.py`): every CRITICAL/HIGH
  threat event is recorded to a real, inspectable alert log (`GET
  /alerts`). No email/SMS/push integration exists -- `AlertChannel` names
  the interface a real one would implement, exactly the same pattern as
  `TrafficSource` (ingestion) and `PatternStore` (pattern/history).
- **Data persistence** (`storage/persistence.py`): a real sqlite3 database
  (gitignored, process/runtime state under `data/runtime/`) backs both the
  threat-event store and the blockchain ledger's record index, so both
  survive a process restart -- one file, no external database service, no
  ORM, appropriate for a single-process local prototype.
- **Data visualization**: the dashboard's "Traffic Trend" panel is a
  small hand-drawn inline SVG sparkline (current traffic vs.
  organizational baseline, from real replayed data) -- deliberately not a
  charting library pulled from a CDN, so the dashboard stays fully
  offline/dependency-free.
- **Containerization** (`Dockerfile`): `docker build -t prahari-backend .`
  packages the backend (with the already-committed dataset/models) into
  one image; `docker run -p 8000:8000 -e PRAHARI_API_KEY=change-me
  prahari-backend` runs it. Not build-tested in the environment this was
  authored in (its network policy blocks the Docker Hub registry) --
  written to standard conventions and worth a real `docker build` check
  on a machine with normal internet access.
- **CI** (`.github/workflows/tests.yml`): runs the full `pytest` suite on
  every push/PR via GitHub Actions.

## RUNNING THE DASHBOARD

The dashboard is a static page (plain HTML/CSS/JS, no build step, no
React/Vite) that talks to the backend at `http://127.0.0.1:8000`. On
Fedora:

**1. Activate the virtual environment**

```bash
source .venv/bin/activate
```

**2. Install requirements (only if not already done)**

```bash
pip install -r requirements.txt
```

**3. Start the backend** (must be on port 8000 — the dashboard is
hard-coded to that origin)

```bash
uvicorn backend.app:app --port 8000
```

**4. Open the dashboard locally** (in another terminal, or just from your
file manager / browser)

```bash
xdg-open frontend/index.html
```

If your browser blocks `file://` fetches in some configuration, serve it
instead from a second terminal:

```bash
cd frontend && python3 -m http.server 8080
# then open http://127.0.0.1:8080 in a browser
```

**5. Start the demo** — click the **Start Demo** button on the dashboard
(this calls `POST /replay/start` with `minutes_per_second: 5`). The
dashboard polls the backend every second and updates traffic, both
forecast modes, threat events, and blockchain records automatically as
the replay progresses through the real recorded dataset.

**6. Reset the demo** — click the **Reset** button (this calls
`POST /replay/stop` then `POST /replay/reset`) to clear all state and
replay from the beginning.

The dashboard is one unified "SECURITY FORECAST" hero, ordered so what an
admin/judge needs first is on top: **current risk state** (a big
NORMAL/ELEVATED/HIGH/CRITICAL/UNVALIDATED badge, never a bare,
easy-to-misread percentage), **predicted attack**, **forecast window**,
**pattern match**, **vs. organizational baseline**, **suspicious
source**/**affected asset**, **why this was flagged** (concrete
evidence), **recommended actions**, and **blockchain proof**
(threat event created / recorded / verified) for that same reading. A
toggle at the top switches which forecasting mode feeds this same
layout -- **Live Heuristic Signal** (`DEMONSTRATION_MODE`, the default,
since it earns a genuinely graded risk reading) or **Trained AI Model**
(`VALIDATED_MODEL_MODE`, honestly always `UNVALIDATED`) -- both are
always computed every poll tick, never blended, so switching is instant.
Everything a skeptical judge or engineer would want to audit -- both
modes' raw scores/confidence/status side by side, the exact validation
limitation, pattern-correlation detail, blockchain ledger internals --
is still there, inside a collapsed **Technical & Validation Details**
panel at the bottom, one click away rather than competing with the
headline story.

## RUNNING THE FINAL DEMO

For a single repeatable command that starts everything and walks through
the full pipeline automatically (see `demo/README.md` for exactly what it
does and why), instead of the manual steps above:

**Exact setup command** (once) -- just the environment, since
`data/processed/`'s datasets and trained models are already committed:

```bash
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
```

(Only if you want to rebuild the datasets/models from scratch instead of
using the committed ones:
`python ai/preprocess.py && python ai/build_forecasting_dataset.py && python ai/build_lagged_forecasting_dataset.py && python ai/build_window_forecast_dataset.py && python ai/train_window_forecaster.py`
-- requires the raw CICIDS2017 CSV under `data/raw/`, see Dataset
placement above.)

**Exact demo command:**

```bash
./demo/run_demo.sh
```

**Dashboard URL:** `http://127.0.0.1:8080/index.html` (printed by the
script, and opened automatically if `xdg-open` is available).

**How to stop:** press `Ctrl+C` in the terminal running the script. It
terminates only the two processes it started (the backend and the
dashboard's static file server) — nothing else on the system.

**What the judge should observe**, in order, printed as numbered
milestones with real values from the actual API responses (never
invented):

```
[1] Backend started
[2] Replay started
[3] Forecasting active   (+ real risk_state/model_status, both modes, for comparison)
[4] Threat event generated   (+ suspicious source, first recommended action)
[5] Blockchain record confirmed
[6] Threat verification successful
```

...after which the backend and dashboard keep running so the judge can
watch the dashboard update live, or interact with it directly (Reset,
re-run, inspect panels).

**Important:** `DEMONSTRATION_MODE` drives the visible walkthrough
because it's a transparent, rule-based heuristic that actually earns a
graded NORMAL/ELEVATED/HIGH_RISK/CRITICAL `risk_state` from the replayed traffic
-- it is explicitly labeled `HEURISTIC_NOT_A_TRAINED_MODEL` everywhere it
appears (script output and dashboard) and is never presented as AI
output. `VALIDATED_MODEL_MODE` — the real trained window forecaster — is
currently **unvalidated**: the dataset (CICIDS2017 Friday DDoS) contains
exactly one continuous attack episode, so the only available test rows
are the tail of that same episode, not an independent occurrence
(`model_status: SINGLE_EPISODE_UNVALIDATED` in
`data/processed/window_metrics.json`, measured test accuracy = 0.0). Its
`risk_state` is forced to `UNVALIDATED` for exactly this reason,
regardless of the raw probability — this is the model's real, documented
behavior, printed and displayed honestly rather than hidden or replaced
with a fabricated result.

## What would still be needed for production

Stated plainly, so the current scope is never overstated:

- **Multiple independent attack episodes** (ideally from real
  organizational traffic, not just CICIDS2017) — the single biggest gap.
  Without it, no chronological split can ever produce a genuinely
  validated held-out test.
- **A real production threat-intel/organizational-history database**
  behind `backend/pattern_store.py`'s `PatternStore.match` interface —
  today it matches against a small local knowledge base of generic
  textbook signatures plus incidents derived only from this dataset's own
  labels, not a licensed feed or a real organization's incident history.
- **Live packet/flow capture** implementing `backend/ingestion.py`'s
  `TrafficSource` interface, in place of `backend/replay.py`'s replay of a
  static historical file — the interface is designed for this, but no
  live-capture implementation exists here today.
- **Richer multi-asset/multi-tenant suspicious-source tracking** beyond
  the top-3 talker-by-flow-count tally implemented today — still a
  simple, transparent volume computation, not per-asset behavioral
  profiling.
- **A production-grade database** behind `storage/persistence.py` --
  threat events and blockchain records now survive a process restart via
  a real sqlite3 file (see the Current implementation status table
  above), which closes the local-demo gap this bullet used to describe;
  a real deployment would still want a managed database service (concurrent
  writers, backups, migrations), not a single sqlite file.
- **True MITRE ATT&CK attack-stage classification** -- `backend/
  pattern_store.py`'s known patterns each carry a real, publicly-documented
  MITRE tactic/technique label (a correct category lookup), but there is no
  trained model here that predicts stage progression from per-flow data;
  that would need attack-stage-labeled training data this dataset does not
  have.
- **Sequence/deep-learning forecasting (e.g. LSTM) and multi-step-ahead
  attack simulation** -- both were part of the original idea-stage concept
  for this project. The current forecaster is a RandomForest (plus a
  Logistic Regression research comparison, `ai/train_window_logreg_baseline.py`)
  over lag features, not a trained sequence model, and there is no
  simulated multi-step-forward attack projection -- both would need
  substantially more independent attack data than this single-episode
  dataset provides to validate honestly.

## Engineering notes

- No hard-coded absolute paths — all paths are derived from `ai/config.py`
  relative to the project root.
- No random shuffling/splitting of temporal data anywhere in this project;
  every train/test split cuts the timeline, never samples rows.
- Feature extraction only uses columns that are actually present in the
  loaded CICIDS2017 files — nothing is fabricated.
- Suspicious-source/asset context (`backend/replay.py`'s top-talker
  computation) is a plain, deterministic volume tally over real flow
  records — it is exposed as supporting evidence/context only, never fed
  into either forecasting model as an input.
- `streaming/windows.py` and `streaming/features.py` are reusable and take
  the window size / observation window / forecast horizon as parameters.
