"""Quick dataset inspection CLI.

    python ai/inspect_data.py

Produces a concise report of what CICIDS2017 data is available and what
the pipeline detects in it, without requiring the full preprocess run
first. If data/processed/cleaned.csv already exists, that is inspected
instead (faster, and reflects the cleaned state); otherwise a lightweight
pass over the raw CSVs is used.
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd

from ai.config import CLEANED_DATA_PATH, RAW_DATA_DIR
from ai.preprocess import (
    DatasetNotFoundError,
    detect_label_column,
    detect_timestamp_column,
    find_csv_files,
    load_raw_data,
)
from ai.analyze_temporal import find_contiguous_segments


def _print_header(title: str) -> None:
    print(f"\n=== {title} ===")


def inspect(df: pd.DataFrame, source_desc: str) -> None:
    _print_header("Dataset files")
    print(source_desc)

    _print_header("Rows / columns")
    print(f"rows loaded: {len(df)}")
    print(f"columns detected ({df.shape[1]}): {list(df.columns)}")

    timestamp_col = detect_timestamp_column(df)
    label_col = detect_label_column(df)
    print(f"\ntimestamp column: {timestamp_col!r}")
    print(f"label column: {label_col!r}")

    if label_col:
        classes = df[label_col].dropna().unique()
        _print_header("Attack classes")
        print(f"{len(classes)} classes: {sorted(str(c) for c in classes)}")

    if timestamp_col:
        ts = pd.to_datetime(df[timestamp_col], errors="coerce", format="mixed")
        ts_valid = ts.dropna()
        _print_header("Time span")
        if not ts_valid.empty:
            print(f"{ts_valid.min()} -> {ts_valid.max()} (span: {ts_valid.max() - ts_valid.min()})")
            sorted_ts = ts_valid.sort_values().drop_duplicates()
            if len(sorted_ts) > 1:
                gaps = sorted_ts.diff().dropna().dt.total_seconds()
                print(f"temporal resolution: min gap={gaps.min():.3f}s median gap={gaps.median():.3f}s")
        else:
            print("no parseable timestamps")

    _print_header("Missing values")
    na_counts = df.isna().sum()
    na_counts = na_counts[na_counts > 0].sort_values(ascending=False)
    if na_counts.empty:
        print("none")
    else:
        print(na_counts.head(20).to_string())
        if len(na_counts) > 20:
            print(f"... and {len(na_counts) - 20} more columns with missing values")

    _print_header("Usable numeric features")
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    numeric_cols = [c for c in numeric_cols if c not in {"is_attack", "label_encoded"}]
    print(f"{len(numeric_cols)} numeric columns: {numeric_cols}")

    if timestamp_col and label_col and "is_attack" in df.columns:
        _print_header("Attack intervals")
        df_sorted = df.sort_values(timestamp_col).copy()
        df_sorted[timestamp_col] = pd.to_datetime(df_sorted[timestamp_col], errors="coerce")
        df_sorted = df_sorted.dropna(subset=[timestamp_col])
        segments = find_contiguous_segments(df_sorted["is_attack"], df_sorted[timestamp_col])
        print(f"{len(segments)} contiguous attack segments")
        if not segments.empty:
            print(segments.describe(include="all").loc[["min", "max"]].to_string())


def main() -> None:
    if CLEANED_DATA_PATH.exists():
        df = pd.read_csv(CLEANED_DATA_PATH, low_memory=False)
        inspect(df, f"using cleaned dataset: {CLEANED_DATA_PATH}")
        return

    files = find_csv_files(RAW_DATA_DIR)
    if not files:
        print(f"No CSV files found under {RAW_DATA_DIR}.")
        print("Place CICIDS2017 CSV files there (see README.md) and re-run this script.")
        sys.exit(1)

    try:
        df = load_raw_data(files)
    except DatasetNotFoundError as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)

    file_list = "\n".join(f"  - {f}" for f in files)
    inspect(df, f"found {len(files)} file(s) under {RAW_DATA_DIR} (no cleaned.csv yet, inspecting raw):\n{file_list}")


if __name__ == "__main__":
    main()
